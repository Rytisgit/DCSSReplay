#pragma once

int unrandart_to_tile(int unrand);
int unrandart_to_doll_tile(int unrand);
