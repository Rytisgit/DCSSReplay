define(["./tileinfo-main"], function(m) {
// This file has been automatically generated.

var exports = {};

var val = m.TILE_MAIN_MAX;
exports.DEMON_BODY = val++;
val = exports.DEMON_BODY_CYAN = exports.DEMON_BODY; val++;
exports.DEMON_BODY_1 = val++;
exports.DEMON_BODY_2 = val++;
exports.DEMON_BODY_3 = val++;
exports.DEMON_BODY_4 = val++;
exports.DEMON_BODY_5 = val++;
exports.DEMON_BODY_6 = val++;
exports.DEMON_BODY_7 = val++;
exports.DEMON_BODY_8 = val++;
exports.DEMON_BODY_9 = val++;
exports.DEMON_BODY_10 = val++;
exports.DEMON_BODY_11 = val++;
exports.DEMON_BODY_12 = val++;
exports.DEMON_BODY_RED = val++;
exports.DEMON_BODY_RED_1 = val++;
exports.DEMON_BODY_RED_2 = val++;
exports.DEMON_BODY_RED_3 = val++;
exports.DEMON_BODY_RED_4 = val++;
exports.DEMON_BODY_RED_5 = val++;
exports.DEMON_BODY_RED_6 = val++;
exports.DEMON_BODY_RED_7 = val++;
exports.DEMON_BODY_RED_8 = val++;
exports.DEMON_BODY_RED_9 = val++;
exports.DEMON_BODY_RED_10 = val++;
exports.DEMON_BODY_RED_11 = val++;
exports.DEMON_BODY_RED_12 = val++;
exports.DEMON_BODY_BLUE = val++;
exports.DEMON_BODY_BLUE_1 = val++;
exports.DEMON_BODY_BLUE_2 = val++;
exports.DEMON_BODY_BLUE_3 = val++;
exports.DEMON_BODY_BLUE_4 = val++;
exports.DEMON_BODY_BLUE_5 = val++;
exports.DEMON_BODY_BLUE_6 = val++;
exports.DEMON_BODY_BLUE_7 = val++;
exports.DEMON_BODY_BLUE_8 = val++;
exports.DEMON_BODY_BLUE_9 = val++;
exports.DEMON_BODY_BLUE_10 = val++;
exports.DEMON_BODY_BLUE_11 = val++;
exports.DEMON_BODY_BLUE_12 = val++;
exports.DEMON_BODY_GREEN = val++;
exports.DEMON_BODY_GREEN_1 = val++;
exports.DEMON_BODY_GREEN_2 = val++;
exports.DEMON_BODY_GREEN_3 = val++;
exports.DEMON_BODY_GREEN_4 = val++;
exports.DEMON_BODY_GREEN_5 = val++;
exports.DEMON_BODY_GREEN_6 = val++;
exports.DEMON_BODY_GREEN_7 = val++;
exports.DEMON_BODY_GREEN_8 = val++;
exports.DEMON_BODY_GREEN_9 = val++;
exports.DEMON_BODY_GREEN_10 = val++;
exports.DEMON_BODY_GREEN_11 = val++;
exports.DEMON_BODY_GREEN_12 = val++;
exports.DEMON_BODY_MAGENTA = val++;
exports.DEMON_BODY_MAGENTA_1 = val++;
exports.DEMON_BODY_MAGENTA_2 = val++;
exports.DEMON_BODY_MAGENTA_3 = val++;
exports.DEMON_BODY_MAGENTA_4 = val++;
exports.DEMON_BODY_MAGENTA_5 = val++;
exports.DEMON_BODY_MAGENTA_6 = val++;
exports.DEMON_BODY_MAGENTA_7 = val++;
exports.DEMON_BODY_MAGENTA_8 = val++;
exports.DEMON_BODY_MAGENTA_9 = val++;
exports.DEMON_BODY_MAGENTA_10 = val++;
exports.DEMON_BODY_MAGENTA_11 = val++;
exports.DEMON_BODY_MAGENTA_12 = val++;
exports.DEMON_BODY_BROWN = val++;
exports.DEMON_BODY_BROWN_1 = val++;
exports.DEMON_BODY_BROWN_2 = val++;
exports.DEMON_BODY_BROWN_3 = val++;
exports.DEMON_BODY_BROWN_4 = val++;
exports.DEMON_BODY_BROWN_5 = val++;
exports.DEMON_BODY_BROWN_6 = val++;
exports.DEMON_BODY_BROWN_7 = val++;
exports.DEMON_BODY_BROWN_8 = val++;
exports.DEMON_BODY_BROWN_9 = val++;
exports.DEMON_BODY_BROWN_10 = val++;
exports.DEMON_BODY_BROWN_11 = val++;
exports.DEMON_BODY_BROWN_12 = val++;
exports.DEMON_BODY_LIGHTGRAY = val++;
exports.DEMON_BODY_LIGHTGRAY_1 = val++;
exports.DEMON_BODY_LIGHTGRAY_2 = val++;
exports.DEMON_BODY_LIGHTGRAY_3 = val++;
exports.DEMON_BODY_LIGHTGRAY_4 = val++;
exports.DEMON_BODY_LIGHTGRAY_5 = val++;
exports.DEMON_BODY_LIGHTGRAY_6 = val++;
exports.DEMON_BODY_LIGHTGRAY_7 = val++;
exports.DEMON_BODY_LIGHTGRAY_8 = val++;
exports.DEMON_BODY_LIGHTGRAY_9 = val++;
exports.DEMON_BODY_LIGHTGRAY_10 = val++;
exports.DEMON_BODY_LIGHTGRAY_11 = val++;
exports.DEMON_BODY_LIGHTGRAY_12 = val++;
exports.DEMON_BODY_DARKGRAY = val++;
exports.DEMON_BODY_DARKGRAY_1 = val++;
exports.DEMON_BODY_DARKGRAY_2 = val++;
exports.DEMON_BODY_DARKGRAY_3 = val++;
exports.DEMON_BODY_DARKGRAY_4 = val++;
exports.DEMON_BODY_DARKGRAY_5 = val++;
exports.DEMON_BODY_DARKGRAY_6 = val++;
exports.DEMON_BODY_DARKGRAY_7 = val++;
exports.DEMON_BODY_DARKGRAY_8 = val++;
exports.DEMON_BODY_DARKGRAY_9 = val++;
exports.DEMON_BODY_DARKGRAY_10 = val++;
exports.DEMON_BODY_DARKGRAY_11 = val++;
exports.DEMON_BODY_DARKGRAY_12 = val++;
exports.DEMON_BODY_LIGHTRED = val++;
exports.DEMON_BODY_LIGHTRED_1 = val++;
exports.DEMON_BODY_LIGHTRED_2 = val++;
exports.DEMON_BODY_LIGHTRED_3 = val++;
exports.DEMON_BODY_LIGHTRED_4 = val++;
exports.DEMON_BODY_LIGHTRED_5 = val++;
exports.DEMON_BODY_LIGHTRED_6 = val++;
exports.DEMON_BODY_LIGHTRED_7 = val++;
exports.DEMON_BODY_LIGHTRED_8 = val++;
exports.DEMON_BODY_LIGHTRED_9 = val++;
exports.DEMON_BODY_LIGHTRED_10 = val++;
exports.DEMON_BODY_LIGHTRED_11 = val++;
exports.DEMON_BODY_LIGHTRED_12 = val++;
exports.DEMON_BODY_LIGHTBLUE = val++;
exports.DEMON_BODY_LIGHTBLUE_1 = val++;
exports.DEMON_BODY_LIGHTBLUE_2 = val++;
exports.DEMON_BODY_LIGHTBLUE_3 = val++;
exports.DEMON_BODY_LIGHTBLUE_4 = val++;
exports.DEMON_BODY_LIGHTBLUE_5 = val++;
exports.DEMON_BODY_LIGHTBLUE_6 = val++;
exports.DEMON_BODY_LIGHTBLUE_7 = val++;
exports.DEMON_BODY_LIGHTBLUE_8 = val++;
exports.DEMON_BODY_LIGHTBLUE_9 = val++;
exports.DEMON_BODY_LIGHTBLUE_10 = val++;
exports.DEMON_BODY_LIGHTBLUE_11 = val++;
exports.DEMON_BODY_LIGHTBLUE_12 = val++;
exports.DEMON_BODY_LIGHTGREEN = val++;
exports.DEMON_BODY_LIGHTGREEN_1 = val++;
exports.DEMON_BODY_LIGHTGREEN_2 = val++;
exports.DEMON_BODY_LIGHTGREEN_3 = val++;
exports.DEMON_BODY_LIGHTGREEN_4 = val++;
exports.DEMON_BODY_LIGHTGREEN_5 = val++;
exports.DEMON_BODY_LIGHTGREEN_6 = val++;
exports.DEMON_BODY_LIGHTGREEN_7 = val++;
exports.DEMON_BODY_LIGHTGREEN_8 = val++;
exports.DEMON_BODY_LIGHTGREEN_9 = val++;
exports.DEMON_BODY_LIGHTGREEN_10 = val++;
exports.DEMON_BODY_LIGHTGREEN_11 = val++;
exports.DEMON_BODY_LIGHTGREEN_12 = val++;
exports.DEMON_BODY_LIGHTCYAN = val++;
exports.DEMON_BODY_LIGHTCYAN_1 = val++;
exports.DEMON_BODY_LIGHTCYAN_2 = val++;
exports.DEMON_BODY_LIGHTCYAN_3 = val++;
exports.DEMON_BODY_LIGHTCYAN_4 = val++;
exports.DEMON_BODY_LIGHTCYAN_5 = val++;
exports.DEMON_BODY_LIGHTCYAN_6 = val++;
exports.DEMON_BODY_LIGHTCYAN_7 = val++;
exports.DEMON_BODY_LIGHTCYAN_8 = val++;
exports.DEMON_BODY_LIGHTCYAN_9 = val++;
exports.DEMON_BODY_LIGHTCYAN_10 = val++;
exports.DEMON_BODY_LIGHTCYAN_11 = val++;
exports.DEMON_BODY_LIGHTCYAN_12 = val++;
exports.DEMON_BODY_LIGHTMAGENTA = val++;
exports.DEMON_BODY_LIGHTMAGENTA_1 = val++;
exports.DEMON_BODY_LIGHTMAGENTA_2 = val++;
exports.DEMON_BODY_LIGHTMAGENTA_3 = val++;
exports.DEMON_BODY_LIGHTMAGENTA_4 = val++;
exports.DEMON_BODY_LIGHTMAGENTA_5 = val++;
exports.DEMON_BODY_LIGHTMAGENTA_6 = val++;
exports.DEMON_BODY_LIGHTMAGENTA_7 = val++;
exports.DEMON_BODY_LIGHTMAGENTA_8 = val++;
exports.DEMON_BODY_LIGHTMAGENTA_9 = val++;
exports.DEMON_BODY_LIGHTMAGENTA_10 = val++;
exports.DEMON_BODY_LIGHTMAGENTA_11 = val++;
exports.DEMON_BODY_LIGHTMAGENTA_12 = val++;
exports.DEMON_BODY_YELLOW = val++;
exports.DEMON_BODY_YELLOW_1 = val++;
exports.DEMON_BODY_YELLOW_2 = val++;
exports.DEMON_BODY_YELLOW_3 = val++;
exports.DEMON_BODY_YELLOW_4 = val++;
exports.DEMON_BODY_YELLOW_5 = val++;
exports.DEMON_BODY_YELLOW_6 = val++;
exports.DEMON_BODY_YELLOW_7 = val++;
exports.DEMON_BODY_YELLOW_8 = val++;
exports.DEMON_BODY_YELLOW_9 = val++;
exports.DEMON_BODY_YELLOW_10 = val++;
exports.DEMON_BODY_YELLOW_11 = val++;
exports.DEMON_BODY_YELLOW_12 = val++;
exports.DEMON_BODY_WHITE = val++;
exports.DEMON_BODY_WHITE_1 = val++;
exports.DEMON_BODY_WHITE_2 = val++;
exports.DEMON_BODY_WHITE_3 = val++;
exports.DEMON_BODY_WHITE_4 = val++;
exports.DEMON_BODY_WHITE_5 = val++;
exports.DEMON_BODY_WHITE_6 = val++;
exports.DEMON_BODY_WHITE_7 = val++;
exports.DEMON_BODY_WHITE_8 = val++;
exports.DEMON_BODY_WHITE_9 = val++;
exports.DEMON_BODY_WHITE_10 = val++;
exports.DEMON_BODY_WHITE_11 = val++;
exports.DEMON_BODY_WHITE_12 = val++;
exports.DEMON_HEAD = val++;
val = exports.DEMON_HEAD_CYAN = exports.DEMON_HEAD; val++;
exports.DEMON_HEAD_1 = val++;
exports.DEMON_HEAD_2 = val++;
exports.DEMON_HEAD_3 = val++;
exports.DEMON_HEAD_4 = val++;
exports.DEMON_HEAD_5 = val++;
exports.DEMON_HEAD_6 = val++;
exports.DEMON_HEAD_7 = val++;
exports.DEMON_HEAD_8 = val++;
exports.DEMON_HEAD_9 = val++;
exports.DEMON_HEAD_10 = val++;
exports.DEMON_HEAD_11 = val++;
exports.DEMON_HEAD_12 = val++;
exports.DEMON_HEAD_13 = val++;
exports.DEMON_HEAD_14 = val++;
exports.DEMON_HEAD_15 = val++;
exports.DEMON_HEAD_16 = val++;
exports.DEMON_HEAD_17 = val++;
exports.DEMON_HEAD_18 = val++;
exports.DEMON_HEAD_19 = val++;
exports.DEMON_HEAD_20 = val++;
exports.DEMON_HEAD_21 = val++;
exports.DEMON_HEAD_22 = val++;
exports.DEMON_HEAD_23 = val++;
exports.DEMON_HEAD_24 = val++;
exports.DEMON_HEAD_25 = val++;
exports.DEMON_HEAD_26 = val++;
exports.DEMON_HEAD_RED = val++;
exports.DEMON_HEAD_RED_1 = val++;
exports.DEMON_HEAD_RED_2 = val++;
exports.DEMON_HEAD_RED_3 = val++;
exports.DEMON_HEAD_RED_4 = val++;
exports.DEMON_HEAD_RED_5 = val++;
exports.DEMON_HEAD_RED_6 = val++;
exports.DEMON_HEAD_RED_7 = val++;
exports.DEMON_HEAD_RED_8 = val++;
exports.DEMON_HEAD_RED_9 = val++;
exports.DEMON_HEAD_RED_10 = val++;
exports.DEMON_HEAD_RED_11 = val++;
exports.DEMON_HEAD_RED_12 = val++;
exports.DEMON_HEAD_RED_13 = val++;
exports.DEMON_HEAD_RED_14 = val++;
exports.DEMON_HEAD_RED_15 = val++;
exports.DEMON_HEAD_RED_16 = val++;
exports.DEMON_HEAD_RED_17 = val++;
exports.DEMON_HEAD_RED_18 = val++;
exports.DEMON_HEAD_RED_19 = val++;
exports.DEMON_HEAD_RED_20 = val++;
exports.DEMON_HEAD_RED_21 = val++;
exports.DEMON_HEAD_RED_22 = val++;
exports.DEMON_HEAD_RED_23 = val++;
exports.DEMON_HEAD_RED_24 = val++;
exports.DEMON_HEAD_RED_25 = val++;
exports.DEMON_HEAD_RED_26 = val++;
exports.DEMON_HEAD_BLUE = val++;
exports.DEMON_HEAD_BLUE_1 = val++;
exports.DEMON_HEAD_BLUE_2 = val++;
exports.DEMON_HEAD_BLUE_3 = val++;
exports.DEMON_HEAD_BLUE_4 = val++;
exports.DEMON_HEAD_BLUE_5 = val++;
exports.DEMON_HEAD_BLUE_6 = val++;
exports.DEMON_HEAD_BLUE_7 = val++;
exports.DEMON_HEAD_BLUE_8 = val++;
exports.DEMON_HEAD_BLUE_9 = val++;
exports.DEMON_HEAD_BLUE_10 = val++;
exports.DEMON_HEAD_BLUE_11 = val++;
exports.DEMON_HEAD_BLUE_12 = val++;
exports.DEMON_HEAD_BLUE_13 = val++;
exports.DEMON_HEAD_BLUE_14 = val++;
exports.DEMON_HEAD_BLUE_15 = val++;
exports.DEMON_HEAD_BLUE_16 = val++;
exports.DEMON_HEAD_BLUE_17 = val++;
exports.DEMON_HEAD_BLUE_18 = val++;
exports.DEMON_HEAD_BLUE_19 = val++;
exports.DEMON_HEAD_BLUE_20 = val++;
exports.DEMON_HEAD_BLUE_21 = val++;
exports.DEMON_HEAD_BLUE_22 = val++;
exports.DEMON_HEAD_BLUE_23 = val++;
exports.DEMON_HEAD_BLUE_24 = val++;
exports.DEMON_HEAD_BLUE_25 = val++;
exports.DEMON_HEAD_BLUE_26 = val++;
exports.DEMON_HEAD_GREEN = val++;
exports.DEMON_HEAD_GREEN_1 = val++;
exports.DEMON_HEAD_GREEN_2 = val++;
exports.DEMON_HEAD_GREEN_3 = val++;
exports.DEMON_HEAD_GREEN_4 = val++;
exports.DEMON_HEAD_GREEN_5 = val++;
exports.DEMON_HEAD_GREEN_6 = val++;
exports.DEMON_HEAD_GREEN_7 = val++;
exports.DEMON_HEAD_GREEN_8 = val++;
exports.DEMON_HEAD_GREEN_9 = val++;
exports.DEMON_HEAD_GREEN_10 = val++;
exports.DEMON_HEAD_GREEN_11 = val++;
exports.DEMON_HEAD_GREEN_12 = val++;
exports.DEMON_HEAD_GREEN_13 = val++;
exports.DEMON_HEAD_GREEN_14 = val++;
exports.DEMON_HEAD_GREEN_15 = val++;
exports.DEMON_HEAD_GREEN_16 = val++;
exports.DEMON_HEAD_GREEN_17 = val++;
exports.DEMON_HEAD_GREEN_18 = val++;
exports.DEMON_HEAD_GREEN_19 = val++;
exports.DEMON_HEAD_GREEN_20 = val++;
exports.DEMON_HEAD_GREEN_21 = val++;
exports.DEMON_HEAD_GREEN_22 = val++;
exports.DEMON_HEAD_GREEN_23 = val++;
exports.DEMON_HEAD_GREEN_24 = val++;
exports.DEMON_HEAD_GREEN_25 = val++;
exports.DEMON_HEAD_GREEN_26 = val++;
exports.DEMON_HEAD_MAGENTA = val++;
exports.DEMON_HEAD_MAGENTA_1 = val++;
exports.DEMON_HEAD_MAGENTA_2 = val++;
exports.DEMON_HEAD_MAGENTA_3 = val++;
exports.DEMON_HEAD_MAGENTA_4 = val++;
exports.DEMON_HEAD_MAGENTA_5 = val++;
exports.DEMON_HEAD_MAGENTA_6 = val++;
exports.DEMON_HEAD_MAGENTA_7 = val++;
exports.DEMON_HEAD_MAGENTA_8 = val++;
exports.DEMON_HEAD_MAGENTA_9 = val++;
exports.DEMON_HEAD_MAGENTA_10 = val++;
exports.DEMON_HEAD_MAGENTA_11 = val++;
exports.DEMON_HEAD_MAGENTA_12 = val++;
exports.DEMON_HEAD_MAGENTA_13 = val++;
exports.DEMON_HEAD_MAGENTA_14 = val++;
exports.DEMON_HEAD_MAGENTA_15 = val++;
exports.DEMON_HEAD_MAGENTA_16 = val++;
exports.DEMON_HEAD_MAGENTA_17 = val++;
exports.DEMON_HEAD_MAGENTA_18 = val++;
exports.DEMON_HEAD_MAGENTA_19 = val++;
exports.DEMON_HEAD_MAGENTA_20 = val++;
exports.DEMON_HEAD_MAGENTA_21 = val++;
exports.DEMON_HEAD_MAGENTA_22 = val++;
exports.DEMON_HEAD_MAGENTA_23 = val++;
exports.DEMON_HEAD_MAGENTA_24 = val++;
exports.DEMON_HEAD_MAGENTA_25 = val++;
exports.DEMON_HEAD_MAGENTA_26 = val++;
exports.DEMON_HEAD_BROWN = val++;
exports.DEMON_HEAD_BROWN_1 = val++;
exports.DEMON_HEAD_BROWN_2 = val++;
exports.DEMON_HEAD_BROWN_3 = val++;
exports.DEMON_HEAD_BROWN_4 = val++;
exports.DEMON_HEAD_BROWN_5 = val++;
exports.DEMON_HEAD_BROWN_6 = val++;
exports.DEMON_HEAD_BROWN_7 = val++;
exports.DEMON_HEAD_BROWN_8 = val++;
exports.DEMON_HEAD_BROWN_9 = val++;
exports.DEMON_HEAD_BROWN_10 = val++;
exports.DEMON_HEAD_BROWN_11 = val++;
exports.DEMON_HEAD_BROWN_12 = val++;
exports.DEMON_HEAD_BROWN_13 = val++;
exports.DEMON_HEAD_BROWN_14 = val++;
exports.DEMON_HEAD_BROWN_15 = val++;
exports.DEMON_HEAD_BROWN_16 = val++;
exports.DEMON_HEAD_BROWN_17 = val++;
exports.DEMON_HEAD_BROWN_18 = val++;
exports.DEMON_HEAD_BROWN_19 = val++;
exports.DEMON_HEAD_BROWN_20 = val++;
exports.DEMON_HEAD_BROWN_21 = val++;
exports.DEMON_HEAD_BROWN_22 = val++;
exports.DEMON_HEAD_BROWN_23 = val++;
exports.DEMON_HEAD_BROWN_24 = val++;
exports.DEMON_HEAD_BROWN_25 = val++;
exports.DEMON_HEAD_BROWN_26 = val++;
exports.DEMON_HEAD_LIGHTGRAY = val++;
exports.DEMON_HEAD_LIGHTGRAY_1 = val++;
exports.DEMON_HEAD_LIGHTGRAY_2 = val++;
exports.DEMON_HEAD_LIGHTGRAY_3 = val++;
exports.DEMON_HEAD_LIGHTGRAY_4 = val++;
exports.DEMON_HEAD_LIGHTGRAY_5 = val++;
exports.DEMON_HEAD_LIGHTGRAY_6 = val++;
exports.DEMON_HEAD_LIGHTGRAY_7 = val++;
exports.DEMON_HEAD_LIGHTGRAY_8 = val++;
exports.DEMON_HEAD_LIGHTGRAY_9 = val++;
exports.DEMON_HEAD_LIGHTGRAY_10 = val++;
exports.DEMON_HEAD_LIGHTGRAY_11 = val++;
exports.DEMON_HEAD_LIGHTGRAY_12 = val++;
exports.DEMON_HEAD_LIGHTGRAY_13 = val++;
exports.DEMON_HEAD_LIGHTGRAY_14 = val++;
exports.DEMON_HEAD_LIGHTGRAY_15 = val++;
exports.DEMON_HEAD_LIGHTGRAY_16 = val++;
exports.DEMON_HEAD_LIGHTGRAY_17 = val++;
exports.DEMON_HEAD_LIGHTGRAY_18 = val++;
exports.DEMON_HEAD_LIGHTGRAY_19 = val++;
exports.DEMON_HEAD_LIGHTGRAY_20 = val++;
exports.DEMON_HEAD_LIGHTGRAY_21 = val++;
exports.DEMON_HEAD_LIGHTGRAY_22 = val++;
exports.DEMON_HEAD_LIGHTGRAY_23 = val++;
exports.DEMON_HEAD_LIGHTGRAY_24 = val++;
exports.DEMON_HEAD_LIGHTGRAY_25 = val++;
exports.DEMON_HEAD_LIGHTGRAY_26 = val++;
exports.DEMON_HEAD_DARKGRAY = val++;
exports.DEMON_HEAD_DARKGRAY_1 = val++;
exports.DEMON_HEAD_DARKGRAY_2 = val++;
exports.DEMON_HEAD_DARKGRAY_3 = val++;
exports.DEMON_HEAD_DARKGRAY_4 = val++;
exports.DEMON_HEAD_DARKGRAY_5 = val++;
exports.DEMON_HEAD_DARKGRAY_6 = val++;
exports.DEMON_HEAD_DARKGRAY_7 = val++;
exports.DEMON_HEAD_DARKGRAY_8 = val++;
exports.DEMON_HEAD_DARKGRAY_9 = val++;
exports.DEMON_HEAD_DARKGRAY_10 = val++;
exports.DEMON_HEAD_DARKGRAY_11 = val++;
exports.DEMON_HEAD_DARKGRAY_12 = val++;
exports.DEMON_HEAD_DARKGRAY_13 = val++;
exports.DEMON_HEAD_DARKGRAY_14 = val++;
exports.DEMON_HEAD_DARKGRAY_15 = val++;
exports.DEMON_HEAD_DARKGRAY_16 = val++;
exports.DEMON_HEAD_DARKGRAY_17 = val++;
exports.DEMON_HEAD_DARKGRAY_18 = val++;
exports.DEMON_HEAD_DARKGRAY_19 = val++;
exports.DEMON_HEAD_DARKGRAY_20 = val++;
exports.DEMON_HEAD_DARKGRAY_21 = val++;
exports.DEMON_HEAD_DARKGRAY_22 = val++;
exports.DEMON_HEAD_DARKGRAY_23 = val++;
exports.DEMON_HEAD_DARKGRAY_24 = val++;
exports.DEMON_HEAD_DARKGRAY_25 = val++;
exports.DEMON_HEAD_DARKGRAY_26 = val++;
exports.DEMON_HEAD_LIGHTRED = val++;
exports.DEMON_HEAD_LIGHTRED_1 = val++;
exports.DEMON_HEAD_LIGHTRED_2 = val++;
exports.DEMON_HEAD_LIGHTRED_3 = val++;
exports.DEMON_HEAD_LIGHTRED_4 = val++;
exports.DEMON_HEAD_LIGHTRED_5 = val++;
exports.DEMON_HEAD_LIGHTRED_6 = val++;
exports.DEMON_HEAD_LIGHTRED_7 = val++;
exports.DEMON_HEAD_LIGHTRED_8 = val++;
exports.DEMON_HEAD_LIGHTRED_9 = val++;
exports.DEMON_HEAD_LIGHTRED_10 = val++;
exports.DEMON_HEAD_LIGHTRED_11 = val++;
exports.DEMON_HEAD_LIGHTRED_12 = val++;
exports.DEMON_HEAD_LIGHTRED_13 = val++;
exports.DEMON_HEAD_LIGHTRED_14 = val++;
exports.DEMON_HEAD_LIGHTRED_15 = val++;
exports.DEMON_HEAD_LIGHTRED_16 = val++;
exports.DEMON_HEAD_LIGHTRED_17 = val++;
exports.DEMON_HEAD_LIGHTRED_18 = val++;
exports.DEMON_HEAD_LIGHTRED_19 = val++;
exports.DEMON_HEAD_LIGHTRED_20 = val++;
exports.DEMON_HEAD_LIGHTRED_21 = val++;
exports.DEMON_HEAD_LIGHTRED_22 = val++;
exports.DEMON_HEAD_LIGHTRED_23 = val++;
exports.DEMON_HEAD_LIGHTRED_24 = val++;
exports.DEMON_HEAD_LIGHTRED_25 = val++;
exports.DEMON_HEAD_LIGHTRED_26 = val++;
exports.DEMON_HEAD_LIGHTBLUE = val++;
exports.DEMON_HEAD_LIGHTBLUE_1 = val++;
exports.DEMON_HEAD_LIGHTBLUE_2 = val++;
exports.DEMON_HEAD_LIGHTBLUE_3 = val++;
exports.DEMON_HEAD_LIGHTBLUE_4 = val++;
exports.DEMON_HEAD_LIGHTBLUE_5 = val++;
exports.DEMON_HEAD_LIGHTBLUE_6 = val++;
exports.DEMON_HEAD_LIGHTBLUE_7 = val++;
exports.DEMON_HEAD_LIGHTBLUE_8 = val++;
exports.DEMON_HEAD_LIGHTBLUE_9 = val++;
exports.DEMON_HEAD_LIGHTBLUE_10 = val++;
exports.DEMON_HEAD_LIGHTBLUE_11 = val++;
exports.DEMON_HEAD_LIGHTBLUE_12 = val++;
exports.DEMON_HEAD_LIGHTBLUE_13 = val++;
exports.DEMON_HEAD_LIGHTBLUE_14 = val++;
exports.DEMON_HEAD_LIGHTBLUE_15 = val++;
exports.DEMON_HEAD_LIGHTBLUE_16 = val++;
exports.DEMON_HEAD_LIGHTBLUE_17 = val++;
exports.DEMON_HEAD_LIGHTBLUE_18 = val++;
exports.DEMON_HEAD_LIGHTBLUE_19 = val++;
exports.DEMON_HEAD_LIGHTBLUE_20 = val++;
exports.DEMON_HEAD_LIGHTBLUE_21 = val++;
exports.DEMON_HEAD_LIGHTBLUE_22 = val++;
exports.DEMON_HEAD_LIGHTBLUE_23 = val++;
exports.DEMON_HEAD_LIGHTBLUE_24 = val++;
exports.DEMON_HEAD_LIGHTBLUE_25 = val++;
exports.DEMON_HEAD_LIGHTBLUE_26 = val++;
exports.DEMON_HEAD_LIGHTGREEN = val++;
exports.DEMON_HEAD_LIGHTGREEN_1 = val++;
exports.DEMON_HEAD_LIGHTGREEN_2 = val++;
exports.DEMON_HEAD_LIGHTGREEN_3 = val++;
exports.DEMON_HEAD_LIGHTGREEN_4 = val++;
exports.DEMON_HEAD_LIGHTGREEN_5 = val++;
exports.DEMON_HEAD_LIGHTGREEN_6 = val++;
exports.DEMON_HEAD_LIGHTGREEN_7 = val++;
exports.DEMON_HEAD_LIGHTGREEN_8 = val++;
exports.DEMON_HEAD_LIGHTGREEN_9 = val++;
exports.DEMON_HEAD_LIGHTGREEN_10 = val++;
exports.DEMON_HEAD_LIGHTGREEN_11 = val++;
exports.DEMON_HEAD_LIGHTGREEN_12 = val++;
exports.DEMON_HEAD_LIGHTGREEN_13 = val++;
exports.DEMON_HEAD_LIGHTGREEN_14 = val++;
exports.DEMON_HEAD_LIGHTGREEN_15 = val++;
exports.DEMON_HEAD_LIGHTGREEN_16 = val++;
exports.DEMON_HEAD_LIGHTGREEN_17 = val++;
exports.DEMON_HEAD_LIGHTGREEN_18 = val++;
exports.DEMON_HEAD_LIGHTGREEN_19 = val++;
exports.DEMON_HEAD_LIGHTGREEN_20 = val++;
exports.DEMON_HEAD_LIGHTGREEN_21 = val++;
exports.DEMON_HEAD_LIGHTGREEN_22 = val++;
exports.DEMON_HEAD_LIGHTGREEN_23 = val++;
exports.DEMON_HEAD_LIGHTGREEN_24 = val++;
exports.DEMON_HEAD_LIGHTGREEN_25 = val++;
exports.DEMON_HEAD_LIGHTGREEN_26 = val++;
exports.DEMON_HEAD_LIGHTCYAN = val++;
exports.DEMON_HEAD_LIGHTCYAN_1 = val++;
exports.DEMON_HEAD_LIGHTCYAN_2 = val++;
exports.DEMON_HEAD_LIGHTCYAN_3 = val++;
exports.DEMON_HEAD_LIGHTCYAN_4 = val++;
exports.DEMON_HEAD_LIGHTCYAN_5 = val++;
exports.DEMON_HEAD_LIGHTCYAN_6 = val++;
exports.DEMON_HEAD_LIGHTCYAN_7 = val++;
exports.DEMON_HEAD_LIGHTCYAN_8 = val++;
exports.DEMON_HEAD_LIGHTCYAN_9 = val++;
exports.DEMON_HEAD_LIGHTCYAN_10 = val++;
exports.DEMON_HEAD_LIGHTCYAN_11 = val++;
exports.DEMON_HEAD_LIGHTCYAN_12 = val++;
exports.DEMON_HEAD_LIGHTCYAN_13 = val++;
exports.DEMON_HEAD_LIGHTCYAN_14 = val++;
exports.DEMON_HEAD_LIGHTCYAN_15 = val++;
exports.DEMON_HEAD_LIGHTCYAN_16 = val++;
exports.DEMON_HEAD_LIGHTCYAN_17 = val++;
exports.DEMON_HEAD_LIGHTCYAN_18 = val++;
exports.DEMON_HEAD_LIGHTCYAN_19 = val++;
exports.DEMON_HEAD_LIGHTCYAN_20 = val++;
exports.DEMON_HEAD_LIGHTCYAN_21 = val++;
exports.DEMON_HEAD_LIGHTCYAN_22 = val++;
exports.DEMON_HEAD_LIGHTCYAN_23 = val++;
exports.DEMON_HEAD_LIGHTCYAN_24 = val++;
exports.DEMON_HEAD_LIGHTCYAN_25 = val++;
exports.DEMON_HEAD_LIGHTCYAN_26 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_1 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_2 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_3 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_4 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_5 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_6 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_7 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_8 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_9 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_10 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_11 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_12 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_13 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_14 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_15 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_16 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_17 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_18 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_19 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_20 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_21 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_22 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_23 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_24 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_25 = val++;
exports.DEMON_HEAD_LIGHTMAGENTA_26 = val++;
exports.DEMON_HEAD_YELLOW = val++;
exports.DEMON_HEAD_YELLOW_1 = val++;
exports.DEMON_HEAD_YELLOW_2 = val++;
exports.DEMON_HEAD_YELLOW_3 = val++;
exports.DEMON_HEAD_YELLOW_4 = val++;
exports.DEMON_HEAD_YELLOW_5 = val++;
exports.DEMON_HEAD_YELLOW_6 = val++;
exports.DEMON_HEAD_YELLOW_7 = val++;
exports.DEMON_HEAD_YELLOW_8 = val++;
exports.DEMON_HEAD_YELLOW_9 = val++;
exports.DEMON_HEAD_YELLOW_10 = val++;
exports.DEMON_HEAD_YELLOW_11 = val++;
exports.DEMON_HEAD_YELLOW_12 = val++;
exports.DEMON_HEAD_YELLOW_13 = val++;
exports.DEMON_HEAD_YELLOW_14 = val++;
exports.DEMON_HEAD_YELLOW_15 = val++;
exports.DEMON_HEAD_YELLOW_16 = val++;
exports.DEMON_HEAD_YELLOW_17 = val++;
exports.DEMON_HEAD_YELLOW_18 = val++;
exports.DEMON_HEAD_YELLOW_19 = val++;
exports.DEMON_HEAD_YELLOW_20 = val++;
exports.DEMON_HEAD_YELLOW_21 = val++;
exports.DEMON_HEAD_YELLOW_22 = val++;
exports.DEMON_HEAD_YELLOW_23 = val++;
exports.DEMON_HEAD_YELLOW_24 = val++;
exports.DEMON_HEAD_YELLOW_25 = val++;
exports.DEMON_HEAD_YELLOW_26 = val++;
exports.DEMON_HEAD_WHITE = val++;
exports.DEMON_HEAD_WHITE_1 = val++;
exports.DEMON_HEAD_WHITE_2 = val++;
exports.DEMON_HEAD_WHITE_3 = val++;
exports.DEMON_HEAD_WHITE_4 = val++;
exports.DEMON_HEAD_WHITE_5 = val++;
exports.DEMON_HEAD_WHITE_6 = val++;
exports.DEMON_HEAD_WHITE_7 = val++;
exports.DEMON_HEAD_WHITE_8 = val++;
exports.DEMON_HEAD_WHITE_9 = val++;
exports.DEMON_HEAD_WHITE_10 = val++;
exports.DEMON_HEAD_WHITE_11 = val++;
exports.DEMON_HEAD_WHITE_12 = val++;
exports.DEMON_HEAD_WHITE_13 = val++;
exports.DEMON_HEAD_WHITE_14 = val++;
exports.DEMON_HEAD_WHITE_15 = val++;
exports.DEMON_HEAD_WHITE_16 = val++;
exports.DEMON_HEAD_WHITE_17 = val++;
exports.DEMON_HEAD_WHITE_18 = val++;
exports.DEMON_HEAD_WHITE_19 = val++;
exports.DEMON_HEAD_WHITE_20 = val++;
exports.DEMON_HEAD_WHITE_21 = val++;
exports.DEMON_HEAD_WHITE_22 = val++;
exports.DEMON_HEAD_WHITE_23 = val++;
exports.DEMON_HEAD_WHITE_24 = val++;
exports.DEMON_HEAD_WHITE_25 = val++;
exports.DEMON_HEAD_WHITE_26 = val++;
exports.DEMON_WINGS = val++;
val = exports.DEMON_WINGS_CYAN = exports.DEMON_WINGS; val++;
exports.DEMON_WINGS_1 = val++;
exports.DEMON_WINGS_2 = val++;
exports.DEMON_WINGS_3 = val++;
exports.DEMON_WINGS_4 = val++;
exports.DEMON_WINGS_5 = val++;
exports.DEMON_WINGS_6 = val++;
exports.DEMON_WINGS_7 = val++;
exports.DEMON_WINGS_8 = val++;
exports.DEMON_WINGS_9 = val++;
exports.DEMON_WINGS_10 = val++;
exports.DEMON_WINGS_11 = val++;
exports.DEMON_WINGS_12 = val++;
exports.DEMON_WINGS_RED = val++;
exports.DEMON_WINGS_RED_1 = val++;
exports.DEMON_WINGS_RED_2 = val++;
exports.DEMON_WINGS_RED_3 = val++;
exports.DEMON_WINGS_RED_4 = val++;
exports.DEMON_WINGS_RED_5 = val++;
exports.DEMON_WINGS_RED_6 = val++;
exports.DEMON_WINGS_RED_7 = val++;
exports.DEMON_WINGS_RED_8 = val++;
exports.DEMON_WINGS_RED_9 = val++;
exports.DEMON_WINGS_RED_10 = val++;
exports.DEMON_WINGS_RED_11 = val++;
exports.DEMON_WINGS_RED_12 = val++;
exports.DEMON_WINGS_BLUE = val++;
exports.DEMON_WINGS_BLUE_1 = val++;
exports.DEMON_WINGS_BLUE_2 = val++;
exports.DEMON_WINGS_BLUE_3 = val++;
exports.DEMON_WINGS_BLUE_4 = val++;
exports.DEMON_WINGS_BLUE_5 = val++;
exports.DEMON_WINGS_BLUE_6 = val++;
exports.DEMON_WINGS_BLUE_7 = val++;
exports.DEMON_WINGS_BLUE_8 = val++;
exports.DEMON_WINGS_BLUE_9 = val++;
exports.DEMON_WINGS_BLUE_10 = val++;
exports.DEMON_WINGS_BLUE_11 = val++;
exports.DEMON_WINGS_BLUE_12 = val++;
exports.DEMON_WINGS_GREEN = val++;
exports.DEMON_WINGS_GREEN_1 = val++;
exports.DEMON_WINGS_GREEN_2 = val++;
exports.DEMON_WINGS_GREEN_3 = val++;
exports.DEMON_WINGS_GREEN_4 = val++;
exports.DEMON_WINGS_GREEN_5 = val++;
exports.DEMON_WINGS_GREEN_6 = val++;
exports.DEMON_WINGS_GREEN_7 = val++;
exports.DEMON_WINGS_GREEN_8 = val++;
exports.DEMON_WINGS_GREEN_9 = val++;
exports.DEMON_WINGS_GREEN_10 = val++;
exports.DEMON_WINGS_GREEN_11 = val++;
exports.DEMON_WINGS_GREEN_12 = val++;
exports.DEMON_WINGS_MAGENTA = val++;
exports.DEMON_WINGS_MAGENTA_1 = val++;
exports.DEMON_WINGS_MAGENTA_2 = val++;
exports.DEMON_WINGS_MAGENTA_3 = val++;
exports.DEMON_WINGS_MAGENTA_4 = val++;
exports.DEMON_WINGS_MAGENTA_5 = val++;
exports.DEMON_WINGS_MAGENTA_6 = val++;
exports.DEMON_WINGS_MAGENTA_7 = val++;
exports.DEMON_WINGS_MAGENTA_8 = val++;
exports.DEMON_WINGS_MAGENTA_9 = val++;
exports.DEMON_WINGS_MAGENTA_10 = val++;
exports.DEMON_WINGS_MAGENTA_11 = val++;
exports.DEMON_WINGS_MAGENTA_12 = val++;
exports.DEMON_WINGS_BROWN = val++;
exports.DEMON_WINGS_BROWN_1 = val++;
exports.DEMON_WINGS_BROWN_2 = val++;
exports.DEMON_WINGS_BROWN_3 = val++;
exports.DEMON_WINGS_BROWN_4 = val++;
exports.DEMON_WINGS_BROWN_5 = val++;
exports.DEMON_WINGS_BROWN_6 = val++;
exports.DEMON_WINGS_BROWN_7 = val++;
exports.DEMON_WINGS_BROWN_8 = val++;
exports.DEMON_WINGS_BROWN_9 = val++;
exports.DEMON_WINGS_BROWN_10 = val++;
exports.DEMON_WINGS_BROWN_11 = val++;
exports.DEMON_WINGS_BROWN_12 = val++;
exports.DEMON_WINGS_LIGHTGRAY = val++;
exports.DEMON_WINGS_LIGHTGRAY_1 = val++;
exports.DEMON_WINGS_LIGHTGRAY_2 = val++;
exports.DEMON_WINGS_LIGHTGRAY_3 = val++;
exports.DEMON_WINGS_LIGHTGRAY_4 = val++;
exports.DEMON_WINGS_LIGHTGRAY_5 = val++;
exports.DEMON_WINGS_LIGHTGRAY_6 = val++;
exports.DEMON_WINGS_LIGHTGRAY_7 = val++;
exports.DEMON_WINGS_LIGHTGRAY_8 = val++;
exports.DEMON_WINGS_LIGHTGRAY_9 = val++;
exports.DEMON_WINGS_LIGHTGRAY_10 = val++;
exports.DEMON_WINGS_LIGHTGRAY_11 = val++;
exports.DEMON_WINGS_LIGHTGRAY_12 = val++;
exports.DEMON_WINGS_DARKGRAY = val++;
exports.DEMON_WINGS_DARKGRAY_1 = val++;
exports.DEMON_WINGS_DARKGRAY_2 = val++;
exports.DEMON_WINGS_DARKGRAY_3 = val++;
exports.DEMON_WINGS_DARKGRAY_4 = val++;
exports.DEMON_WINGS_DARKGRAY_5 = val++;
exports.DEMON_WINGS_DARKGRAY_6 = val++;
exports.DEMON_WINGS_DARKGRAY_7 = val++;
exports.DEMON_WINGS_DARKGRAY_8 = val++;
exports.DEMON_WINGS_DARKGRAY_9 = val++;
exports.DEMON_WINGS_DARKGRAY_10 = val++;
exports.DEMON_WINGS_DARKGRAY_11 = val++;
exports.DEMON_WINGS_DARKGRAY_12 = val++;
exports.DEMON_WINGS_LIGHTRED = val++;
exports.DEMON_WINGS_LIGHTRED_1 = val++;
exports.DEMON_WINGS_LIGHTRED_2 = val++;
exports.DEMON_WINGS_LIGHTRED_3 = val++;
exports.DEMON_WINGS_LIGHTRED_4 = val++;
exports.DEMON_WINGS_LIGHTRED_5 = val++;
exports.DEMON_WINGS_LIGHTRED_6 = val++;
exports.DEMON_WINGS_LIGHTRED_7 = val++;
exports.DEMON_WINGS_LIGHTRED_8 = val++;
exports.DEMON_WINGS_LIGHTRED_9 = val++;
exports.DEMON_WINGS_LIGHTRED_10 = val++;
exports.DEMON_WINGS_LIGHTRED_11 = val++;
exports.DEMON_WINGS_LIGHTRED_12 = val++;
exports.DEMON_WINGS_LIGHTBLUE = val++;
exports.DEMON_WINGS_LIGHTBLUE_1 = val++;
exports.DEMON_WINGS_LIGHTBLUE_2 = val++;
exports.DEMON_WINGS_LIGHTBLUE_3 = val++;
exports.DEMON_WINGS_LIGHTBLUE_4 = val++;
exports.DEMON_WINGS_LIGHTBLUE_5 = val++;
exports.DEMON_WINGS_LIGHTBLUE_6 = val++;
exports.DEMON_WINGS_LIGHTBLUE_7 = val++;
exports.DEMON_WINGS_LIGHTBLUE_8 = val++;
exports.DEMON_WINGS_LIGHTBLUE_9 = val++;
exports.DEMON_WINGS_LIGHTBLUE_10 = val++;
exports.DEMON_WINGS_LIGHTBLUE_11 = val++;
exports.DEMON_WINGS_LIGHTBLUE_12 = val++;
exports.DEMON_WINGS_LIGHTGREEN = val++;
exports.DEMON_WINGS_LIGHTGREEN_1 = val++;
exports.DEMON_WINGS_LIGHTGREEN_2 = val++;
exports.DEMON_WINGS_LIGHTGREEN_3 = val++;
exports.DEMON_WINGS_LIGHTGREEN_4 = val++;
exports.DEMON_WINGS_LIGHTGREEN_5 = val++;
exports.DEMON_WINGS_LIGHTGREEN_6 = val++;
exports.DEMON_WINGS_LIGHTGREEN_7 = val++;
exports.DEMON_WINGS_LIGHTGREEN_8 = val++;
exports.DEMON_WINGS_LIGHTGREEN_9 = val++;
exports.DEMON_WINGS_LIGHTGREEN_10 = val++;
exports.DEMON_WINGS_LIGHTGREEN_11 = val++;
exports.DEMON_WINGS_LIGHTGREEN_12 = val++;
exports.DEMON_WINGS_LIGHTCYAN = val++;
exports.DEMON_WINGS_LIGHTCYAN_1 = val++;
exports.DEMON_WINGS_LIGHTCYAN_2 = val++;
exports.DEMON_WINGS_LIGHTCYAN_3 = val++;
exports.DEMON_WINGS_LIGHTCYAN_4 = val++;
exports.DEMON_WINGS_LIGHTCYAN_5 = val++;
exports.DEMON_WINGS_LIGHTCYAN_6 = val++;
exports.DEMON_WINGS_LIGHTCYAN_7 = val++;
exports.DEMON_WINGS_LIGHTCYAN_8 = val++;
exports.DEMON_WINGS_LIGHTCYAN_9 = val++;
exports.DEMON_WINGS_LIGHTCYAN_10 = val++;
exports.DEMON_WINGS_LIGHTCYAN_11 = val++;
exports.DEMON_WINGS_LIGHTCYAN_12 = val++;
exports.DEMON_WINGS_LIGHTMAGENTA = val++;
exports.DEMON_WINGS_LIGHTMAGENTA_1 = val++;
exports.DEMON_WINGS_LIGHTMAGENTA_2 = val++;
exports.DEMON_WINGS_LIGHTMAGENTA_3 = val++;
exports.DEMON_WINGS_LIGHTMAGENTA_4 = val++;
exports.DEMON_WINGS_LIGHTMAGENTA_5 = val++;
exports.DEMON_WINGS_LIGHTMAGENTA_6 = val++;
exports.DEMON_WINGS_LIGHTMAGENTA_7 = val++;
exports.DEMON_WINGS_LIGHTMAGENTA_8 = val++;
exports.DEMON_WINGS_LIGHTMAGENTA_9 = val++;
exports.DEMON_WINGS_LIGHTMAGENTA_10 = val++;
exports.DEMON_WINGS_LIGHTMAGENTA_11 = val++;
exports.DEMON_WINGS_LIGHTMAGENTA_12 = val++;
exports.DEMON_WINGS_YELLOW = val++;
exports.DEMON_WINGS_YELLOW_1 = val++;
exports.DEMON_WINGS_YELLOW_2 = val++;
exports.DEMON_WINGS_YELLOW_3 = val++;
exports.DEMON_WINGS_YELLOW_4 = val++;
exports.DEMON_WINGS_YELLOW_5 = val++;
exports.DEMON_WINGS_YELLOW_6 = val++;
exports.DEMON_WINGS_YELLOW_7 = val++;
exports.DEMON_WINGS_YELLOW_8 = val++;
exports.DEMON_WINGS_YELLOW_9 = val++;
exports.DEMON_WINGS_YELLOW_10 = val++;
exports.DEMON_WINGS_YELLOW_11 = val++;
exports.DEMON_WINGS_YELLOW_12 = val++;
exports.DEMON_WINGS_WHITE = val++;
exports.DEMON_WINGS_WHITE_1 = val++;
exports.DEMON_WINGS_WHITE_2 = val++;
exports.DEMON_WINGS_WHITE_3 = val++;
exports.DEMON_WINGS_WHITE_4 = val++;
exports.DEMON_WINGS_WHITE_5 = val++;
exports.DEMON_WINGS_WHITE_6 = val++;
exports.DEMON_WINGS_WHITE_7 = val++;
exports.DEMON_WINGS_WHITE_8 = val++;
exports.DEMON_WINGS_WHITE_9 = val++;
exports.DEMON_WINGS_WHITE_10 = val++;
exports.DEMON_WINGS_WHITE_11 = val++;
exports.DEMON_WINGS_WHITE_12 = val++;
exports.MONS_PANDEMONIUM_LORD = val++;
exports.MONS_PROGRAM_BUG = val++;
exports.MONS_ASMODEUS = val++;
exports.MONS_CEREBOV = val++;
exports.MONS_CEREBOV_SWORDLESS = val++;
exports.MONS_DISPATER = val++;
exports.MONS_ERESHKIGAL = val++;
exports.MONS_GLOORX_VLOQ = val++;
exports.MONS_LOM_LOBON = val++;
exports.MONS_MNOLEG = val++;
exports.MONS_ANTAEUS = val++;
exports.MONS_LERNAEAN_HYDRA = val++;
exports.MONS_LERNAEAN_HYDRA_1 = val++;
exports.MONS_LERNAEAN_HYDRA_2 = val++;
exports.MONS_LERNAEAN_HYDRA_3 = val++;
exports.MONS_LERNAEAN_HYDRA_4 = val++;
exports.MONS_LERNAEAN_HYDRA_5 = val++;
exports.MONS_LERNAEAN_HYDRA_6 = val++;
exports.MONS_LERNAEAN_HYDRA_7 = val++;
exports.MONS_LERNAEAN_HYDRA_8 = val++;
exports.MONS_LERNAEAN_HYDRA_9 = val++;
exports.MONS_ROYAL_JELLY = val++;
exports.MONS_SERPENT_OF_HELL_GEHENNA = val++;
exports.MONS_SERPENT_OF_HELL_COCYTUS = val++;
exports.MONS_SERPENT_OF_HELL_DIS = val++;
exports.MONS_SERPENT_OF_HELL_TARTARUS = val++;
exports.MONS_SERAPH = val++;
exports.MONS_UNSPEAKABLE = val++;
exports.MONS_GIANT_COCKROACH = val++;
exports.MONS_WORKER_ANT = val++;
exports.MONS_SOLDIER_ANT = val++;
exports.MONS_QUEEN_ANT = val++;
exports.MONS_BAT = val++;
exports.MONS_VAMPIRE_BAT = val++;
exports.MONS_BUTTERFLY = val++;
exports.MONS_BUTTERFLY_1 = val++;
exports.MONS_BUTTERFLY_2 = val++;
exports.MONS_BUTTERFLY_3 = val++;
exports.MONS_BUTTERFLY_4 = val++;
exports.MONS_BUTTERFLY_5 = val++;
exports.MONS_BUTTERFLY_6 = val++;
exports.MONS_BUTTERFLY_7 = val++;
exports.MONS_BUTTERFLY_8 = val++;
exports.MONS_BUTTERFLY_9 = val++;
exports.MONS_BUTTERFLY_10 = val++;
exports.MONS_FIRE_BAT = val++;
exports.MONS_BENNU = val++;
exports.MONS_CAUSTIC_SHRIKE = val++;
exports.MONS_SHARD_SHRIKE = val++;
exports.MONS_MICROBAT = val++;
exports.MONS_MEGABAT = val++;
exports.MONS_GIGABAT = val++;
exports.MONS_PHASE_BAT = val++;
exports.MONS_JACKAL = val++;
exports.MONS_HOUND = val++;
exports.MONS_HOWLER_MONKEY = val++;
exports.MONS_WARG = val++;
exports.MONS_WOLF = val++;
exports.MONS_RAIJU = val++;
exports.MONS_HELL_HOUND = val++;
exports.MONS_DOOM_HOUND = val++;
exports.MONS_HOG = val++;
exports.MONS_HELL_HOG = val++;
exports.MONS_HOLY_SWINE = val++;
exports.MONS_FELID = val++;
exports.MONS_NATASHA = val++;
exports.MONS_KILLER_BEE = val++;
exports.MONS_QUEEN_BEE = val++;
exports.MONS_MELIAI = val++;
exports.MONS_FRILLED_LIZARD = val++;
exports.MONS_LEOPARD_GECKO = val++;
exports.MONS_IGUANA = val++;
exports.MONS_BASILISK = val++;
exports.MONS_KOMODO_DRAGON = val++;
exports.MONS_GASTRONOK = val++;
exports.MONS_RAT = val++;
exports.MONS_RIVER_RAT = val++;
exports.MONS_ORANGE_RAT = val++;
exports.MONS_PORCUPINE = val++;
exports.MONS_QUOKKA = val++;
exports.MONS_SCORPION = val++;
exports.MONS_EMPEROR_SCORPION = val++;
exports.MONS_TARANTELLA = val++;
exports.MONS_JUMPING_SPIDER = val++;
exports.MONS_WOLF_SPIDER = val++;
exports.MONS_REDBACK = val++;
exports.MONS_ORB_SPIDER = val++;
exports.MONS_DEMONIC_CRAWLER = val++;
exports.MONS_DEATH_SCARAB = val++;
exports.MONS_CROCODILE = val++;
exports.MONS_ALLIGATOR = val++;
exports.MONS_SNAPPING_TURTLE = val++;
exports.MONS_ALLIGATOR_SNAPPING_TURTLE = val++;
exports.MONS_FIRE_CRAB = val++;
exports.MONS_GHOST_CRAB = val++;
exports.MONS_SWAMP_WORM = val++;
exports.MONS_SWAMP_WORM_1 = val++;
exports.MONS_WORM = val++;
exports.MONS_TYRANT_LEECH = val++;
exports.MONS_DART_SLUG = val++;
exports.MONS_TORPOR_SNAIL = val++;
exports.MONS_VAMPIRE_MOSQUITO = val++;
exports.MONS_HORNET = val++;
exports.MONS_SPARK_WASP = val++;
exports.MONS_GHOST_MOTH = val++;
exports.MONS_MOTH_OF_WRATH = val++;
exports.MONS_ELECTRIC_EEL = val++;
exports.MONS_KRAKEN_HEAD = val++;
exports.MONS_KRAKEN_TENTACLE_WATER = val++;
val = exports.FIRST_TENTACLE_IN_WATER = exports.MONS_KRAKEN_TENTACLE_WATER; val++;
exports.MONS_KRAKEN_TENTACLE_WATER_1 = val++;
exports.MONS_KRAKEN_TENTACLE_WATER_2 = val++;
exports.MONS_KRAKEN_TENTACLE_WATER_3 = val++;
exports.MONS_KRAKEN_TENTACLE_WATER_4 = val++;
exports.MONS_KRAKEN_TENTACLE_WATER_5 = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_WATER = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_N = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_S = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_E = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_W = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_NE = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_NW = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_SE = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_SW = val++;
val = exports.LAST_TENTACLE_IN_WATER = exports.MONS_KRAKEN_TENTACLE_SEGMENT_SW; val++;
exports.MONS_KRAKEN_TENTACLE_N = val++;
exports.MONS_KRAKEN_TENTACLE_S = val++;
exports.MONS_KRAKEN_TENTACLE_E = val++;
exports.MONS_KRAKEN_TENTACLE_W = val++;
exports.MONS_KRAKEN_TENTACLE_NE = val++;
exports.MONS_KRAKEN_TENTACLE_NW = val++;
exports.MONS_KRAKEN_TENTACLE_SE = val++;
exports.MONS_KRAKEN_TENTACLE_SW = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_E_W = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_N_S = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_NE_SW = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_NW_SE = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_E_N = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_E_S = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_N_W = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_S_W = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_NE_NW = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_NE_SE = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_NW_SW = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_SE_SW = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_N_SE = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_N_SW = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_S_NE = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_S_NW = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_E_NW = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_E_SW = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_W_NE = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_W_SE = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_N_NW = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_N_NE = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_E_NE = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_E_SE = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_S_SE = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_S_SW = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_W_SW = val++;
exports.MONS_KRAKEN_TENTACLE_SEGMENT_W_NW = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_WATER = val++;
val = exports.FIRST_ZOMBIE_TENTACLE_IN_WATER = exports.MONS_KRAKEN_ZOMBIE_TENTACLE_WATER; val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_WATER_1 = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_WATER_2 = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_WATER_3 = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_WATER_4 = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_WATER_5 = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_WATER = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_N = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_S = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_E = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_W = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_NE = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_NW = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_SE = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_SW = val++;
val = exports.LAST_ZOMBIE_TENTACLE_IN_WATER = exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_SW; val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_N = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_S = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_E = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_W = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_NE = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_NW = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SE = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SW = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_E_W = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_N_S = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_NE_SW = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_NW_SE = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_E_N = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_E_S = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_N_W = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_S_W = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_NE_NW = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_NE_SE = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_NW_SW = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_SE_SW = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_N_SE = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_N_SW = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_S_NE = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_S_NW = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_E_NW = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_E_SW = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_W_NE = val++;
exports.MONS_KRAKEN_ZOMBIE_TENTACLE_SEGMENT_W_SE = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_WATER = val++;
val = exports.FIRST_SIMULACRUM_TENTACLE_IN_WATER = exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_WATER; val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_WATER_1 = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_WATER_2 = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_WATER_3 = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_WATER_4 = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_WATER_5 = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_WATER = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_N = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_S = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_E = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_W = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_NE = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_NW = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_SE = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_SW = val++;
val = exports.LAST_SIMULACRUM_TENTACLE_IN_WATER = exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_SW; val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_N = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_S = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_E = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_W = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_NE = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_NW = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SE = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SW = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_E_W = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_N_S = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_NE_SW = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_NW_SE = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_E_N = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_E_S = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_N_W = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_S_W = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_NE_NW = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_NE_SE = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_NW_SW = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_SE_SW = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_N_SE = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_N_SW = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_S_NE = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_S_NW = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_E_NW = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_E_SW = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_W_NE = val++;
exports.MONS_KRAKEN_SIMULACRUM_TENTACLE_SEGMENT_W_SE = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_WATER = val++;
val = exports.FIRST_SPECTRAL_TENTACLE_IN_WATER = exports.MONS_KRAKEN_SPECTRAL_TENTACLE_WATER; val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_WATER_1 = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_WATER_2 = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_WATER_3 = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_WATER_4 = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_WATER_5 = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_WATER = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_N = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_S = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_E = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_W = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_NE = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_NW = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_SE = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_SW = val++;
val = exports.LAST_SPECTRAL_TENTACLE_IN_WATER = exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_SW; val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_N = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_S = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_E = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_W = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_NE = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_NW = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SE = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SW = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_E_W = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_N_S = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_NE_SW = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_NW_SE = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_E_N = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_E_S = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_N_W = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_S_W = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_NE_NW = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_NE_SE = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_NW_SW = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_SE_SW = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_N_SE = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_N_SW = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_S_NE = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_S_NW = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_E_NW = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_E_SW = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_W_NE = val++;
exports.MONS_KRAKEN_SPECTRAL_TENTACLE_SEGMENT_W_SE = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_1 = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_2 = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_3 = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_4 = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_5 = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_6 = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_7 = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_8 = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_9 = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_N = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_S = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_E = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_W = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_NE = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_NW = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_SE = val++;
exports.MONS_ELDRITCH_TENTACLE_PORTAL_SW = val++;
exports.MONS_ELDRITCH_TENTACLE_N = val++;
exports.MONS_ELDRITCH_TENTACLE_S = val++;
exports.MONS_ELDRITCH_TENTACLE_E = val++;
exports.MONS_ELDRITCH_TENTACLE_W = val++;
exports.MONS_ELDRITCH_TENTACLE_NE = val++;
exports.MONS_ELDRITCH_TENTACLE_NW = val++;
exports.MONS_ELDRITCH_TENTACLE_SE = val++;
exports.MONS_ELDRITCH_TENTACLE_SW = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_E_W = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_N_S = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_NE_SW = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_NW_SE = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_E_N = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_E_S = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_N_W = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_S_W = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_NE_NW = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_NE_SE = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_NW_SW = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_SE_SW = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_N_SE = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_N_SW = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_S_NE = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_S_NW = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_E_NW = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_E_SW = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_W_NE = val++;
exports.MONS_ELDRITCH_TENTACLE_SEGMENT_W_SE = val++;
exports.MONS_STARSPAWN_TENTACLE_N = val++;
exports.MONS_STARSPAWN_TENTACLE_S = val++;
exports.MONS_STARSPAWN_TENTACLE_E = val++;
exports.MONS_STARSPAWN_TENTACLE_W = val++;
exports.MONS_STARSPAWN_TENTACLE_NE = val++;
exports.MONS_STARSPAWN_TENTACLE_NW = val++;
exports.MONS_STARSPAWN_TENTACLE_SE = val++;
exports.MONS_STARSPAWN_TENTACLE_SW = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_E_W = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_N_S = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_NE_SW = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_NW_SE = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_E_N = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_E_S = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_N_W = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_S_W = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_NE_NW = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_NE_SE = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_NW_SW = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_SE_SW = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_N_SE = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_N_SW = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_S_NE = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_S_NW = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_E_NW = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_E_SW = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_W_NE = val++;
exports.MONS_STARSPAWN_TENTACLE_SEGMENT_W_SE = val++;
exports.MONS_VINE_N = val++;
exports.MONS_VINE_S = val++;
exports.MONS_VINE_E = val++;
exports.MONS_VINE_W = val++;
exports.MONS_VINE_NE = val++;
exports.MONS_VINE_NW = val++;
exports.MONS_VINE_SE = val++;
exports.MONS_VINE_SW = val++;
exports.MONS_VINE_SEGMENT_E_W = val++;
exports.MONS_VINE_SEGMENT_N_S = val++;
exports.MONS_VINE_SEGMENT_NE_SW = val++;
exports.MONS_VINE_SEGMENT_NW_SE = val++;
exports.MONS_VINE_SEGMENT_E_N = val++;
exports.MONS_VINE_SEGMENT_E_S = val++;
exports.MONS_VINE_SEGMENT_N_W = val++;
exports.MONS_VINE_SEGMENT_S_W = val++;
exports.MONS_VINE_SEGMENT_NE_NW = val++;
exports.MONS_VINE_SEGMENT_NE_SE = val++;
exports.MONS_VINE_SEGMENT_NW_SW = val++;
exports.MONS_VINE_SEGMENT_SE_SW = val++;
exports.MONS_VINE_SEGMENT_N_SE = val++;
exports.MONS_VINE_SEGMENT_N_SW = val++;
exports.MONS_VINE_SEGMENT_S_NE = val++;
exports.MONS_VINE_SEGMENT_S_NW = val++;
exports.MONS_VINE_SEGMENT_E_NW = val++;
exports.MONS_VINE_SEGMENT_E_SW = val++;
exports.MONS_VINE_SEGMENT_W_NE = val++;
exports.MONS_VINE_SEGMENT_W_SE = val++;
exports.MONS_VINE_SEGMENT_N_NW = val++;
exports.MONS_VINE_SEGMENT_N_NE = val++;
exports.MONS_VINE_SEGMENT_E_NE = val++;
exports.MONS_VINE_SEGMENT_E_SE = val++;
exports.MONS_VINE_SEGMENT_S_SE = val++;
exports.MONS_VINE_SEGMENT_S_SW = val++;
exports.MONS_VINE_SEGMENT_W_SW = val++;
exports.MONS_VINE_SEGMENT_W_NW = val++;
exports.MONS_PRINCE_RIBBIT = val++;
exports.MONS_BULLFROG = val++;
exports.MONS_BLINK_FROG = val++;
exports.MONS_SPINY_FROG = val++;
exports.MONS_BALL_PYTHON = val++;
exports.MONS_ADDER = val++;
exports.MONS_BLACK_MAMBA = val++;
exports.MONS_WATER_MOCCASIN = val++;
exports.MONS_ANACONDA = val++;
exports.MONS_LAVA_SNAKE = val++;
exports.MONS_SEA_SNAKE = val++;
exports.MONS_SHOCK_SERPENT = val++;
exports.MONS_MANA_VIPER = val++;
exports.MONS_BLACK_BEAR = val++;
exports.MONS_POLAR_BEAR = val++;
exports.MONS_DREAM_SHEEP = val++;
exports.MONS_YAK = val++;
exports.MONS_DEATH_YAK = val++;
exports.MONS_CATOBLEPAS = val++;
exports.MONS_ELEPHANT = val++;
exports.MONS_DIRE_ELEPHANT = val++;
exports.MONS_HELLEPHANT = val++;
exports.MONS_NELLIE = val++;
exports.MONS_APIS = val++;
exports.MONS_EARTH_ELEMENTAL = val++;
exports.MONS_FIRE_ELEMENTAL = val++;
exports.MONS_WATER_ELEMENTAL = val++;
exports.MONS_AIR_ELEMENTAL = val++;
exports.MONS_IRON_ELEMENTAL = val++;
exports.MONS_ELEMENTAL_WELLSPRING = val++;
exports.MONS_FIRE_VORTEX = val++;
exports.MONS_FIRE_VORTEX_1 = val++;
exports.MONS_FIRE_VORTEX_2 = val++;
exports.MONS_FIRE_VORTEX_3 = val++;
exports.MONS_SPATIAL_VORTEX = val++;
exports.MONS_SPATIAL_VORTEX_1 = val++;
exports.MONS_SPATIAL_VORTEX_2 = val++;
exports.MONS_SPATIAL_VORTEX_3 = val++;
exports.MONS_SPATIAL_MAELSTROM = val++;
exports.MONS_SPATIAL_MAELSTROM_1 = val++;
exports.MONS_SPATIAL_MAELSTROM_2 = val++;
exports.MONS_SPATIAL_MAELSTROM_3 = val++;
exports.MONS_TWISTER = val++;
exports.MONS_TWISTER_1 = val++;
exports.MONS_TWISTER_2 = val++;
exports.MONS_TWISTER_3 = val++;
exports.MONS_ORB_OF_FIRE = val++;
exports.MONS_ORB_OF_DESTRUCTION = val++;
exports.MONS_ORB_OF_DESTRUCTION_1 = val++;
exports.MONS_ORB_OF_DESTRUCTION_2 = val++;
exports.MONS_BATTLESPHERE = val++;
exports.MONS_FULMINANT_PRISM = val++;
exports.MONS_FULMINANT_PRISM_1 = val++;
exports.MONS_FULMINANT_PRISM_2 = val++;
exports.MONS_FULMINANT_PRISM_3 = val++;
exports.MONS_BALL_LIGHTNING = val++;
exports.MONS_DEATH_COB = val++;
exports.MONS_ANCIENT_ZYME = val++;
exports.MONS_APOCALYPSE_CRAB = val++;
exports.MONS_LURKING_HORROR = val++;
exports.MONS_STARCURSED_MASS = val++;
exports.MONS_TENTACLED_STARSPAWN = val++;
exports.MONS_THRASHING_HORROR = val++;
exports.MONS_WORLDBINDER = val++;
exports.MONS_WRETCHED_STAR = val++;
exports.MONS_GERYON = val++;
exports.MONS_BALRUG = val++;
exports.MONS_BLIZZARD_DEMON = val++;
exports.MONS_CACODEMON = val++;
exports.MONS_EXECUTIONER = val++;
exports.MONS_BRIMSTONE_FIEND = val++;
exports.MONS_GREEN_DEATH = val++;
exports.MONS_ICE_FIEND = val++;
exports.MONS_HELL_SENTINEL = val++;
exports.MONS_TZITZIMITL = val++;
exports.MONS_IGNACIO = val++;
exports.MONS_HELL_BEAST = val++;
exports.MONS_ICE_DEVIL = val++;
exports.MONS_LOROCYPROCA = val++;
exports.MONS_REAPER = val++;
exports.MONS_SOUL_EATER = val++;
exports.MONS_SUN_DEMON = val++;
exports.MONS_CHAOS_SPAWN = val++;
exports.MONS_CHAOS_SPAWN_1 = val++;
exports.MONS_CHAOS_SPAWN_2 = val++;
exports.MONS_CHAOS_SPAWN_3 = val++;
exports.MONS_CHAOS_SPAWN_4 = val++;
exports.MONS_HELLION = val++;
exports.MONS_RUST_DEVIL = val++;
exports.MONS_NEQOXEC = val++;
exports.MONS_ORANGE_DEMON = val++;
exports.MONS_SHADOW_DEMON = val++;
exports.MONS_TORMENTOR = val++;
exports.MONS_YNOXINUL = val++;
exports.MONS_RED_DEVIL = val++;
exports.MONS_SMOKE_DEMON = val++;
exports.MONS_SIXFIRHY = val++;
exports.MONS_HELLWING = val++;
exports.MONS_CRIMSON_IMP = val++;
exports.MONS_QUASIT = val++;
exports.MONS_IRON_IMP = val++;
exports.MONS_SHADOW_IMP = val++;
exports.MONS_GRINDER = val++;
exports.MONS_UFETUBUS = val++;
exports.MONS_WHITE_IMP = val++;
exports.MONS_DEMONSPAWN = val++;
exports.MONS_MONSTROUS_DEMONSPAWN = val++;
exports.MONS_GELID_DEMONSPAWN = val++;
exports.MONS_INFERNAL_DEMONSPAWN = val++;
exports.MONS_TORTUROUS_DEMONSPAWN = val++;
exports.MONS_BLOOD_SAINT = val++;
exports.MONS_WARMONGER = val++;
exports.MONS_CORRUPTER = val++;
exports.MONS_BLACK_SUN = val++;
exports.MONS_FAINT_DEMONSPAWN_MONK = val++;
exports.MONS_MARA = val++;
exports.MONS_RAKSHASA = val++;
exports.MONS_AZRAEL = val++;
exports.MONS_EFREET = val++;
exports.MONS_ANCESTOR = val++;
exports.MONS_ANCESTOR_KNIGHT = val++;
exports.MONS_ANCESTOR_BATTLEMAGE = val++;
exports.MONS_ANCESTOR_HEXER = val++;
exports.MONS_ABOMINATION_LARGE = val++;
exports.MONS_ABOMINATION_LARGE_1 = val++;
exports.MONS_ABOMINATION_LARGE_2 = val++;
exports.MONS_ABOMINATION_LARGE_3 = val++;
exports.MONS_ABOMINATION_LARGE_4 = val++;
exports.MONS_ABOMINATION_LARGE_5 = val++;
exports.MONS_ABOMINATION_LARGE_6 = val++;
exports.MONS_ABOMINATION_LARGE_7 = val++;
exports.MONS_ABOMINATION_LARGE_8 = val++;
exports.MONS_ABOMINATION_LARGE_9 = val++;
exports.MONS_TENTACLED_MONSTROSITY = val++;
exports.MONS_CIGOTUVIS_MONSTER = val++;
exports.MONS_UGLY_THING = val++;
exports.MONS_UGLY_THING_1 = val++;
exports.MONS_UGLY_THING_2 = val++;
exports.MONS_UGLY_THING_3 = val++;
exports.MONS_UGLY_THING_4 = val++;
exports.MONS_UGLY_THING_5 = val++;
exports.MONS_VERY_UGLY_THING = val++;
exports.MONS_VERY_UGLY_THING_1 = val++;
exports.MONS_VERY_UGLY_THING_2 = val++;
exports.MONS_VERY_UGLY_THING_3 = val++;
exports.MONS_VERY_UGLY_THING_4 = val++;
exports.MONS_VERY_UGLY_THING_5 = val++;
exports.MONS_UNSEEN_HORROR = val++;
exports.MONS_ABOMINATION_SMALL = val++;
exports.MONS_ABOMINATION_SMALL_1 = val++;
exports.MONS_OCTOPODE = val++;
exports.MONS_CRYSTAL_GUARDIAN = val++;
exports.MONS_ELECTRIC_GOLEM = val++;
exports.MONS_GUARDIAN_GOLEM = val++;
exports.MONS_IRON_GOLEM = val++;
exports.MONS_TOENAIL_GOLEM = val++;
exports.MONS_USHABTI = val++;
exports.MONS_PEACEKEEPER = val++;
exports.MONS_SALTLING = val++;
exports.MONS_FLESH_GOLEM = val++;
exports.MONS_ROXANNE = val++;
exports.MONS_PILLAR_OF_SALT = val++;
exports.MONS_BLOCK_OF_ICE = val++;
exports.MONS_BLOCK_OF_ICE_1 = val++;
exports.MONS_TRAINING_DUMMY = val++;
exports.MONS_ICE_STATUE = val++;
exports.MONS_OBSIDIAN_STATUE = val++;
exports.MONS_ORANGE_STATUE = val++;
exports.MONS_WUCAD_MU_STATUE = val++;
exports.MONS_AIR_ELEMENTALIST_STATUE = val++;
exports.MONS_EARTH_ELEMENTALIST_STATUE = val++;
exports.MONS_FIRE_ELEMENTALIST_STATUE = val++;
exports.MONS_WATER_ELEMENTALIST_STATUE = val++;
exports.MONS_ZOT_STATUE = val++;
exports.MONS_STATUE_AXE = val++;
exports.MONS_STATUE_ARCHER = val++;
exports.MONS_STATUE_CROSSBOW = val++;
exports.MONS_STATUE_MACE = val++;
exports.MONS_STATUE_MAGE = val++;
exports.MONS_STATUE_SCYTHE = val++;
exports.MONS_STATUE_SWORD = val++;
exports.MONS_STATUE_WHIP = val++;
exports.MONS_FIRESPITTER_STATUE = val++;
exports.MONS_DIAMOND_OBELISK = val++;
exports.MONS_LIGHTNING_SPIRE = val++;
exports.MONS_SPELLFORGED_SERVITOR = val++;
exports.MONS_GARGOYLE = val++;
exports.MONS_WAR_GARGOYLE = val++;
exports.MONS_MOLTEN_GARGOYLE = val++;
exports.MONS_SPECTRAL_SBL = val++;
exports.MONS_SPECTRAL_LBL = val++;
exports.MONS_SPECTRAL_STAFF = val++;
exports.MONS_SPECTRAL_AXE = val++;
exports.MONS_SPECTRAL_MACE = val++;
exports.MONS_SPECTRAL_WHIP = val++;
exports.MONS_SPECTRAL_SPEAR = val++;
exports.MONS_DONALD = val++;
exports.MONS_EDMUND = val++;
exports.MONS_ERICA = val++;
exports.MONS_ERICA_SWORDLESS = val++;
exports.MONS_EUSTACHIO = val++;
exports.MONS_FRANCES = val++;
exports.MONS_FREDERICK = val++;
exports.MONS_HAROLD = val++;
exports.MONS_JESSICA = val++;
exports.MONS_JOSEPH = val++;
exports.MONS_JOSEPHINE = val++;
exports.MONS_KIRKE = val++;
exports.MONS_LOUISE = val++;
exports.MONS_MARGERY = val++;
exports.MONS_MAURICE = val++;
exports.MONS_NIKOLA = val++;
exports.MONS_PSYCHE = val++;
exports.MONS_RUPERT = val++;
exports.MONS_SIGMUND = val++;
exports.MONS_TERENCE = val++;
exports.MONS_SHAPESHIFTER = val++;
exports.MONS_GLOWING_SHAPESHIFTER = val++;
exports.MONS_ENTROPY_WEAVER = val++;
exports.MONS_FORMICID = val++;
exports.MONS_HUMAN = val++;
exports.MONS_HUMAN_1 = val++;
exports.MONS_HUMAN_2 = val++;
exports.MONS_HELL_KNIGHT = val++;
exports.MONS_DEATH_KNIGHT = val++;
exports.MONS_NECROMANCER = val++;
exports.MONS_WIZARD = val++;
exports.MONS_VAULT_GUARD = val++;
exports.MONS_VAULT_WARDEN = val++;
exports.MONS_VAULT_SENTINEL = val++;
exports.MONS_IRONBRAND_CONVOKER = val++;
exports.MONS_IRONHEART_PRESERVER = val++;
exports.MONS_SERVANT_OF_WHISPERS = val++;
exports.MONS_RAGGED_HIEROPHANT = val++;
exports.MONS_IMPERIAL_MYRMIDON = val++;
exports.MONS_KILLER_KLOWN = val++;
exports.MONS_KILLER_KLOWN_1 = val++;
exports.MONS_KILLER_KLOWN_2 = val++;
exports.MONS_KILLER_KLOWN_3 = val++;
exports.MONS_KILLER_KLOWN_4 = val++;
exports.MONS_SLAVE = val++;
exports.MONS_SLAVE_1 = val++;
exports.MONS_HELL_WIZARD = val++;
exports.MONS_HELL_WIZARD_1 = val++;
exports.MONS_HELL_WIZARD_2 = val++;
exports.MONS_DEFORMED_HUMAN = val++;
exports.MONS_CLOUD_MAGE = val++;
exports.MONS_HELLBINDER = val++;
exports.MONS_MASTER_ELEMENTALIST = val++;
exports.MONS_HALFLING = val++;
exports.MONS_DEMIGOD = val++;
exports.MONS_ANGEL = val++;
exports.MONS_DAEVA = val++;
exports.MONS_CHERUB = val++;
exports.MONS_PROFANE_SERVITOR = val++;
exports.MONS_MENNAS = val++;
exports.MONS_POLYPHEMUS = val++;
exports.MONS_CHUCK = val++;
exports.MONS_ETTIN = val++;
exports.MONS_CYCLOPS = val++;
exports.MONS_FIRE_GIANT = val++;
exports.MONS_FROST_GIANT = val++;
exports.MONS_STONE_GIANT = val++;
exports.MONS_TITAN = val++;
exports.MONS_JUGGERNAUT = val++;
exports.MONS_IRON_GIANT = val++;
exports.MONS_SWAMP_DRAKE = val++;
exports.MONS_RIME_DRAKE = val++;
exports.MONS_LINDWURM = val++;
exports.MONS_DEATH_DRAKE = val++;
exports.MONS_WIND_DRAKE = val++;
exports.MONS_XTAHUA = val++;
exports.MONS_WYVERN = val++;
exports.MONS_FIRE_DRAGON = val++;
exports.MONS_HYDRA = val++;
exports.MONS_HYDRA_1 = val++;
exports.MONS_HYDRA_2 = val++;
exports.MONS_HYDRA_3 = val++;
exports.MONS_HYDRA_4 = val++;
exports.MONS_HYDRA_5 = val++;
exports.MONS_HYDRA_6 = val++;
exports.MONS_ICE_DRAGON = val++;
exports.MONS_STEAM_DRAGON = val++;
exports.MONS_SWAMP_DRAGON = val++;
exports.MONS_ACID_DRAGON = val++;
exports.MONS_QUICKSILVER_DRAGON = val++;
exports.MONS_IRON_DRAGON = val++;
exports.MONS_STORM_DRAGON = val++;
exports.MONS_GOLDEN_DRAGON = val++;
exports.MONS_SHADOW_DRAGON = val++;
exports.MONS_BONE_DRAGON = val++;
exports.MONS_PEARL_DRAGON = val++;
exports.MONS_BALLISTOMYCETE_SPORE = val++;
exports.MONS_FLOATING_EYE = val++;
exports.MONS_EYE_OF_DRAINING = val++;
exports.MONS_GLOWING_ORANGE_BRAIN = val++;
exports.MONS_GREAT_ORB_OF_EYES = val++;
exports.MONS_SHINING_EYE = val++;
exports.MONS_EYE_OF_DEVASTATION = val++;
exports.MONS_GOLDEN_EYE = val++;
exports.MONS_OPHAN = val++;
exports.MONS_HIPPOGRIFF = val++;
exports.MONS_MANTICORE = val++;
exports.MONS_HARPY = val++;
exports.MONS_SPHINX = val++;
exports.MONS_MINOTAUR = val++;
exports.MONS_TENGU = val++;
exports.MONS_TENGU_CONJURER = val++;
exports.MONS_TENGU_WARRIOR = val++;
exports.MONS_TENGU_REAVER = val++;
exports.MUTANT_BEAST_BASE = val++;
exports.MUTANT_BEAST_BASE_1 = val++;
exports.MUTANT_BEAST_BASE_2 = val++;
exports.MUTANT_BEAST_BASE_3 = val++;
exports.MUTANT_BEAST_BASE_4 = val++;
exports.MUTANT_BEAST_WING_BASE = val++;
exports.MUTANT_BEAST_WING_BASE_1 = val++;
exports.MUTANT_BEAST_WING_BASE_2 = val++;
exports.MUTANT_BEAST_WING_BASE_3 = val++;
exports.MUTANT_BEAST_WING_BASE_4 = val++;
exports.MUTANT_BEAST_FIRE = val++;
exports.MUTANT_BEAST_FIRE_1 = val++;
exports.MUTANT_BEAST_FIRE_2 = val++;
exports.MUTANT_BEAST_FIRE_3 = val++;
exports.MUTANT_BEAST_FIRE_4 = val++;
exports.MUTANT_BEAST_WEIRD = val++;
exports.MUTANT_BEAST_WEIRD_1 = val++;
exports.MUTANT_BEAST_WEIRD_2 = val++;
exports.MUTANT_BEAST_WEIRD_3 = val++;
exports.MUTANT_BEAST_WEIRD_4 = val++;
exports.MUTANT_BEAST_HORN = val++;
exports.MUTANT_BEAST_HORN_1 = val++;
exports.MUTANT_BEAST_HORN_2 = val++;
exports.MUTANT_BEAST_HORN_3 = val++;
exports.MUTANT_BEAST_HORN_4 = val++;
exports.MUTANT_BEAST_OX = val++;
exports.MUTANT_BEAST_OX_1 = val++;
exports.MUTANT_BEAST_OX_2 = val++;
exports.MUTANT_BEAST_OX_3 = val++;
exports.MUTANT_BEAST_OX_4 = val++;
exports.MUTANT_BEAST_SHOCK = val++;
exports.MUTANT_BEAST_SHOCK_1 = val++;
exports.MUTANT_BEAST_SHOCK_2 = val++;
exports.MUTANT_BEAST_SHOCK_3 = val++;
exports.MUTANT_BEAST_SHOCK_4 = val++;
exports.MUTANT_BEAST_STING = val++;
exports.MUTANT_BEAST_STING_1 = val++;
exports.MUTANT_BEAST_STING_2 = val++;
exports.MUTANT_BEAST_STING_3 = val++;
exports.MUTANT_BEAST_STING_4 = val++;
exports.MUTANT_BEAST_WING_TOP = val++;
exports.MUTANT_BEAST_WING_TOP_1 = val++;
exports.MUTANT_BEAST_WING_TOP_2 = val++;
exports.MUTANT_BEAST_WING_TOP_3 = val++;
exports.MUTANT_BEAST_WING_TOP_4 = val++;
exports.MONS_SOJOBO = val++;
exports.MONS_ARACHNE = val++;
exports.MONS_ARACHNE_STAVELESS = val++;
exports.MONS_ASTERION = val++;
exports.MONS_ICE_BEAST = val++;
exports.MONS_SKY_BEAST = val++;
exports.MONS_DISSOLUTION = val++;
exports.MONS_OOZE = val++;
exports.MONS_JELLY = val++;
exports.MONS_SLIME_CREATURE = val++;
exports.MONS_SLIME_CREATURE_1 = val++;
exports.MONS_SLIME_CREATURE_2 = val++;
exports.MONS_SLIME_CREATURE_3 = val++;
exports.MONS_SLIME_CREATURE_4 = val++;
exports.MONS_AZURE_JELLY = val++;
exports.MONS_ACID_BLOB = val++;
exports.MONS_DEATH_OOZE = val++;
exports.MONS_SONJA = val++;
exports.MONS_PIKEL = val++;
exports.MONS_KOBOLD = val++;
exports.MONS_BIG_KOBOLD = val++;
exports.MONS_KOBOLD_DEMONOLOGIST = val++;
exports.MONS_BORIS = val++;
exports.MONS_REVENANT = val++;
exports.MONS_LICH = val++;
exports.MONS_ANCIENT_LICH = val++;
exports.MONS_HALAZID_WARLOCK = val++;
exports.MONS_ZONGULDROK_LICH = val++;
exports.MONS_MENKAURE = val++;
exports.MONS_KHUFU = val++;
exports.MONS_MUMMY = val++;
exports.MONS_GUARDIAN_MUMMY = val++;
exports.MONS_GREATER_MUMMY = val++;
exports.MONS_MUMMY_PRIEST = val++;
exports.MONS_AIZUL = val++;
exports.MONS_VASHNIA = val++;
exports.MONS_NAGA = val++;
exports.MONS_NAGA_MAGE = val++;
exports.MONS_NAGA_RITUALIST = val++;
exports.MONS_NAGA_SHARPSHOOTER = val++;
exports.MONS_NAGA_WARRIOR = val++;
exports.MONS_NAGARAJA = val++;
exports.MONS_SALAMANDER = val++;
exports.MONS_SALAMANDER_MYSTIC = val++;
exports.MONS_GUARDIAN_SERPENT = val++;
exports.MONS_EROLCHA = val++;
exports.MONS_OGRE = val++;
exports.MONS_TWO_HEADED_OGRE = val++;
exports.MONS_OGRE_MAGE = val++;
exports.MONS_PLANT = val++;
exports.MONS_PLANT_1 = val++;
exports.MONS_PLANT_2 = val++;
exports.MONS_PLANT_3 = val++;
exports.MONS_PLANT_4 = val++;
exports.MONS_PLANT_5 = val++;
exports.MONS_PLANT_6 = val++;
exports.MONS_PLANT_7 = val++;
exports.MONS_PLANT_8 = val++;
exports.MONS_PLANT_9 = val++;
exports.MONS_PLANT_10 = val++;
exports.MONS_WITHERED_PLANT = val++;
exports.MONS_DEMONIC_PLANT = val++;
exports.MONS_BUSH = val++;
exports.MONS_BUSH_1 = val++;
exports.MONS_BUSH_2 = val++;
exports.MONS_BUSH_3 = val++;
exports.MONS_BUSH_BURNING = val++;
exports.MONS_OKLOB_SAPLING = val++;
exports.MONS_OKLOB_PLANT = val++;
exports.MONS_THORN_HUNTER = val++;
exports.MONS_TREANT = val++;
exports.MONS_BRIAR_PATCH = val++;
exports.MONS_VINE_STALKER = val++;
exports.MONS_PURGY = val++;
exports.MONS_SNORG = val++;
exports.MONS_TROLL = val++;
exports.MONS_IRON_TROLL = val++;
exports.MONS_DEEP_TROLL = val++;
exports.MONS_DEEP_TROLL_EARTH_MAGE = val++;
exports.MONS_DEEP_TROLL_SHAMAN = val++;
exports.MONS_FAINT_DEEP_TROLL_MONK = val++;
exports.MONS_MOON_TROLL = val++;
exports.MONS_VAMPIRE = val++;
exports.MONS_VAMPIRE_KNIGHT = val++;
exports.MONS_VAMPIRE_MAGE = val++;
exports.MONS_JIANGSHI = val++;
exports.MONS_JORY = val++;
exports.MONS_WRAITH = val++;
exports.MONS_SHADOW_WRAITH = val++;
exports.MONS_FREEZING_WRAITH = val++;
exports.MONS_PHANTASMAL_WARRIOR = val++;
exports.MONS_EIDOLON = val++;
exports.MONS_ORB_GUARDIAN = val++;
exports.MONS_NESSOS = val++;
exports.MONS_CENTAUR = val++;
exports.MONS_CENTAUR_MELEE = val++;
exports.MONS_CENTAUR_WARRIOR = val++;
exports.MONS_CENTAUR_WARRIOR_MELEE = val++;
exports.MONS_YAKTAUR = val++;
exports.MONS_YAKTAUR_MELEE = val++;
exports.MONS_YAKTAUR_CAPTAIN = val++;
exports.MONS_YAKTAUR_CAPTAIN_MELEE = val++;
exports.MONS_FAUN = val++;
exports.MONS_SATYR = val++;
exports.MONS_DOWAN = val++;
exports.MONS_DOWAN_1 = val++;
exports.MONS_DUVESSA = val++;
exports.MONS_DUVESSA_1 = val++;
exports.MONS_FANNAR = val++;
exports.MONS_ELF = val++;
exports.MONS_DEEP_ELF_KNIGHT = val++;
exports.MONS_DEEP_ELF_ARCHER = val++;
exports.MONS_DEEP_ELF_MAGE = val++;
exports.MONS_DEEP_ELF_SORCERER = val++;
exports.MONS_DEEP_ELF_DEATH_MAGE = val++;
exports.MONS_DEEP_ELF_DEMONOLOGIST = val++;
exports.MONS_DEEP_ELF_ANNIHILATOR = val++;
exports.MONS_DEEP_ELF_HIGH_PRIEST = val++;
exports.MONS_DEEP_ELF_BLADEMASTER = val++;
exports.MONS_DEEP_ELF_MASTER_ARCHER = val++;
exports.MONS_DEEP_ELF_ELEMENTALIST = val++;
exports.MONS_DEEP_ELF_ELEMENTALIST_1 = val++;
exports.MONS_DEEP_ELF_ELEMENTALIST_2 = val++;
exports.MONS_DEFORMED_ELF = val++;
exports.MONS_TOADSTOOL = val++;
exports.MONS_TOADSTOOL_1 = val++;
exports.MONS_FUNGUS = val++;
exports.MONS_FUNGUS_1 = val++;
exports.MONS_FUNGUS_2 = val++;
exports.MONS_FUNGUS_3 = val++;
exports.MONS_FUNGUS_4 = val++;
exports.MONS_FUNGUS_5 = val++;
exports.MONS_FUNGUS_6 = val++;
exports.MONS_FUNGUS_7 = val++;
exports.MONS_FUNGUS_8 = val++;
exports.MONS_BALLISTOMYCETE = val++;
exports.MONS_WANDERING_MUSHROOM = val++;
exports.MONS_DEATHCAP = val++;
exports.MONS_IJYB = val++;
exports.MONS_ROBIN = val++;
exports.MONS_CRAZY_YIUF = val++;
exports.MONS_GRUM = val++;
exports.MONS_GOBLIN = val++;
exports.MONS_HOBGOBLIN = val++;
exports.MONS_GNOLL = val++;
exports.MONS_GNOLL_SHAMAN = val++;
exports.MONS_GNOLL_SERGEANT = val++;
exports.MONS_BOGGART = val++;
exports.MONS_SPRIGGAN = val++;
exports.MONS_SPRIGGAN_RIDER = val++;
exports.MONS_SPRIGGAN_DRUID = val++;
exports.MONS_SPRIGGAN_BERSERKER = val++;
exports.MONS_SPRIGGAN_DEFENDER = val++;
exports.MONS_SPRIGGAN_AIR_MAGE = val++;
exports.MONS_THE_ENCHANTRESS = val++;
exports.MONS_AGNES = val++;
exports.MONS_AGNES_STAVELESS = val++;
exports.MONS_ILSUIW = val++;
exports.MONS_ILSUIW_WATER = val++;
exports.MONS_MERFOLK = val++;
exports.MONS_MERFOLK_WATER = val++;
exports.MONS_MERFOLK_JAVELINEER = val++;
exports.MONS_MERFOLK_JAVELINEER_WATER = val++;
exports.MONS_MERFOLK_IMPALER = val++;
exports.MONS_MERFOLK_IMPALER_WATER = val++;
exports.MONS_MERFOLK_AQUAMANCER = val++;
exports.MONS_MERFOLK_AQUAMANCER_WATER = val++;
exports.MONS_MERFOLK_SIREN = val++;
exports.MONS_MERFOLK_SIREN_WATER = val++;
exports.MONS_MERFOLK_AVATAR = val++;
exports.MONS_MERFOLK_AVATAR_WATER = val++;
exports.MONS_DRYAD = val++;
exports.MONS_WATER_NYMPH = val++;
exports.MONS_BOG_BODY = val++;
exports.MONS_NECROPHAGE = val++;
exports.MONS_GHOUL = val++;
exports.MONS_BLORK_THE_ORC = val++;
exports.MONS_URUG = val++;
exports.MONS_NERGALLE = val++;
exports.MONS_SAINT_ROKA = val++;
exports.MONS_ORC = val++;
exports.MONS_ORC_WIZARD = val++;
exports.MONS_ORC_PRIEST = val++;
exports.MONS_ORC_WARRIOR = val++;
exports.MONS_ORC_KNIGHT = val++;
exports.MONS_ORC_WARLORD = val++;
exports.MONS_ORC_SORCERER = val++;
exports.MONS_ORC_HIGH_PRIEST = val++;
exports.MONS_DEFORMED_ORC = val++;
exports.MONS_SHADOW = val++;
exports.MONS_PHANTOM = val++;
exports.MONS_GHOST = val++;
exports.MONS_PLAYER_GHOST = val++;
exports.MONS_SILENT_SPECTRE = val++;
exports.MONS_LOST_SOUL = val++;
exports.MONS_DROWNED_SOUL = val++;
exports.MONS_FLAYED_GHOST = val++;
exports.MONS_HUNGRY_GHOST = val++;
exports.MONS_INSUBSTANTIAL_WISP = val++;
exports.MONS_DWARF = val++;
exports.MONS_DEEP_DWARF = val++;
exports.MONS_JORGRUN = val++;
exports.MONS_WIGHT = val++;
exports.MONS_SKELETAL_WARRIOR = val++;
exports.MONS_ANCIENT_CHAMPION = val++;
exports.MONS_CURSE_SKULL = val++;
exports.MONS_CURSE_TOE = val++;
exports.MONS_FLYING_SKULL = val++;
exports.MONS_CRAWLING_CORPSE = val++;
exports.MONS_MACABRE_MASS = val++;
exports.MONS_MURRAY = val++;
exports.MONS_DIMME = val++;
exports.MONS_ORB_OF_ICE = val++;
exports.MONS_ORB_OF_ELECTRICITY = val++;
exports.MONS_ZOMBIE_SMALL = val++;
exports.MONS_ZOMBIE_LARGE = val++;
exports.MONS_ZOMBIE_QUADRUPED_SMALL = val++;
exports.MONS_ZOMBIE_QUADRUPED_LARGE = val++;
exports.MONS_ZOMBIE_OGRE = val++;
exports.MONS_ZOMBIE_FROG = val++;
exports.MONS_ZOMBIE_BAT = val++;
exports.MONS_ZOMBIE_BEE = val++;
exports.MONS_ZOMBIE_BEETLE = val++;
exports.MONS_ZOMBIE_BUG = val++;
exports.MONS_ZOMBIE_HOUND = val++;
exports.MONS_ZOMBIE_FISH = val++;
exports.MONS_ZOMBIE_CENTAUR = val++;
exports.MONS_ZOMBIE_NAGA = val++;
exports.MONS_ZOMBIE_SNAKE = val++;
exports.MONS_ZOMBIE_WORM = val++;
exports.MONS_ZOMBIE_LIZARD = val++;
exports.MONS_ZOMBIE_SPIDER_LARGE = val++;
exports.MONS_ZOMBIE_DRAGON = val++;
exports.MONS_ZOMBIE_KRAKEN = val++;
exports.MONS_ZOMBIE_DRAKE = val++;
exports.MONS_ZOMBIE_HYDRA = val++;
exports.MONS_ZOMBIE_HYDRA_1 = val++;
exports.MONS_ZOMBIE_HYDRA_2 = val++;
exports.MONS_ZOMBIE_HYDRA_3 = val++;
exports.MONS_ZOMBIE_HYDRA_4 = val++;
exports.MONS_ZOMBIE_TROLL = val++;
exports.MONS_ZOMBIE_DRACONIAN = val++;
exports.MONS_ZOMBIE_QUADRUPED_WINGED = val++;
exports.MONS_ZOMBIE_HARPY = val++;
exports.MONS_ZOMBIE_OCTOPODE = val++;
exports.MONS_ZOMBIE_JUGGERNAUT = val++;
exports.MONS_LERNAEAN_HYDRA_ZOMBIE = val++;
exports.MONS_LERNAEAN_HYDRA_ZOMBIE_1 = val++;
exports.MONS_LERNAEAN_HYDRA_ZOMBIE_2 = val++;
exports.MONS_LERNAEAN_HYDRA_ZOMBIE_3 = val++;
exports.MONS_LERNAEAN_HYDRA_ZOMBIE_4 = val++;
exports.MONS_LERNAEAN_HYDRA_ZOMBIE_5 = val++;
exports.MONS_LERNAEAN_HYDRA_ZOMBIE_6 = val++;
exports.MONS_LERNAEAN_HYDRA_ZOMBIE_7 = val++;
exports.MONS_LERNAEAN_HYDRA_ZOMBIE_8 = val++;
exports.MONS_LERNAEAN_HYDRA_ZOMBIE_9 = val++;
exports.MONS_ZOMBIE_ELF = val++;
exports.MONS_ZOMBIE_FAUN = val++;
exports.MONS_ZOMBIE_GUARDIAN_SERPENT = val++;
exports.MONS_ZOMBIE_LINDWURM = val++;
exports.MONS_ZOMBIE_MERFOLK = val++;
exports.MONS_ZOMBIE_MINOTAUR = val++;
exports.MONS_ZOMBIE_SALAMANDER = val++;
exports.MONS_ZOMBIE_SPRIGGAN = val++;
exports.MONS_ZOMBIE_WYVERN = val++;
exports.MONS_ZOMBIE_YAKTAUR = val++;
exports.MONS_ZOMBIE_UGLY_THING = val++;
exports.MONS_ZOMBIE_TURTLE = val++;
exports.MONS_ZOMBIE_CRAB = val++;
exports.MONS_ZOMBIE_ADDER = val++;
exports.MONS_ZOMBIE_GNOLL = val++;
exports.MONS_ZOMBIE_GOBLIN = val++;
exports.MONS_ZOMBIE_HOBGOBLIN = val++;
exports.MONS_ZOMBIE_HUMAN = val++;
exports.MONS_ZOMBIE_JACKAL = val++;
exports.MONS_ZOMBIE_KOBOLD = val++;
exports.MONS_ZOMBIE_ORC = val++;
exports.MONS_ZOMBIE_QUOKKA = val++;
exports.MONS_ZOMBIE_RAT = val++;
exports.MONS_ZOMBIE_ROACH = val++;
exports.MONS_ZOMBIE_SCORPION = val++;
exports.MONS_ZOMBIE_SPIDER_SMALL = val++;
exports.MONS_ZOMBIE_BIRD = val++;
exports.MONS_ZOMBIE_MONKEY = val++;
exports.MONS_ZOMBIE_ELEPHANT = val++;
exports.MONS_ZOMBIE_QUICKSILVER_DRAGON = val++;
exports.MONS_ZOMBIE_GOLDEN_DRAGON = val++;
exports.MONS_ZOMBIE_IRON_DRAGON = val++;
exports.MONS_ZOMBIE_YAK = val++;
exports.MONS_ZOMBIE_BEAR = val++;
exports.MONS_SKELETON_SMALL = val++;
exports.MONS_SKELETON_MEDIUM = val++;
exports.MONS_SKELETON_LARGE = val++;
exports.MONS_SKELETON_QUADRUPED_SMALL = val++;
exports.MONS_SKELETON_QUADRUPED_LARGE = val++;
exports.MONS_SKELETON_QUADRUPED_WINGED = val++;
exports.MONS_SKELETON_TROLL = val++;
exports.MONS_SKELETON_FROG = val++;
exports.MONS_SKELETON_LIZARD = val++;
exports.MONS_SKELETON_TURTLE = val++;
exports.MONS_SKELETON_BAT = val++;
exports.MONS_SKELETON_BIRD = val++;
exports.MONS_SKELETON_FISH = val++;
exports.MONS_SKELETON_CENTAUR = val++;
exports.MONS_SKELETON_NAGA = val++;
exports.MONS_SKELETON_SNAKE = val++;
exports.MONS_SKELETON_DRAGON = val++;
exports.MONS_SKELETON_DRAKE = val++;
exports.MONS_SKELETON_HYDRA = val++;
exports.MONS_SKELETON_HYDRA_1 = val++;
exports.MONS_SKELETON_HYDRA_2 = val++;
exports.MONS_SKELETON_HYDRA_3 = val++;
exports.MONS_SKELETON_HYDRA_4 = val++;
exports.MONS_SKELETON_UGLY_THING = val++;
exports.MONS_SKELETON_DRACONIAN = val++;
exports.MONS_SIMULACRUM_SMALL = val++;
exports.MONS_SIMULACRUM_LARGE = val++;
exports.MONS_SIMULACRUM_QUADRUPED_SMALL = val++;
exports.MONS_SIMULACRUM_QUADRUPED_LARGE = val++;
exports.MONS_SIMULACRUM_BAT = val++;
exports.MONS_SIMULACRUM_BEE = val++;
exports.MONS_SIMULACRUM_BUG = val++;
exports.MONS_SIMULACRUM_FISH = val++;
exports.MONS_SIMULACRUM_CENTAUR = val++;
exports.MONS_SIMULACRUM_NAGA = val++;
exports.MONS_SIMULACRUM_SNAKE = val++;
exports.MONS_SIMULACRUM_LIZARD = val++;
exports.MONS_SIMULACRUM_SPIDER = val++;
exports.MONS_SIMULACRUM_DRAGON = val++;
exports.MONS_SIMULACRUM_KRAKEN = val++;
exports.MONS_SIMULACRUM_DRAKE = val++;
exports.MONS_SIMULACRUM_HYDRA = val++;
exports.MONS_SIMULACRUM_HYDRA_1 = val++;
exports.MONS_SIMULACRUM_HYDRA_2 = val++;
exports.MONS_SIMULACRUM_HYDRA_3 = val++;
exports.MONS_SIMULACRUM_HYDRA_4 = val++;
exports.MONS_SPECTRAL_SMALL = val++;
exports.MONS_SPECTRAL_LARGE = val++;
exports.MONS_SPECTRAL_QUADRUPED_SMALL = val++;
exports.MONS_SPECTRAL_QUADRUPED_LARGE = val++;
exports.MONS_SPECTRAL_FROG = val++;
exports.MONS_SPECTRAL_BAT = val++;
exports.MONS_SPECTRAL_BEE = val++;
exports.MONS_SPECTRAL_BUG = val++;
exports.MONS_SPECTRAL_FISH = val++;
exports.MONS_SPECTRAL_CENTAUR = val++;
exports.MONS_SPECTRAL_NAGA = val++;
exports.MONS_SPECTRAL_SNAKE = val++;
exports.MONS_SPECTRAL_LIZARD = val++;
exports.MONS_SPECTRAL_SPIDER = val++;
exports.MONS_SPECTRAL_DRAGON = val++;
exports.MONS_SPECTRAL_KRAKEN = val++;
exports.MONS_SPECTRAL_DRAKE = val++;
exports.MONS_SPECTRAL_HYDRA = val++;
exports.MONS_SPECTRAL_HYDRA_1 = val++;
exports.MONS_SPECTRAL_HYDRA_2 = val++;
exports.MONS_SPECTRAL_HYDRA_3 = val++;
exports.MONS_SPECTRAL_HYDRA_4 = val++;
exports.MONS_TIAMAT = val++;
exports.MONS_TIAMAT_1 = val++;
exports.MONS_TIAMAT_2 = val++;
exports.MONS_TIAMAT_3 = val++;
exports.MONS_TIAMAT_4 = val++;
exports.MONS_TIAMAT_5 = val++;
exports.MONS_TIAMAT_6 = val++;
exports.MONS_TIAMAT_7 = val++;
exports.MONS_TIAMAT_8 = val++;
exports.MONS_BAI_SUZHEN = val++;
exports.MONS_BAI_SUZHEN_DRAGON = val++;
exports.DRACO_BASE = val++;
exports.DRACO_BASE_1 = val++;
exports.DRACO_BASE_2 = val++;
exports.DRACO_BASE_3 = val++;
exports.DRACO_BASE_4 = val++;
exports.DRACO_BASE_5 = val++;
exports.DRACO_BASE_6 = val++;
exports.DRACO_BASE_7 = val++;
exports.DRACO_BASE_8 = val++;
exports.DRACO_BASE_9 = val++;
exports.DRACO_ANNIHILATOR = val++;
exports.DRACO_STORMCALLER = val++;
exports.DRACO_KNIGHT = val++;
exports.DRACO_MONK = val++;
exports.DRACO_SCORCHER = val++;
exports.DRACO_SHIFTER = val++;
exports.MONS_FAINT_GREY_DRACONIAN_MONK = val++;
exports.MONS_TEST_SPAWNER = val++;
exports.PLAYER = val++;
exports.TRAN_BAT = val++;
exports.TRAN_SPIDER = val++;
exports.TRAN_PIG = val++;
exports.TRAN_ICE_BEAST = val++;
exports.TRAN_STATUE_HUMANOID = val++;
val = exports.TRAN_STATUE_EQUIP_FIRST = exports.TRAN_STATUE_HUMANOID; val++;
exports.TRAN_STATUE_CENTAUR = val++;
exports.TRAN_STATUE_NAGA = val++;
exports.TRAN_STATUE_OCTOPODE = val++;
val = exports.TRAN_STATUE_EQUIP_LAST = exports.TRAN_STATUE_OCTOPODE; val++;
exports.TRAN_STATUE_FELID = val++;
exports.TRAN_DRAGON = val++;
exports.TRAN_DRAGON_RED = val++;
exports.TRAN_DRAGON_WHITE = val++;
exports.TRAN_DRAGON_GREEN = val++;
exports.TRAN_DRAGON_YELLOW = val++;
exports.TRAN_DRAGON_GREY = val++;
exports.TRAN_DRAGON_BLACK = val++;
exports.TRAN_DRAGON_PURPLE = val++;
exports.TRAN_DRAGON_PALE = val++;
exports.TRAN_LICH_HUMANOID = val++;
val = exports.TRAN_LICH_EQUIP_FIRST = exports.TRAN_LICH_HUMANOID; val++;
exports.TRAN_LICH_CENTAUR = val++;
exports.TRAN_LICH_NAGA = val++;
exports.TRAN_LICH_OCTOPODE = val++;
val = exports.TRAN_LICH_EQUIP_LAST = exports.TRAN_LICH_OCTOPODE; val++;
exports.TRAN_LICH_FELID = val++;
exports.TRAN_TREE = val++;
exports.TRAN_MUSHROOM = val++;
exports.TRAN_SHADOW = val++;
exports.MONS_UNKNOWN = val++;
exports.MCACHE_START = val++;
exports.TODO = val++;
exports.ERROR = val++;
exports.MONS_GIAGGOSTUONO = val++;
exports.MONS_JORMUNGANDR = val++;
exports.MONS_LAMIA = val++;
exports.MONS_MAUD = val++;
exports.MONS_OLD_SERPENT_COC = val++;
exports.MONS_OLD_SERPENT_DIS = val++;
exports.MONS_OLD_SERPENT_GEH = val++;
exports.MONS_OLD_SERPENT_TAR = val++;
exports.MONS_WIGLAF = val++;
exports.MONS_ORB_GUARDIAN_FETUS = val++;
exports.MONS_POLYMOTH = val++;
exports.TRAP_NET = val++;
exports.CURSOR = val++;
exports.BASE_HUMAN = val++;
exports.HUMAN_1 = val++;
exports.HUMAN_2 = val++;
exports.HUMAN_3 = val++;
exports.HUMAN_4 = val++;
exports.HUMAN_5 = val++;
exports.BASE_ELF = val++;
exports.ELF_1 = val++;
exports.BASE_DEEP_ELF = val++;
exports.DEEP_ELF_1 = val++;
exports.BASE_DWARF = val++;
exports.DWARF_1 = val++;
exports.BASE_BARACHI = val++;
exports.BARACHI_1 = val++;
exports.BARACHI_2 = val++;
exports.BARACHI_3 = val++;
exports.BASE_GNOLL = val++;
exports.GNOLL_1 = val++;
exports.GNOLL_2 = val++;
exports.GNOLL_3 = val++;
exports.GNOLL_4 = val++;
exports.GNOLL_5 = val++;
exports.GNOLL_6 = val++;
exports.GNOLL_7 = val++;
exports.GNOLL_8 = val++;
exports.GNOLL_9 = val++;
exports.BASE_HALFLING = val++;
exports.HALFLING_1 = val++;
exports.BASE_ORC = val++;
exports.ORC_1 = val++;
exports.BASE_LAVA_ORC = val++;
exports.LAVA_ORC_1 = val++;
exports.BASE_LAVA_ORC_HEAT = val++;
exports.LAVA_ORC_HEAT_1 = val++;
exports.LAVA_ORC_HEAT_2 = val++;
exports.LAVA_ORC_HEAT_3 = val++;
exports.LAVA_ORC_HEAT_4 = val++;
exports.LAVA_ORC_HEAT_5 = val++;
exports.LAVA_ORC_HEAT_6 = val++;
exports.LAVA_ORC_HEAT_7 = val++;
exports.LAVA_ORC_HEAT_8 = val++;
exports.LAVA_ORC_HEAT_9 = val++;
exports.LAVA_ORC_HEAT_10 = val++;
exports.LAVA_ORC_HEAT_11 = val++;
exports.BASE_KOBOLD = val++;
exports.KOBOLD_1 = val++;
exports.KOBOLD_2 = val++;
exports.KOBOLD_3 = val++;
exports.BASE_MUMMY = val++;
exports.MUMMY_1 = val++;
exports.BASE_NAGA = val++;
exports.NAGA_1 = val++;
exports.NAGA_2 = val++;
exports.NAGA_3 = val++;
exports.NAGA_4 = val++;
exports.NAGA_5 = val++;
exports.NAGA_6 = val++;
exports.NAGA_7 = val++;
exports.NAGA_8 = val++;
exports.NAGA_9 = val++;
exports.BASE_OGRE = val++;
exports.OGRE_1 = val++;
exports.BASE_TROLL = val++;
exports.TROLL_1 = val++;
exports.BASE_OCTOPODE = val++;
exports.OCTOPODE_1 = val++;
exports.OCTOPODE_2 = val++;
exports.OCTOPODE_3 = val++;
exports.OCTOPODE_4 = val++;
exports.BASE_DJINNI = val++;
exports.DJINNI_1 = val++;
exports.BASE_FORMICID = val++;
exports.BASE_VINE_STALKER = val++;
exports.VINE_STALKER_1 = val++;
exports.BASE_DRACONIAN = val++;
val = exports.BASE_DRACONIAN_FIRST = exports.BASE_DRACONIAN; val++;
exports.DRACONIAN_1 = val++;
exports.BASE_DRACONIAN_BLACK = val++;
exports.DRACONIAN_BLACK_1 = val++;
exports.BASE_DRACONIAN_GOLD = val++;
exports.DRACONIAN_GOLD_1 = val++;
exports.BASE_DRACONIAN_GREY = val++;
exports.DRACONIAN_GREY_1 = val++;
exports.BASE_DRACONIAN_GREEN = val++;
exports.DRACONIAN_GREEN_1 = val++;
exports.BASE_DRACONIAN_PALE = val++;
exports.DRACONIAN_PALE_1 = val++;
exports.BASE_DRACONIAN_PURPLE = val++;
exports.DRACONIAN_PURPLE_1 = val++;
exports.BASE_DRACONIAN_RED = val++;
exports.DRACONIAN_RED_1 = val++;
exports.BASE_DRACONIAN_WHITE = val++;
exports.BASE_DRACONIAN_LAST = val++;
exports.BASE_CENTAUR = val++;
exports.CENTAUR_1 = val++;
exports.CENTAUR_2 = val++;
exports.CENTAUR_3 = val++;
exports.CENTAUR_4 = val++;
exports.CENTAUR_5 = val++;
exports.CENTAUR_6 = val++;
exports.CENTAUR_7 = val++;
exports.CENTAUR_8 = val++;
exports.CENTAUR_9 = val++;
exports.BASE_DEMIGOD = val++;
exports.DEMIGOD_1 = val++;
exports.BASE_SPRIGGAN = val++;
exports.SPRIGGAN_1 = val++;
exports.BASE_MINOTAUR = val++;
exports.MINOTAUR_1 = val++;
exports.MINOTAUR_2 = val++;
exports.MINOTAUR_3 = val++;
exports.BASE_DEMONSPAWN = val++;
exports.DEMONSPAWN_1 = val++;
exports.DEMONSPAWN_2 = val++;
exports.DEMONSPAWN_3 = val++;
exports.DEMONSPAWN_4 = val++;
exports.BASE_GHOUL = val++;
exports.GHOUL_1 = val++;
exports.GHOUL_2 = val++;
exports.BASE_TENGU = val++;
exports.TENGU_1 = val++;
exports.TENGU_2 = val++;
exports.TENGU_3 = val++;
exports.TENGU_4 = val++;
exports.TENGU_5 = val++;
exports.BASE_MERFOLK = val++;
exports.MERFOLK_1 = val++;
exports.BASE_MERFOLK_WATER = val++;
exports.MERFOLK_WATER_1 = val++;
exports.BASE_VAMPIRE = val++;
exports.VAMPIRE_1 = val++;
exports.BASE_DEEP_DWARF = val++;
exports.DEEP_DWARF_1 = val++;
exports.BASE_GARGOYLE = val++;
exports.GARGOYLE_1 = val++;
exports.GARGOYLE_2 = val++;
exports.GARGOYLE_3 = val++;
exports.GARGOYLE_4 = val++;
exports.GARGOYLE_5 = val++;
exports.BASE_FELID = val++;
exports.FELID_1 = val++;
exports.FELID_2 = val++;
exports.FELID_3 = val++;
exports.FELID_4 = val++;
exports.FELID_5 = val++;
exports.FELID_6 = val++;
exports.FELID_7 = val++;
exports.FELID_8 = val++;
exports.FELID_9 = val++;
exports.SHADOW_SHADOW = val++;
exports.HALO_TSO = val++;
exports.ENCH_STICKY_FLAME = val++;
exports.CLOAK_RED = val++;
val = exports.CLOAK_FIRST_NORM = exports.CLOAK_RED; val++;
exports.CLOAK_BLUE = val++;
exports.CLOAK_MAGENTA = val++;
exports.CLOAK_YELLOW = val++;
exports.CLOAK_BLACK = val++;
exports.CLOAK_GRAY = val++;
exports.CLOAK_LBROWN = val++;
exports.CLOAK_GREEN = val++;
exports.CLOAK_CYAN = val++;
exports.CLOAK_WHITE = val++;
val = exports.CLOAK_LAST_NORM = exports.CLOAK_WHITE; val++;
exports.CLOAK_RATSKIN_CLOAK = val++;
exports.CLOAK_DRAGONSKIN_CLOAK = val++;
exports.CLOAK_SCARF_CYAN = val++;
val = exports.CLOAK_SCARF_FIRST_NORM = exports.CLOAK_SCARF_CYAN; val++;
exports.CLOAK_SCARF_RED = val++;
exports.CLOAK_SCARF_WHITE = val++;
exports.CLOAK_SCARF_MAGENTA = val++;
exports.CLOAK_SCARF_GREEN = val++;
val = exports.CLOAK_SCARF_LAST_NORM = exports.CLOAK_SCARF_GREEN; val++;
exports.BOOTS_SHORT_RED = val++;
val = exports.BOOTS_FIRST_NORM = exports.BOOTS_SHORT_RED; val++;
exports.BOOTS_SHORT_PURPLE = val++;
exports.BOOTS_SHORT_BROWN = val++;
exports.BOOTS_SHORT_BROWN2 = val++;
exports.BOOTS_PJ = val++;
exports.BOOTS_MIDDLE_BROWN = val++;
exports.BOOTS_MIDDLE_GRAY = val++;
exports.BOOTS_MIDDLE_YBROWN = val++;
exports.BOOTS_MIDDLE_BROWN2 = val++;
exports.BOOTS_MIDDLE_BROWN3 = val++;
exports.BOOTS_MIDDLE_GOLD = val++;
exports.BOOTS_MIDDLE_GREEN = val++;
exports.BOOTS_MIDDLE_PURPLE = val++;
exports.BOOTS_LONG_RED = val++;
exports.BOOTS_LONG_WHITE = val++;
exports.BOOTS_BLUE_GOLD = val++;
exports.BOOTS_MESH_RED = val++;
exports.BOOTS_MESH_BLACK = val++;
exports.BOOTS_MESH_WHITE = val++;
exports.BOOTS_MESH_BLUE = val++;
val = exports.BOOTS_LAST_NORM = exports.BOOTS_MESH_BLUE; val++;
exports.BOOTS_SPIDER = val++;
exports.BOOTS_HOOVES = val++;
exports.BOOTS_NAGA_BARDING = val++;
exports.BOOTS_NAGA_BARDING_METAL = val++;
exports.BOOTS_NAGA_BARDING_MAGENTA = val++;
exports.BOOTS_NAGA_BARDING_RED = val++;
exports.BOOTS_CENTAUR_BARDING = val++;
exports.BOOTS_CENTAUR_BARDING_METAL = val++;
exports.BOOTS_CENTAUR_BARDING_MAGENTA = val++;
exports.BOOTS_CENTAUR_BARDING_RED = val++;
exports.BOOTS_LIGHTNING_SCALES = val++;
exports.BOOTS_BLACK_KNIGHT = val++;
exports.LEG_BIKINI_RED = val++;
exports.LEG_LOINCLOTH_RED = val++;
exports.LEG_BELT_REDBROWN = val++;
exports.LEG_PJ = val++;
exports.LEG_PANTS_TROUSER_GREEN = val++;
exports.LEG_PANTS_CHUN_LI = val++;
exports.LEG_BELT_GRAY = val++;
val = exports.LEG_FIRST_NORM = exports.LEG_BELT_GRAY; val++;
exports.LEG_PANTS_ORANGE = val++;
exports.LEG_PANTS_SHORT_GRAY = val++;
exports.LEG_PANTS_GARTER = val++;
exports.LEG_PANTS_BLACK = val++;
exports.LEG_PANTS_BLUE = val++;
exports.LEG_PANTS_DARKGREEN = val++;
exports.LEG_PANTS_BROWN = val++;
exports.LEG_PANTS_SHORT_DARKBROWN = val++;
exports.LEG_PANTS_SHORT_BROWN = val++;
exports.LEG_PANTS_SHORT_DARK_BROWN = val++;
exports.LEG_PANTS_LONG_WHITE = val++;
exports.LEG_PANTS_LONG_RED = val++;
exports.LEG_PANTS_RED = val++;
exports.LEG_METAL_RED = val++;
exports.LEG_METAL_SILVER = val++;
exports.LEG_METAL_GRAY = val++;
exports.LEG_METAL_GREEN = val++;
exports.LEG_LEGCHAIN_GRAY = val++;
exports.LEG_LEGCHAIN_SILVER = val++;
val = exports.LEG_LAST_NORM = exports.LEG_LEGCHAIN_SILVER; val++;
exports.LEG_SKIRT_BLUE = val++;
val = exports.LEG_SKIRT_OFS = exports.LEG_SKIRT_BLUE; val++;
exports.LEG_SKIRT_GREEN = val++;
exports.LEG_SKIRT_WHITE = val++;
exports.LEG_SKIRT_RED = val++;
exports.LEG_SKIRT_SHORT = val++;
exports.LEG_LOWARM1 = val++;
exports.LEG_LOWARM2 = val++;
exports.LEG_LOWARM3 = val++;
exports.BODY_ROBE_BLUE = val++;
val = exports.BODY_ROBE_FIRST_NORM = exports.BODY_ROBE_BLUE; val++;
exports.BODY_ROBE_BLACK = val++;
exports.BODY_ROBE_WHITE = val++;
exports.BODY_ROBE_RED = val++;
exports.BODY_ROBE_MAGENTA = val++;
exports.BODY_ROBE_GREEN = val++;
exports.BODY_ROBE_YELLOW = val++;
exports.BODY_ROBE_BROWN = val++;
exports.BODY_ROBE_CYAN = val++;
exports.BODY_GANDALF_G = val++;
exports.BODY_SARUMAN = val++;
exports.BODY_ROBE_BLACK_HOOD = val++;
exports.BODY_MONK_BLUE = val++;
exports.BODY_MONK_BLACK = val++;
exports.BODY_ROBE_BLACK_GOLD = val++;
exports.BODY_ROBE_WHITE2 = val++;
exports.BODY_ROBE_WHITE_RED = val++;
exports.BODY_ROBE_WHITE_GREEN = val++;
exports.BODY_ROBE_BLUE_WHITE = val++;
exports.BODY_ROBE_RED_GOLD = val++;
exports.BODY_ROBE_BLACK_RED = val++;
exports.BODY_ROBE_BLUE_GREEN = val++;
exports.BODY_ROBE_RED3 = val++;
exports.BODY_ROBE_BROWN2 = val++;
exports.BODY_ROBE_GREEN_GOLD = val++;
exports.BODY_ROBE_BROWN3 = val++;
exports.BODY_ROBE_GRAY2 = val++;
val = exports.BODY_ROBE_LAST_NORM = exports.BODY_ROBE_GRAY2; val++;
exports.BODY_ROBE_RAINBOW = val++;
exports.BODY_DRESS_GREEN = val++;
exports.BODY_DRESS_WHITE = val++;
exports.BODY_ARWEN = val++;
exports.BODY_SKIRT_ONEP_GREY = val++;
exports.BODY_BLOODY = val++;
exports.BODY_LEATHER_SHORT = val++;
exports.BODY_CHINA_RED2 = val++;
exports.BODY_ROBE_JESTER = val++;
exports.BODY_ROBE_MISFORTUNE = val++;
exports.BODY_ROBE_CLOUDS = val++;
exports.BODY_ROBE_AUGMENTATION = val++;
exports.BODY_ROBE_OF_NIGHT = val++;
exports.BODY_ROBE_FOLLY = val++;
exports.BODY_ANIMAL_SKIN = val++;
exports.BODY_ZHOR = val++;
exports.BODY_NECK = val++;
exports.BODY_BELT1 = val++;
exports.BODY_BELT2 = val++;
exports.BODY_SUSP_BLACK = val++;
exports.BODY_SHOULDER_PAD = val++;
exports.BODY_MESH_BLACK = val++;
exports.BODY_MESH_RED = val++;
exports.BODY_LEATHER_JACKET = val++;
exports.BODY_SHIRT_WHITE1 = val++;
exports.BODY_SHIRT_WHITE2 = val++;
exports.BODY_SHIRT_WHITE3 = val++;
exports.BODY_SHIRT_BLUE = val++;
exports.BODY_BIKINI_RED = val++;
exports.BODY_SHIRT_HAWAII = val++;
exports.BODY_CHINA_RED = val++;
exports.BODY_LEATHER_RED = val++;
exports.BODY_CHUNLI = val++;
exports.BODY_SHIRT_WHITE_YELLOW = val++;
exports.BODY_SHIRT_CHECK = val++;
exports.BODY_JESSICA = val++;
exports.BODY_SLIT_BLACK = val++;
exports.BODY_LEATHER_GREEN = val++;
exports.BODY_SHIRT_BLACK = val++;
exports.BODY_SHIRT_BLACK_AND_CLOTH = val++;
exports.BODY_SHIRT_BLACK3 = val++;
exports.BODY_LEATHER2 = val++;
exports.BODY_COAT_RED = val++;
exports.BODY_COAT_BLACK = val++;
exports.BODY_LEATHER_ARMOUR = val++;
exports.LEATHER_ARMOUR_1 = val++;
exports.LEATHER_ARMOUR_2 = val++;
exports.BODY_SHIRT_VEST = val++;
exports.BODY_KARATE = val++;
exports.BODY_KARATE2 = val++;
exports.BODY_LEATHER_HEAVY = val++;
exports.BODY_TROLL_HIDE = val++;
exports.BODY_TROLL_LEATHER = val++;
exports.BODY_GREEN_CHAIN = val++;
exports.BODY_METAL_BLUE = val++;
exports.BODY_GREEN_SUSP = val++;
exports.BODY_JACKET2 = val++;
exports.BODY_JACKET3 = val++;
exports.BODY_LEATHER_STUD = val++;
exports.BODY_JACKET_STUD = val++;
exports.BODY_HALF_PLATE = val++;
exports.BODY_HALF_PLATE2 = val++;
exports.BODY_HALF_PLATE3 = val++;
exports.BODY_BREAST_BLACK = val++;
exports.BODY_VEST_RED = val++;
exports.BODY_VEST_RED2 = val++;
exports.BODY_BPLATE_GREEN = val++;
exports.BODY_BPLATE_METAL1 = val++;
exports.BPLATE_METAL1_1 = val++;
exports.BODY_RINGMAIL = val++;
exports.RINGMAIL_1 = val++;
exports.RINGMAIL_2 = val++;
exports.BODY_CHAINMAIL = val++;
exports.CHAINMAIL_1 = val++;
exports.CHAINMAIL_2 = val++;
exports.BODY_PLATE_AND_CLOTH = val++;
exports.BODY_PLATE_AND_CLOTH2 = val++;
exports.BODY_SCALEMAIL = val++;
exports.SCALEMAIL_1 = val++;
exports.SCALEMAIL_2 = val++;
exports.BODY_SCALEMAIL_LIGHT = val++;
exports.BODY_LEATHER_METAL = val++;
exports.BODY_PLATE = val++;
exports.PLATE_1 = val++;
exports.PLATE_2 = val++;
exports.BODY_PLATE_BLACK = val++;
exports.BODY_CRYSTAL_PLATE = val++;
exports.CRYSTAL_PLATE_1 = val++;
exports.CRYSTAL_PLATE_2 = val++;
exports.BODY_ARMOUR_MUMMY = val++;
exports.BODY_DRAGONARM_RED = val++;
exports.BODY_DRAGONARM_WHITE = val++;
exports.BODY_DRAGONARM_YELLOW = val++;
exports.BODY_DRAGONARM_QUICKSILVER = val++;
exports.BODY_DRAGONARM_CYAN = val++;
exports.BODY_DRAGONARM_BROWN = val++;
exports.BODY_DRAGONARM_BLUE = val++;
exports.BODY_DRAGONARM_SHADOW = val++;
exports.BODY_DRAGONARM_GOLD = val++;
exports.BODY_DRAGONARM_PEARL = val++;
exports.BODY_ARAGORN = val++;
exports.BODY_ARAGORN2 = val++;
exports.BODY_BOROMIR = val++;
exports.BODY_FRODO = val++;
exports.BODY_GIMLI = val++;
exports.BODY_LEGOLAS = val++;
exports.BODY_MERRY = val++;
exports.BODY_PIPIN = val++;
exports.BODY_GILGALAD = val++;
exports.BODY_ISILDUR = val++;
exports.BODY_PJ = val++;
exports.BODY_SAM = val++;
exports.BODY_VANHEL = val++;
exports.BODY_DEEP_TROLL_LEATHER = val++;
exports.BODY_IRON_TROLL_LEATHER = val++;
exports.BODY_MAXWELL = val++;
exports.BODY_LEARS_HAUBERK = val++;
exports.BODY_FAERIE_DRAGON_ARMOUR = val++;
exports.BODY_MOON_TROLL_LEATHER_ARMOUR = val++;
exports.BODY_ORANGE_CRYSTAL = val++;
exports.BODY_VINES = val++;
exports.BODY_KRYIAS = val++;
exports.BODY_TALOS = val++;
exports.ARM_GLOVE_RED = val++;
val = exports.ARM_FIRST_NORM = exports.ARM_GLOVE_RED; val++;
exports.ARM_GLOVE_GRAY = val++;
exports.ARM_GLOVE_WHITE = val++;
exports.ARM_GLOVE_BLUE = val++;
exports.ARM_GLOVE_BLACK = val++;
exports.ARM_GLOVE_ORANGE = val++;
exports.ARM_GLOVE_BROWN = val++;
exports.ARM_GLOVE_BLACK2 = val++;
exports.ARM_GLOVE_GRAYFIST = val++;
exports.ARM_GLOVE_PURPLE = val++;
exports.ARM_GLOVE_WRIST_PURPLE = val++;
exports.ARM_GLOVE_CHUNLI = val++;
exports.ARM_GAUNTLET_BLUE = val++;
exports.ARM_GLOVE_GOLD = val++;
exports.ARM_GLOVE_SHORT_YELLOW = val++;
exports.ARM_GLOVE_SHORT_RED = val++;
exports.ARM_GLOVE_SHORT_WHITE = val++;
exports.ARM_GLOVE_SHORT_GREEN = val++;
exports.ARM_GLOVE_SHORT_BLUE = val++;
exports.ARM_GLOVE_SHORT_GRAY = val++;
val = exports.ARM_LAST_NORM = exports.ARM_GLOVE_SHORT_GRAY; val++;
exports.ARM_CLAWS = val++;
exports.ARM_OCTOPODE_SPIKE = val++;
exports.HAND1_BLOODBANE = val++;
exports.HAND1_DOOM_KNIGHT = val++;
exports.HAND1_LEECH = val++;
exports.HAND1_MORG = val++;
exports.HAND1_PLUTONIUM_SWORD = val++;
exports.HAND1_ZEALOT_SWORD = val++;
exports.HAND1_SINGING_SWORD = val++;
exports.HAND1_ZONGULDROK = val++;
exports.HAND1_SWORD_OF_POWER = val++;
exports.HAND1_KNIFE_OF_ACCURACY = val++;
exports.HAND1_VAMPIRES_TOOTH = val++;
exports.HAND1_SPRIGGANS_KNIFE = val++;
exports.HAND1_CAPT_CUTLASS = val++;
exports.HAND1_ARC_BLADE = val++;
exports.HAND1_GYRE = val++;
exports.HAND1_THERMIC_ENGINE = val++;
exports.HAND1_WUCAD_MU = val++;
exports.HAND1_MACE_OF_VARIABILITY = val++;
exports.HAND1_MACE_OF_BRILLIANCE = val++;
exports.HAND1_UNDEADHUNTER = val++;
exports.HAND1_EOS = val++;
exports.HAND1_SNAKEBITE = val++;
exports.HAND1_SHILLELAGH = val++;
exports.HAND1_DARK_MAUL = val++;
exports.HAND1_SPELLBINDER = val++;
exports.HAND1_FIRESTARTER = val++;
exports.HAND1_MAJIN = val++;
exports.HAND1_TRIDENT_OCTOPUS_KING = val++;
exports.HAND1_GLAIVE_OF_PRUNE = val++;
exports.HAND1_FINISHER = val++;
exports.HAND1_GLAIVE_OF_THE_GUARD = val++;
exports.HAND1_WYRMBANE = val++;
exports.HAND1_RIFT = val++;
exports.HAND1_ELEMENTAL_STAFF = val++;
exports.HAND1_ASMODEUS = val++;
exports.HAND1_DISPATER = val++;
exports.HAND1_OLGREB = val++;
exports.HAND1_ORDER = val++;
exports.HAND1_BATTLE_STAFF = val++;
exports.HAND1_AXE_TROG = val++;
exports.HAND1_ARGA = val++;
exports.HAND1_DEMON_AXE = val++;
exports.HAND1_AXE_OF_WOE = val++;
exports.HAND1_FROSTBITE = val++;
exports.HAND1_BLOWGUN_ASSASSIN = val++;
exports.HAND1_PUNK = val++;
exports.HAND1_SNIPER = val++;
exports.HAND1_FIERY_DEVIL = val++;
exports.HAND1_ZEPHYR = val++;
exports.HAND1_SCEPTRE_OF_TORMENT = val++;
exports.HAND1_BOTONO = val++;
exports.HAND1_CHILLY_DEATH = val++;
exports.HAND1_CRYSTAL_SPEAR = val++;
exports.HAND1_FLAMING_DEATH = val++;
exports.HAND1_DAGGER = val++;
exports.DAGGER_1 = val++;
exports.HAND1_DAGGER_SLANT = val++;
exports.DAGGER_SLANT_1 = val++;
exports.HAND1_SHORT_SWORD = val++;
exports.HAND1_SHORT_SWORD_SLANT = val++;
exports.SHORT_SWORD_SLANT_1 = val++;
exports.HAND1_SHORT_SWORD2 = val++;
exports.HAND1_SWORD_THIEF = val++;
exports.HAND1_DOUBLE_SWORD = val++;
exports.DOUBLE_SWORD_1 = val++;
exports.DOUBLE_SWORD_2 = val++;
exports.HAND1_LONG_SWORD_SLANT = val++;
exports.LONG_SWORD_SLANT_1 = val++;
exports.HAND1_BLESSED_BLADE = val++;
exports.HAND1_GREAT_SWORD_SLANT = val++;
exports.GREAT_SWORD_SLANT_1 = val++;
exports.HAND1_TRIPLE_SWORD = val++;
exports.TRIPLE_SWORD_1 = val++;
exports.HAND1_KATANA_SLANT = val++;
exports.HAND1_SCIMITAR = val++;
exports.SCIMITAR_1 = val++;
exports.HAND1_FALCHION = val++;
exports.FALCHION_1 = val++;
exports.HAND1_SWORD2 = val++;
exports.HAND1_BROADSWORD = val++;
exports.HAND1_BLACK_SWORD = val++;
exports.HAND1_SWORD_BLACK = val++;
exports.HAND1_SWORD_TWIST = val++;
exports.HAND1_KNIFE = val++;
exports.HAND1_HEAVY_SWORD = val++;
exports.HAND1_RAPIER = val++;
exports.RAPIER_1 = val++;
exports.HAND1_SWORD3 = val++;
exports.HAND1_SWORD_BREAKER = val++;
exports.HAND1_SWORD_JAG = val++;
exports.HAND1_DEMON_BLADE = val++;
exports.HAND1_ENCHANTRESS_DAGGER = val++;
exports.HAND1_CLUB = val++;
exports.HAND1_CLUB_SLANT = val++;
exports.HAND1_CLUB2 = val++;
exports.HAND1_CLUB3 = val++;
exports.HAND1_STICK = val++;
exports.HAND1_GIANT_CLUB = val++;
exports.HAND1_GIANT_CLUB_SLANT = val++;
exports.HAND1_GIANT_CLUB_SPIKE = val++;
exports.HAND1_GIANT_CLUB_SPIKE_SLANT = val++;
exports.HAND1_GIANT_CLUB_PLAIN = val++;
exports.HAND1_WHIP = val++;
exports.WHIP_1 = val++;
exports.HAND1_SCEPTRE = val++;
exports.HAND1_MACE2 = val++;
exports.HAND1_MACE = val++;
exports.MACE_1 = val++;
exports.HAND1_GREAT_MACE = val++;
exports.GREAT_MACE_1 = val++;
exports.HAND1_MACE_RUBY = val++;
exports.HAND1_MORNINGSTAR2 = val++;
exports.HAND1_MORNINGSTAR = val++;
exports.MORNINGSTAR_1 = val++;
exports.HAND1_EVENINGSTAR = val++;
exports.EVENINGSTAR_1 = val++;
exports.HAND1_LARGE_MACE = val++;
exports.HAND1_BLACK_WHIP = val++;
exports.HAND1_SACRED_SCOURGE = val++;
exports.HAND1_SACRED_SCOURGE2 = val++;
exports.HAND1_FLAIL_STICK = val++;
exports.HAND1_FLAIL = val++;
exports.FLAIL_1 = val++;
exports.HAND1_GREAT_FLAIL = val++;
exports.GREAT_FLAIL_1 = val++;
exports.HAND1_FLAIL_STICK_SLANT = val++;
exports.HAND1_FLAIL_BALL2 = val++;
exports.HAND1_FLAIL_BALLS = val++;
exports.HAND1_FLAIL_BALL3 = val++;
exports.HAND1_FLAIL_BALL4 = val++;
exports.HAND1_NUNCHAKU = val++;
exports.HAND1_SPEAR = val++;
exports.SPEAR_1 = val++;
exports.HAND1_SPEAR2 = val++;
exports.HAND1_SPEAR3 = val++;
exports.HAND1_SPEAR4 = val++;
exports.HAND1_SPEAR5 = val++;
exports.HAND1_HOOK = val++;
exports.HAND1_HALBERD = val++;
exports.HALBERD_1 = val++;
exports.HAND1_PICK_AXE = val++;
exports.HAND1_TRIDENT = val++;
exports.HAND1_DEMON_TRIDENT = val++;
exports.HAND1_TRIDENT_ELEC = val++;
exports.HAND1_TRIDENT2 = val++;
exports.TRIDENT2_1 = val++;
exports.HAND1_TRIDENT3 = val++;
exports.HAND1_LANCE = val++;
exports.HAND1_LANCE2 = val++;
exports.HAND1_SCYTHE = val++;
exports.SCYTHE_1 = val++;
exports.HAND1_SCYTHE_SLANT = val++;
exports.HAND1_PIKE = val++;
exports.HAND1_STAFF = val++;
exports.HAND1_QUARTERSTAFF1 = val++;
exports.QUARTERSTAFF1_1 = val++;
exports.HAND1_QUARTERSTAFF2 = val++;
exports.HAND1_QUARTERSTAFF3 = val++;
exports.HAND1_QUARTERSTAFF4 = val++;
exports.HAND1_QUARTERSTAFF_JESTER = val++;
exports.HAND1_SICKLE = val++;
exports.HAND1_GLAIVE = val++;
exports.GLAIVE_1 = val++;
exports.HAND1_GLAIVE2 = val++;
exports.HAND1_GLAIVE3 = val++;
exports.GLAIVE3_1 = val++;
exports.HAND1_D_GLAIVE = val++;
exports.HAND1_POLE_FORKED = val++;
exports.HAND1_FORK2 = val++;
exports.HAND1_TRISHULA = val++;
exports.HAND1_LAJATANG = val++;
exports.LAJATANG_1 = val++;
exports.LAJATANG_2 = val++;
exports.HAND1_STAFF_LARGE = val++;
exports.HAND1_GREAT_STAFF = val++;
exports.HAND1_STAFF_MAGE = val++;
exports.HAND1_STAFF_MAGE2 = val++;
exports.HAND1_STAFF_PLAIN = val++;
exports.HAND1_STAFF_ORGANIC = val++;
exports.HAND1_STAFF_SKULL = val++;
exports.HAND1_STAFF_SCEPTRE = val++;
exports.HAND1_STAFF_RUBY = val++;
exports.HAND1_STAFF_FANCY = val++;
exports.HAND1_STAFF_EVIL = val++;
exports.HAND1_STAFF_RING_BLUE = val++;
exports.HAND1_STAFF_MUMMY = val++;
exports.HAND1_STAFF_FORK = val++;
exports.HAND1_ROD_FIRST = val++;
exports.ROD_FIRST_1 = val++;
exports.ROD_FIRST_2 = val++;
exports.ROD_FIRST_3 = val++;
exports.ROD_FIRST_4 = val++;
exports.ROD_FIRST_5 = val++;
exports.ROD_FIRST_6 = val++;
exports.ROD_FIRST_7 = val++;
exports.ROD_FIRST_8 = val++;
exports.ROD_FIRST_9 = val++;
exports.HAND1_AXE_SMALL = val++;
exports.HAND1_HAND_AXE = val++;
exports.HAND_AXE_1 = val++;
exports.HAND1_WAR_AXE = val++;
exports.WAR_AXE_1 = val++;
exports.HAND1_BROAD_AXE = val++;
exports.BROAD_AXE_1 = val++;
exports.HAND1_BATTLEAXE = val++;
exports.BATTLEAXE_1 = val++;
exports.HAND1_EXECUTIONERS_AXE = val++;
exports.EXECUTIONERS_AXE_1 = val++;
exports.HAND1_AXE_DOUBLE = val++;
exports.HAND1_AXE_BLOOD = val++;
exports.HAND1_AXE_SHORT = val++;
exports.HAND1_HUNTING_SLING = val++;
exports.HAND1_FUSTIBALUS = val++;
exports.HAND1_BOW = val++;
exports.HAND1_BOW2 = val++;
exports.HAND1_BOW3 = val++;
exports.HAND1_GREAT_BOW = val++;
exports.HAND1_STORM_BOW = val++;
exports.HAND1_HAND_CROSSBOW = val++;
exports.HAND1_ARBALEST = val++;
exports.HAND1_ARBALEST2 = val++;
exports.HAND1_ARBALEST3 = val++;
exports.HAND1_ARBALEST4 = val++;
exports.HAND1_TRIPLE_CROSSBOW = val++;
exports.HAND1_BLOWGUN = val++;
exports.HAND1_DART = val++;
exports.HAND1_ARAGORN = val++;
exports.HAND1_ARWEN = val++;
exports.HAND1_BOROMIR = val++;
exports.HAND1_FRODO = val++;
exports.HAND1_GANDALF = val++;
exports.HAND1_GIMLI = val++;
exports.HAND1_LEGOLAS = val++;
exports.HAND1_SARUMAN = val++;
exports.HAND1_BONE_LANTERN = val++;
exports.HAND1_FAN = val++;
exports.HAND1_BOTTLE = val++;
exports.HAND1_BOX = val++;
exports.HAND1_CRYSTAL = val++;
exports.HAND1_HORN = val++;
exports.HAND1_LANTERN = val++;
exports.HAND1_ORB = val++;
exports.HAND1_STONE = val++;
exports.HAND1_FIRE_RED = val++;
exports.HAND1_FIRE_BLUE = val++;
exports.HAND1_SKULL = val++;
exports.HAND1_HEAD = val++;
exports.HAND1_FIRE_GREEN = val++;
exports.HAND1_FIRE_CYAN = val++;
exports.HAND1_FIRE_WHITE = val++;
exports.HAND1_LIGHT_BLUE = val++;
exports.HAND1_LIGHT_RED = val++;
exports.HAND1_LIGHT_YELLOW = val++;
exports.HAND1_SPARK = val++;
exports.HAND1_FIRE_DARK = val++;
exports.HAND1_FIRE_WHITE2 = val++;
exports.HAND1_BLADEHAND = val++;
exports.HAND1_BLADEHAND_OP = val++;
exports.HAND1_BLADEHAND_FE = val++;
exports.HAND2_BUCKLER_ROUND = val++;
val = exports.HAND2_BUCKLER_FIRST_NORM = exports.HAND2_BUCKLER_ROUND; val++;
exports.HAND2_BUCKLER_ROUND2 = val++;
exports.HAND2_BUCKLER_ROUND3 = val++;
exports.HAND2_BUCKLER_RB = val++;
exports.HAND2_BUCKLER_GREEN = val++;
exports.HAND2_BUCKLER_SPIRAL = val++;
val = exports.HAND2_BUCKLER_LAST_NORM = exports.HAND2_BUCKLER_SPIRAL; val++;
exports.HAND2_SHIELD_KNIGHT_BLUE = val++;
val = exports.HAND2_SHIELD_FIRST_NORM = exports.HAND2_SHIELD_KNIGHT_BLUE; val++;
exports.HAND2_SHIELD_KNIGHT_GRAY = val++;
exports.HAND2_SHIELD_KNIGHT_RW = val++;
exports.HAND2_SHIELD_KITE1 = val++;
exports.HAND2_SHIELD_KITE2 = val++;
exports.HAND2_SHIELD_KITE3 = val++;
exports.HAND2_SHIELD_KITE4 = val++;
val = exports.HAND2_SHIELD_LAST_NORM = exports.HAND2_SHIELD_KITE4; val++;
exports.HAND2_LARGE_SHIELD_LONG_RED = val++;
val = exports.HAND2_LSHIELD_FIRST_NORM = exports.HAND2_LARGE_SHIELD_LONG_RED; val++;
exports.HAND2_LARGE_SHIELD_GOLD = val++;
exports.HAND2_LARGE_SHIELD_GREEN = val++;
exports.HAND2_LARGE_SHIELD_QUARTERED = val++;
exports.HAND2_LARGE_SHIELD_TEAL = val++;
exports.HAND2_LARGE_SHIELD_SPIRAL = val++;
val = exports.HAND2_LSHIELD_LAST_NORM = exports.HAND2_LARGE_SHIELD_SPIRAL; val++;
exports.HAND2_BUCKLER_SPRIGGAN = val++;
exports.HAND2_BUCKLER_WARLOCK = val++;
exports.HAND2_SHIELD_DONALD = val++;
exports.HAND2_SHIELD_BULLSEYE = val++;
exports.HAND2_SHIELD_GONG = val++;
exports.HAND2_SHIELD_OF_RESISTANCE = val++;
exports.HAND2_LARGE_SHIELD_OF_IGNORANCE = val++;
exports.HAND2_LSHIELD_LOUISE = val++;
exports.HAND2_SHIELD_MIDDLE_ROUND = val++;
exports.HAND2_SHIELD_SKULL = val++;
exports.HAND2_SHIELD_ROUND_WHITE = val++;
exports.HAND2_BOROMIR = val++;
exports.HAND2_SHIELD_ROUND1 = val++;
exports.HAND2_SHIELD_ROUND2 = val++;
exports.HAND2_SHIELD_ROUND3 = val++;
exports.HAND2_SHIELD_ROUND4 = val++;
exports.HAND2_SHIELD_ROUND5 = val++;
exports.HAND2_SHIELD_ROUND6 = val++;
exports.HAND2_SHIELD_ROUND7 = val++;
exports.HAND2_SHIELD_MIDDLE_UNICORN = val++;
exports.HAND2_SHIELD_MIDDLE_GRAY = val++;
exports.HAND2_SHIELD_DIAMOND_YELLOW = val++;
exports.HAND2_SHIELD_MIDDLE_BROWN = val++;
exports.HAND2_SHIELD_MIDDLE_BLACK = val++;
exports.HAND2_SHIELD_MIDDLE_CYAN = val++;
exports.HAND2_SHIELD_MIDDLE_ETHN = val++;
exports.HAND2_SHIELD_LONG_CROSS = val++;
exports.HAND2_SHIELD_SHAMAN = val++;
exports.HAND2_SHIELD_GILGALAD = val++;
exports.HAND2_SHIELD_DEEP_DWARF = val++;
exports.HAND2_SHIELD_DEEP_DWARF_SCION = val++;
exports.HAND2_LARGE_SHIELD_DEEP_DWARF_DEATH_KNIGHT = val++;
exports.HAND2_BOOK_BLACK = val++;
exports.HAND2_BOOK_BLUE = val++;
exports.HAND2_BOOK_RED = val++;
exports.HAND2_BOOK_MAGENTA = val++;
exports.HAND2_BOOK_GREEN = val++;
exports.HAND2_BOOK_CYAN = val++;
exports.HAND2_BOOK_YELLOW = val++;
exports.HAND2_BOOK_WHITE = val++;
exports.HAND2_BOOK_SKY = val++;
exports.HAND2_BOOK_BLUE_DIM = val++;
exports.HAND2_BOOK_CYAN_DIM = val++;
exports.HAND2_BOOK_GREEN_DIM = val++;
exports.HAND2_BOOK_MAGENTA_DIM = val++;
exports.HAND2_BOOK_RED_DIM = val++;
exports.HAND2_BOOK_YELLOW_DIM = val++;
exports.HAND2_FIRE_GREEN = val++;
exports.HAND2_FIRE_CYAN = val++;
exports.HAND2_FIRE_WHITE = val++;
exports.HAND2_LIGHT_BLUE = val++;
exports.HAND2_LIGHT_RED = val++;
exports.HAND2_LIGHT_YELLOW = val++;
exports.HAND2_SPARK = val++;
exports.HAND2_FIRE_DARK = val++;
exports.HAND2_FIRE_WHITE2 = val++;
exports.HAND2_LANTERN = val++;
exports.HAND2_TORCH = val++;
exports.HAND2_PJ = val++;
exports.HAND2_TORCH2 = val++;
exports.HAND2_BLADEHAND = val++;
exports.HAND2_DAGGER = val++;
exports.HAND2_DAGGER_1 = val++;
exports.HAND2_RAPIER = val++;
exports.HAND2_RAPIER_1 = val++;
exports.HAND2_SHORT_SWORD_SLANT = val++;
exports.HAND2_SHORT_SWORD_SLANT_1 = val++;
exports.HAND2_GREAT_FLAIL = val++;
exports.HAND2_GREAT_FLAIL_1 = val++;
exports.HAND2_GREAT_MACE = val++;
exports.HAND2_GREAT_MACE_1 = val++;
exports.HAND2_GIANT_CLUB = val++;
exports.HAND2_GIANT_CLUB_SLANT = val++;
exports.HAND2_GIANT_CLUB_SPIKE = val++;
exports.HAND2_GIANT_CLUB_SPIKE_SLANT = val++;
exports.HAND2_GIANT_CLUB_PLAIN = val++;
exports.HAIR_SHORT_BLACK = val++;
exports.HAIR_SHORT_RED = val++;
exports.HAIR_SHORT_YELLOW = val++;
exports.HAIR_SHORT_WHITE = val++;
exports.HAIR_SHORT_BROWN = val++;
exports.HAIR_LONG_BLACK = val++;
exports.HAIR_LONG_RED = val++;
exports.HAIR_LONG_YELLOW = val++;
exports.HAIR_LONG_WHITE = val++;
exports.HAIR_FEM_BLACK = val++;
exports.HAIR_FEM_RED = val++;
exports.HAIR_FEM_YELLOW = val++;
exports.HAIR_FEM_WHITE = val++;
exports.HAIR_ELF_BLACK = val++;
exports.HAIR_ELF_RED = val++;
exports.HAIR_ELF_YELLOW = val++;
exports.HAIR_ELF_WHITE = val++;
exports.HAIR_ELF_BROWN = val++;
exports.HAIR_CURLY_YELLOW = val++;
exports.HAIR_FULL_BROWN = val++;
exports.HAIR_MOUNTAIN_MAN = val++;
exports.HAIR_PART_BLUE = val++;
exports.HAIR_PART2_RED = val++;
exports.HAIR_RIBBONS_BLACK = val++;
exports.HAIR_HIGHTAIL = val++;
exports.HAIR_QUEUE = val++;
exports.HAIR_HEADBAND = val++;
exports.HAIR_ARAGORN = val++;
exports.HAIR_ARWEN = val++;
exports.HAIR_BOROMIR = val++;
exports.HAIR_FRODO = val++;
exports.HAIR_LEGOLAS = val++;
exports.HAIR_MERRY = val++;
exports.HAIR_PJ = val++;
exports.HAIR_SAM = val++;
exports.HAIR_PIGTAIL_RED = val++;
exports.HAIR_PIGTAILS_BROWN = val++;
exports.HAIR_PIGTAILS_YELLOW = val++;
exports.HAIR_PIGTAILS_GREEN = val++;
exports.HAIR_PONYTAIL_YELLOW = val++;
exports.HAIR_KNOT_RED = val++;
exports.HAIR_BROWN1 = val++;
exports.HAIR_BROWN2 = val++;
exports.HAIR_GREEN = val++;
exports.HAIR_TENGU_COMB = val++;
exports.HAIR_SPRIGGAN1 = val++;
exports.HAIR_SPRIGGAN2 = val++;
exports.HAIR_SPRIGGAN3 = val++;
exports.HAIR_HIGHTAILS_BROWN = val++;
exports.HAIR_TOPKNOT = val++;
exports.HAIR_TOPKNOT2 = val++;
exports.HAIR_SWEEP = val++;
exports.HAIR_CHOPSTICKS = val++;
exports.HAIR_TROLL = val++;
exports.HAIR_DJINN1 = val++;
exports.HAIR_DJINN2 = val++;
exports.BEARD_FULL_BLACK = val++;
exports.BEARD_FULL_BLONDE = val++;
exports.BEARD_FULL_BROWN = val++;
exports.BEARD_FULL_GREEN = val++;
exports.BEARD_FULL_RED = val++;
exports.BEARD_FULL_WHITE = val++;
exports.BEARD_GARIBALDI_BLACK = val++;
exports.BEARD_GARIBALDI_BLONDE = val++;
exports.BEARD_GARIBALDI_BROWN = val++;
exports.BEARD_GARIBALDI_GREEN = val++;
exports.BEARD_GARIBALDI_RED = val++;
exports.BEARD_GARIBALDI_WHITE = val++;
exports.BEARD_MEDIUM_BLACK = val++;
exports.BEARD_MEDIUM_BLONDE = val++;
exports.BEARD_MEDIUM_BROWN = val++;
exports.BEARD_MEDIUM_GREEN = val++;
exports.BEARD_MEDIUM_RED = val++;
exports.BEARD_MEDIUM_WHITE = val++;
exports.BEARD_SCARF = val++;
exports.BEARD_SHORT_BLACK = val++;
exports.BEARD_SHORT_BLONDE = val++;
exports.BEARD_SHORT_BROWN = val++;
exports.BEARD_SHORT_GREEN = val++;
exports.BEARD_SHORT_RED = val++;
exports.BEARD_SHORT_WHITE = val++;
exports.BEARD_STUBBLE_BLACK = val++;
exports.BEARD_STUBBLE_BLONDE = val++;
exports.BEARD_STUBBLE_BROWN = val++;
exports.BEARD_STUBBLE_GREEN = val++;
exports.BEARD_STUBBLE_RED = val++;
exports.BEARD_STUBBLE_WHITE = val++;
exports.BEARD_MUTTONCHOPS_GREEN = val++;
exports.BEARD_BUSHY_GREEN = val++;
exports.BEARD_PJ = val++;
exports.BEARD_WIZARD = val++;
exports.HELM_CONE_BLUE = val++;
val = exports.HELM_HAT_FIRST_NORM = exports.HELM_CONE_BLUE; val++;
exports.HELM_STRAW = val++;
exports.HELM_CAP_BLUE = val++;
exports.HELM_FEATHER_GREEN = val++;
exports.HELM_FEATHER_RED = val++;
exports.HELM_FEATHER_BLUE = val++;
exports.HELM_FEATHER_YELLOW = val++;
exports.HELM_FEATHER_WHITE = val++;
exports.HELM_BANDANA_YBROWN = val++;
exports.HELM_HAT_BLACK = val++;
exports.HELM_WIZARD_GRAY = val++;
exports.HELM_WIZARD_BLUE = val++;
exports.HELM_WIZARD_PURPLE = val++;
exports.HELM_WIZARD_BLUEGREEN = val++;
exports.HELM_WIZARD_DARKGREEN = val++;
exports.HELM_WIZARD_BROWN = val++;
exports.HELM_WIZARD_BLACKGOLD = val++;
exports.HELM_WIZARD_BLACKRED = val++;
exports.HELM_WIZARD_RED = val++;
exports.HELM_WIZARD_WHITE = val++;
exports.HELM_TURBAN_WHITE = val++;
exports.HELM_TURBAN_BROWN = val++;
exports.HELM_TURBAN_PURPLE = val++;
val = exports.HELM_HAT_LAST_NORM = exports.HELM_TURBAN_PURPLE; val++;
exports.HELM_PUMPKIN = val++;
exports.HELM_HORNS1 = val++;
exports.HELM_HORNS2 = val++;
exports.HELM_HORNS3 = val++;
exports.HELM_HORNS_CAT = val++;
exports.HORNS_CAT_1 = val++;
exports.HORNS_CAT_2 = val++;
exports.HORNS_CAT_3 = val++;
exports.HORNS_CAT_4 = val++;
exports.HORNS_CAT_5 = val++;
exports.HORNS_CAT_6 = val++;
exports.HORNS_CAT_7 = val++;
exports.HORNS_CAT_8 = val++;
exports.HORNS_CAT_9 = val++;
exports.HELM_HORNS_DRAC = val++;
exports.HELM_CONE_RED = val++;
exports.HELM_CROWN = val++;
exports.CROWN_1 = val++;
exports.CROWN_2 = val++;
exports.HELM_CAP_BLACK = val++;
exports.HELM_CLOWN = val++;
exports.HELM_JESTER = val++;
exports.HELM_HEADBAND = val++;
exports.HEADBAND_1 = val++;
exports.HEADBAND_2 = val++;
exports.HEADBAND_3 = val++;
exports.HEADBAND_4 = val++;
exports.HELM_TAISO = val++;
exports.TAISO_1 = val++;
exports.TAISO_2 = val++;
exports.TAISO_3 = val++;
exports.TAISO_4 = val++;
exports.HELM_BEAR = val++;
exports.HELM_DYROVEPREVA = val++;
exports.HELM_ETERNAL_TORMENT = val++;
exports.HELM_WIZARD_LIGHTGREEN = val++;
exports.HELM_HELM_IRON = val++;
val = exports.HELM_HELM_OFS = exports.HELM_HELM_IRON; val++;
val = exports.HELM_FIRST_NORM = exports.HELM_HELM_IRON; val++;
exports.HELM_HELM_RED = val++;
exports.HELM_HELM_HORNED = val++;
exports.HELM_HELM_GIMLI = val++;
exports.HELM_HELM_GREEN = val++;
exports.HELM_GREEN_1 = val++;
exports.HELM_IRON_RED = val++;
exports.HELM_BLUE_HORN_GOLD = val++;
exports.HELM_VIKING = val++;
exports.VIKING_1 = val++;
exports.VIKING_2 = val++;
exports.HELM_WHITE = val++;
exports.HELM_YELLOW_WING = val++;
exports.HELM_BROWN_GOLD = val++;
exports.HELM_BLACK_HORN = val++;
exports.HELM_FULL_GOLD = val++;
exports.HELM_CHAIN = val++;
exports.HELM_FHELM_HORN_BLACK = val++;
val = exports.HELM_FHELM_OFS = exports.HELM_FHELM_HORN_BLACK; val++;
exports.HELM_FHELM_BLACK = val++;
exports.HELM_FHELM_HORN_GRAY = val++;
exports.HELM_FHELM_GRAY = val++;
exports.HELM_FHELM_GRAY2 = val++;
exports.HELM_FHELM_GRAY3 = val++;
exports.HELM_FHELM_HORN_YELLOW = val++;
exports.HELM_FHELM_HORN2 = val++;
exports.HELM_FHELM_EVIL = val++;
exports.HELM_FHELM_PLUME = val++;
exports.HELM_FHELM_MUMMY = val++;
exports.HELM_FHELM_ISILDUR = val++;
val = exports.HELM_LAST_NORM = exports.HELM_FHELM_ISILDUR; val++;
exports.HELM_ART_DRAGONHELM = val++;
exports.HELM_ETHERIC_CAGE = val++;
exports.HELM_FHELM_HEALER = val++;
exports.HELM_HOOD_GRAY = val++;
exports.HELM_HOOD_RED = val++;
exports.HELM_HOOD_GREEN2 = val++;
exports.HELM_HOOD_CYAN = val++;
exports.HELM_HOOD_ORANGE = val++;
exports.HELM_HOOD_RED2 = val++;
exports.HELM_HOOD_BLACK2 = val++;
exports.HELM_HOOD_WHITE2 = val++;
exports.HELM_HOOD_YBROWN = val++;
exports.HELM_HOOD_GREEN = val++;
exports.HELM_MASK_NINJA_BLACK = val++;
exports.DRCWING_BROWN = val++;
exports.DRCWING_BLACK = val++;
exports.DRCWING_YELLOW = val++;
exports.DRCWING_GREY = val++;
exports.DRCWING_GREEN = val++;
exports.DRCWING_PALE = val++;
exports.DRCWING_PURPLE = val++;
exports.DRCWING_RED = val++;
exports.DRCWING_WHITE = val++;
exports.DRCHEAD_BROWN = val++;
exports.DRCHEAD_BLACK = val++;
exports.DRCHEAD_YELLOW = val++;
exports.DRCHEAD_GREY = val++;
exports.DRCHEAD_GREEN = val++;
exports.DRCHEAD_PALE = val++;
exports.DRCHEAD_PURPLE = val++;
exports.DRCHEAD_RED = val++;
exports.DRCHEAD_WHITE = val++;
exports.PLAYER_MAX = exports.TILEP_PLAYER_MAX = val++;

var tile_info = [
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
];

exports.get_tile_info = function (idx)
{
    return tile_info[idx - m.TILE_MAIN_MAX];
};

var _tile_count =
[
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    27,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    27,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    27,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    27,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    27,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    27,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    27,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    27,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    27,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    27,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    27,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    27,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    27,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    27,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    27,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    10,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    11,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    6,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    6,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    6,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    6,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    10,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    1,
    3,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    10,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    6,
    1,
    1,
    1,
    1,
    1,
    6,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    3,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    2,
    1,
    3,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    11,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    2,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    3,
    1,
    1,
    1,
    2,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    10,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    10,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    6,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    4,
    1,
    1,
    1,
    10,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    12,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    2,
    1,
    10,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    2,
    1,
    5,
    1,
    1,
    1,
    1,
    2,
    1,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    1,
    1,
    10,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    2,
    1,
    4,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    3,
    1,
    1,
    6,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    6,
    1,
    1,
    1,
    1,
    1,
    10,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    3,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    3,
    1,
    1,
    3,
    1,
    1,
    1,
    1,
    3,
    1,
    1,
    1,
    1,
    3,
    1,
    1,
    1,
    3,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    2,
    1,
    1,
    2,
    1,
    1,
    1,
    3,
    1,
    1,
    2,
    1,
    1,
    2,
    1,
    2,
    1,
    1,
    2,
    1,
    2,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    1,
    1,
    2,
    1,
    2,
    1,
    1,
    1,
    2,
    1,
    2,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    2,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    1,
    1,
    1,
    2,
    1,
    1,
    1,
    1,
    2,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    1,
    2,
    1,
    1,
    1,
    1,
    1,
    3,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    10,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    10,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    3,
    1,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    5,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    1,
    1,
    3,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
];

exports.tile_count = function (idx)
{
    return _tile_count[idx - m.TILE_MAIN_MAX];
}

var _basetiles =
[
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    13,
    13,
    13,
    13,
    13,
    13,
    13,
    13,
    13,
    13,
    13,
    13,
    13,
    26,
    26,
    26,
    26,
    26,
    26,
    26,
    26,
    26,
    26,
    26,
    26,
    26,
    39,
    39,
    39,
    39,
    39,
    39,
    39,
    39,
    39,
    39,
    39,
    39,
    39,
    52,
    52,
    52,
    52,
    52,
    52,
    52,
    52,
    52,
    52,
    52,
    52,
    52,
    65,
    65,
    65,
    65,
    65,
    65,
    65,
    65,
    65,
    65,
    65,
    65,
    65,
    78,
    78,
    78,
    78,
    78,
    78,
    78,
    78,
    78,
    78,
    78,
    78,
    78,
    91,
    91,
    91,
    91,
    91,
    91,
    91,
    91,
    91,
    91,
    91,
    91,
    91,
    104,
    104,
    104,
    104,
    104,
    104,
    104,
    104,
    104,
    104,
    104,
    104,
    104,
    117,
    117,
    117,
    117,
    117,
    117,
    117,
    117,
    117,
    117,
    117,
    117,
    117,
    130,
    130,
    130,
    130,
    130,
    130,
    130,
    130,
    130,
    130,
    130,
    130,
    130,
    143,
    143,
    143,
    143,
    143,
    143,
    143,
    143,
    143,
    143,
    143,
    143,
    143,
    156,
    156,
    156,
    156,
    156,
    156,
    156,
    156,
    156,
    156,
    156,
    156,
    156,
    169,
    169,
    169,
    169,
    169,
    169,
    169,
    169,
    169,
    169,
    169,
    169,
    169,
    182,
    182,
    182,
    182,
    182,
    182,
    182,
    182,
    182,
    182,
    182,
    182,
    182,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    195,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    222,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    249,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    276,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    303,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    330,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    357,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    384,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    411,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    438,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    465,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    492,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    519,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    573,
    600,
    600,
    600,
    600,
    600,
    600,
    600,
    600,
    600,
    600,
    600,
    600,
    600,
    613,
    613,
    613,
    613,
    613,
    613,
    613,
    613,
    613,
    613,
    613,
    613,
    613,
    626,
    626,
    626,
    626,
    626,
    626,
    626,
    626,
    626,
    626,
    626,
    626,
    626,
    639,
    639,
    639,
    639,
    639,
    639,
    639,
    639,
    639,
    639,
    639,
    639,
    639,
    652,
    652,
    652,
    652,
    652,
    652,
    652,
    652,
    652,
    652,
    652,
    652,
    652,
    665,
    665,
    665,
    665,
    665,
    665,
    665,
    665,
    665,
    665,
    665,
    665,
    665,
    678,
    678,
    678,
    678,
    678,
    678,
    678,
    678,
    678,
    678,
    678,
    678,
    678,
    691,
    691,
    691,
    691,
    691,
    691,
    691,
    691,
    691,
    691,
    691,
    691,
    691,
    704,
    704,
    704,
    704,
    704,
    704,
    704,
    704,
    704,
    704,
    704,
    704,
    704,
    717,
    717,
    717,
    717,
    717,
    717,
    717,
    717,
    717,
    717,
    717,
    717,
    717,
    730,
    730,
    730,
    730,
    730,
    730,
    730,
    730,
    730,
    730,
    730,
    730,
    730,
    743,
    743,
    743,
    743,
    743,
    743,
    743,
    743,
    743,
    743,
    743,
    743,
    743,
    756,
    756,
    756,
    756,
    756,
    756,
    756,
    756,
    756,
    756,
    756,
    756,
    756,
    769,
    769,
    769,
    769,
    769,
    769,
    769,
    769,
    769,
    769,
    769,
    769,
    769,
    782,
    782,
    782,
    782,
    782,
    782,
    782,
    782,
    782,
    782,
    782,
    782,
    782,
    795,
    796,
    797,
    798,
    799,
    800,
    801,
    802,
    803,
    804,
    805,
    806,
    806,
    806,
    806,
    806,
    806,
    806,
    806,
    806,
    806,
    816,
    817,
    818,
    819,
    820,
    821,
    822,
    823,
    824,
    825,
    826,
    827,
    828,
    829,
    829,
    829,
    829,
    829,
    829,
    829,
    829,
    829,
    829,
    829,
    840,
    841,
    842,
    843,
    844,
    845,
    846,
    847,
    848,
    849,
    850,
    851,
    852,
    853,
    854,
    855,
    856,
    857,
    858,
    859,
    860,
    861,
    862,
    863,
    864,
    865,
    866,
    867,
    868,
    869,
    870,
    871,
    872,
    873,
    874,
    875,
    876,
    877,
    878,
    879,
    880,
    881,
    882,
    883,
    884,
    885,
    886,
    887,
    888,
    889,
    890,
    890,
    892,
    893,
    894,
    895,
    896,
    897,
    898,
    899,
    900,
    901,
    902,
    903,
    903,
    903,
    903,
    903,
    903,
    909,
    910,
    911,
    912,
    913,
    914,
    915,
    916,
    917,
    918,
    919,
    920,
    921,
    922,
    923,
    924,
    925,
    926,
    927,
    928,
    929,
    930,
    931,
    932,
    933,
    934,
    935,
    936,
    937,
    938,
    939,
    940,
    941,
    942,
    943,
    944,
    945,
    946,
    947,
    948,
    949,
    950,
    951,
    952,
    953,
    954,
    954,
    954,
    954,
    954,
    954,
    960,
    961,
    962,
    963,
    964,
    965,
    966,
    967,
    968,
    969,
    970,
    971,
    972,
    973,
    974,
    975,
    976,
    977,
    978,
    979,
    980,
    981,
    982,
    983,
    984,
    985,
    986,
    987,
    988,
    989,
    990,
    991,
    992,
    993,
    994,
    995,
    996,
    997,
    997,
    997,
    997,
    997,
    997,
    1003,
    1004,
    1005,
    1006,
    1007,
    1008,
    1009,
    1010,
    1011,
    1012,
    1013,
    1014,
    1015,
    1016,
    1017,
    1018,
    1019,
    1020,
    1021,
    1022,
    1023,
    1024,
    1025,
    1026,
    1027,
    1028,
    1029,
    1030,
    1031,
    1032,
    1033,
    1034,
    1035,
    1036,
    1037,
    1038,
    1039,
    1040,
    1040,
    1040,
    1040,
    1040,
    1040,
    1046,
    1047,
    1048,
    1049,
    1050,
    1051,
    1052,
    1053,
    1054,
    1055,
    1056,
    1057,
    1058,
    1059,
    1060,
    1061,
    1062,
    1063,
    1064,
    1065,
    1066,
    1067,
    1068,
    1069,
    1070,
    1071,
    1072,
    1073,
    1074,
    1075,
    1076,
    1077,
    1078,
    1079,
    1080,
    1081,
    1082,
    1083,
    1083,
    1083,
    1083,
    1083,
    1083,
    1083,
    1083,
    1083,
    1083,
    1093,
    1094,
    1095,
    1096,
    1097,
    1098,
    1099,
    1100,
    1101,
    1102,
    1103,
    1104,
    1105,
    1106,
    1107,
    1108,
    1109,
    1110,
    1111,
    1112,
    1113,
    1114,
    1115,
    1116,
    1117,
    1118,
    1119,
    1120,
    1121,
    1122,
    1123,
    1124,
    1125,
    1126,
    1127,
    1128,
    1129,
    1130,
    1131,
    1132,
    1133,
    1134,
    1135,
    1136,
    1137,
    1138,
    1139,
    1140,
    1141,
    1142,
    1143,
    1144,
    1145,
    1146,
    1147,
    1148,
    1149,
    1150,
    1151,
    1152,
    1153,
    1154,
    1155,
    1156,
    1157,
    1158,
    1159,
    1160,
    1161,
    1162,
    1163,
    1164,
    1165,
    1166,
    1167,
    1168,
    1169,
    1170,
    1171,
    1172,
    1173,
    1174,
    1175,
    1176,
    1177,
    1178,
    1179,
    1180,
    1181,
    1182,
    1183,
    1184,
    1185,
    1186,
    1187,
    1188,
    1189,
    1190,
    1191,
    1192,
    1193,
    1194,
    1195,
    1196,
    1197,
    1198,
    1199,
    1200,
    1201,
    1202,
    1203,
    1204,
    1205,
    1206,
    1207,
    1208,
    1209,
    1210,
    1211,
    1212,
    1213,
    1214,
    1215,
    1216,
    1217,
    1218,
    1219,
    1220,
    1221,
    1222,
    1223,
    1223,
    1223,
    1223,
    1227,
    1227,
    1227,
    1227,
    1231,
    1231,
    1231,
    1231,
    1235,
    1235,
    1235,
    1235,
    1239,
    1240,
    1240,
    1240,
    1243,
    1244,
    1244,
    1244,
    1244,
    1248,
    1249,
    1250,
    1251,
    1252,
    1253,
    1254,
    1255,
    1256,
    1257,
    1258,
    1259,
    1260,
    1261,
    1262,
    1263,
    1264,
    1265,
    1266,
    1267,
    1268,
    1269,
    1270,
    1271,
    1272,
    1273,
    1274,
    1275,
    1275,
    1275,
    1275,
    1275,
    1280,
    1281,
    1282,
    1283,
    1284,
    1285,
    1286,
    1287,
    1288,
    1289,
    1290,
    1291,
    1292,
    1293,
    1294,
    1295,
    1296,
    1297,
    1298,
    1299,
    1300,
    1301,
    1302,
    1303,
    1304,
    1305,
    1306,
    1307,
    1308,
    1309,
    1310,
    1311,
    1312,
    1313,
    1314,
    1315,
    1316,
    1316,
    1316,
    1316,
    1316,
    1316,
    1316,
    1316,
    1316,
    1316,
    1326,
    1327,
    1328,
    1328,
    1328,
    1328,
    1328,
    1328,
    1334,
    1334,
    1334,
    1334,
    1334,
    1334,
    1340,
    1341,
    1341,
    1343,
    1344,
    1345,
    1346,
    1347,
    1348,
    1349,
    1350,
    1351,
    1352,
    1353,
    1354,
    1355,
    1355,
    1357,
    1358,
    1359,
    1360,
    1361,
    1362,
    1363,
    1364,
    1365,
    1366,
    1367,
    1368,
    1369,
    1370,
    1371,
    1372,
    1373,
    1374,
    1375,
    1376,
    1377,
    1378,
    1379,
    1380,
    1381,
    1382,
    1383,
    1384,
    1385,
    1386,
    1387,
    1388,
    1389,
    1390,
    1391,
    1392,
    1393,
    1394,
    1395,
    1396,
    1397,
    1398,
    1399,
    1400,
    1401,
    1402,
    1403,
    1404,
    1405,
    1406,
    1407,
    1408,
    1409,
    1410,
    1411,
    1412,
    1413,
    1413,
    1413,
    1416,
    1417,
    1418,
    1419,
    1420,
    1421,
    1422,
    1423,
    1424,
    1425,
    1426,
    1427,
    1428,
    1428,
    1428,
    1428,
    1428,
    1433,
    1433,
    1435,
    1435,
    1435,
    1438,
    1439,
    1440,
    1441,
    1442,
    1443,
    1444,
    1445,
    1446,
    1447,
    1448,
    1449,
    1450,
    1451,
    1452,
    1453,
    1454,
    1455,
    1456,
    1457,
    1458,
    1459,
    1460,
    1461,
    1462,
    1463,
    1464,
    1465,
    1466,
    1467,
    1467,
    1467,
    1467,
    1467,
    1467,
    1467,
    1474,
    1475,
    1476,
    1477,
    1478,
    1479,
    1480,
    1481,
    1482,
    1483,
    1484,
    1485,
    1486,
    1487,
    1488,
    1489,
    1490,
    1491,
    1492,
    1493,
    1494,
    1495,
    1496,
    1497,
    1498,
    1499,
    1500,
    1501,
    1502,
    1503,
    1503,
    1503,
    1503,
    1503,
    1508,
    1508,
    1508,
    1508,
    1508,
    1513,
    1513,
    1513,
    1513,
    1513,
    1518,
    1518,
    1518,
    1518,
    1518,
    1523,
    1523,
    1523,
    1523,
    1523,
    1528,
    1528,
    1528,
    1528,
    1528,
    1533,
    1533,
    1533,
    1533,
    1533,
    1538,
    1538,
    1538,
    1538,
    1538,
    1543,
    1543,
    1543,
    1543,
    1543,
    1548,
    1549,
    1550,
    1551,
    1552,
    1553,
    1554,
    1555,
    1556,
    1557,
    1557,
    1557,
    1557,
    1557,
    1562,
    1563,
    1564,
    1565,
    1566,
    1567,
    1568,
    1569,
    1570,
    1571,
    1572,
    1573,
    1574,
    1575,
    1576,
    1577,
    1578,
    1579,
    1580,
    1581,
    1582,
    1583,
    1584,
    1585,
    1586,
    1587,
    1588,
    1589,
    1590,
    1591,
    1592,
    1593,
    1594,
    1595,
    1596,
    1597,
    1597,
    1597,
    1597,
    1597,
    1597,
    1597,
    1597,
    1597,
    1597,
    1597,
    1608,
    1609,
    1610,
    1610,
    1610,
    1610,
    1614,
    1615,
    1616,
    1617,
    1618,
    1619,
    1620,
    1621,
    1622,
    1623,
    1624,
    1625,
    1626,
    1627,
    1628,
    1629,
    1630,
    1631,
    1632,
    1633,
    1634,
    1635,
    1636,
    1637,
    1638,
    1639,
    1640,
    1641,
    1642,
    1643,
    1644,
    1645,
    1646,
    1647,
    1648,
    1649,
    1650,
    1651,
    1652,
    1652,
    1654,
    1654,
    1656,
    1657,
    1658,
    1659,
    1660,
    1661,
    1662,
    1663,
    1664,
    1665,
    1666,
    1667,
    1668,
    1668,
    1668,
    1671,
    1672,
    1672,
    1674,
    1674,
    1674,
    1674,
    1674,
    1674,
    1674,
    1674,
    1674,
    1683,
    1684,
    1685,
    1686,
    1687,
    1688,
    1689,
    1690,
    1691,
    1692,
    1693,
    1694,
    1695,
    1696,
    1697,
    1698,
    1699,
    1700,
    1701,
    1702,
    1703,
    1704,
    1705,
    1706,
    1707,
    1708,
    1709,
    1710,
    1711,
    1712,
    1713,
    1714,
    1715,
    1716,
    1717,
    1718,
    1719,
    1720,
    1721,
    1722,
    1723,
    1724,
    1725,
    1726,
    1727,
    1728,
    1729,
    1730,
    1731,
    1732,
    1733,
    1734,
    1735,
    1736,
    1737,
    1738,
    1739,
    1740,
    1741,
    1742,
    1743,
    1744,
    1745,
    1746,
    1747,
    1748,
    1749,
    1750,
    1751,
    1752,
    1753,
    1754,
    1755,
    1756,
    1757,
    1758,
    1759,
    1760,
    1761,
    1762,
    1763,
    1764,
    1765,
    1766,
    1767,
    1768,
    1769,
    1770,
    1771,
    1772,
    1773,
    1774,
    1775,
    1776,
    1777,
    1778,
    1779,
    1780,
    1781,
    1782,
    1783,
    1783,
    1783,
    1783,
    1783,
    1788,
    1789,
    1790,
    1791,
    1792,
    1793,
    1794,
    1794,
    1794,
    1794,
    1794,
    1794,
    1794,
    1794,
    1794,
    1794,
    1804,
    1805,
    1806,
    1807,
    1808,
    1809,
    1810,
    1811,
    1812,
    1813,
    1814,
    1815,
    1816,
    1817,
    1818,
    1819,
    1820,
    1821,
    1822,
    1823,
    1824,
    1825,
    1826,
    1827,
    1828,
    1829,
    1830,
    1831,
    1832,
    1833,
    1834,
    1835,
    1836,
    1837,
    1838,
    1839,
    1840,
    1841,
    1842,
    1843,
    1844,
    1845,
    1846,
    1847,
    1848,
    1849,
    1850,
    1851,
    1852,
    1853,
    1854,
    1855,
    1856,
    1856,
    1856,
    1856,
    1856,
    1861,
    1862,
    1863,
    1864,
    1865,
    1866,
    1867,
    1868,
    1869,
    1870,
    1871,
    1872,
    1873,
    1874,
    1875,
    1876,
    1877,
    1878,
    1879,
    1879,
    1879,
    1879,
    1879,
    1884,
    1885,
    1886,
    1887,
    1888,
    1889,
    1890,
    1891,
    1892,
    1893,
    1894,
    1895,
    1896,
    1897,
    1898,
    1899,
    1900,
    1901,
    1901,
    1901,
    1901,
    1901,
    1906,
    1906,
    1906,
    1906,
    1906,
    1906,
    1906,
    1906,
    1906,
    1915,
    1916,
    1917,
    1917,
    1917,
    1917,
    1917,
    1917,
    1917,
    1917,
    1917,
    1917,
    1927,
    1928,
    1929,
    1930,
    1931,
    1932,
    1933,
    1934,
    1935,
    1936,
    1937,
    1938,
    1939,
    1940,
    1941,
    1942,
    1943,
    1944,
    1945,
    1946,
    1947,
    1948,
    1949,
    1950,
    1951,
    1952,
    1953,
    1954,
    1955,
    1956,
    1957,
    1958,
    1959,
    1960,
    1961,
    1962,
    1963,
    1964,
    1965,
    1966,
    1967,
    1968,
    1969,
    1970,
    1971,
    1972,
    1973,
    1974,
    1975,
    1976,
    1977,
    1978,
    1979,
    1979,
    1979,
    1979,
    1979,
    1979,
    1985,
    1985,
    1987,
    1987,
    1989,
    1989,
    1991,
    1991,
    1991,
    1991,
    1995,
    1995,
    1995,
    1995,
    1995,
    1995,
    1995,
    1995,
    1995,
    1995,
    2005,
    2005,
    2007,
    2007,
    2009,
    2009,
    2011,
    2011,
    2011,
    2011,
    2011,
    2011,
    2011,
    2011,
    2011,
    2011,
    2011,
    2011,
    2023,
    2023,
    2023,
    2023,
    2027,
    2027,
    2029,
    2029,
    2029,
    2029,
    2029,
    2029,
    2029,
    2029,
    2029,
    2029,
    2039,
    2039,
    2041,
    2041,
    2043,
    2043,
    2043,
    2043,
    2043,
    2048,
    2048,
    2050,
    2051,
    2051,
    2053,
    2053,
    2055,
    2055,
    2057,
    2057,
    2059,
    2059,
    2061,
    2061,
    2063,
    2063,
    2065,
    2065,
    2067,
    2067,
    2069,
    2070,
    2071,
    2071,
    2071,
    2071,
    2071,
    2071,
    2071,
    2071,
    2071,
    2071,
    2081,
    2081,
    2083,
    2083,
    2085,
    2085,
    2085,
    2085,
    2089,
    2089,
    2089,
    2089,
    2089,
    2094,
    2094,
    2094,
    2097,
    2097,
    2097,
    2097,
    2097,
    2097,
    2103,
    2103,
    2105,
    2105,
    2107,
    2107,
    2109,
    2109,
    2111,
    2111,
    2111,
    2111,
    2111,
    2111,
    2117,
    2117,
    2117,
    2117,
    2117,
    2117,
    2117,
    2117,
    2117,
    2117,
    2127,
    2128,
    2129,
    2130,
    2131,
    2132,
    2133,
    2134,
    2135,
    2136,
    2137,
    2138,
    2139,
    2140,
    2141,
    2142,
    2143,
    2144,
    2145,
    2146,
    2147,
    2148,
    2149,
    2150,
    2151,
    2152,
    2153,
    2154,
    2155,
    2156,
    2157,
    2158,
    2159,
    2160,
    2161,
    2162,
    2163,
    2164,
    2165,
    2166,
    2167,
    2168,
    2169,
    2170,
    2171,
    2172,
    2173,
    2174,
    2175,
    2176,
    2177,
    2178,
    2179,
    2180,
    2181,
    2182,
    2183,
    2184,
    2185,
    2186,
    2187,
    2188,
    2189,
    2190,
    2191,
    2192,
    2193,
    2194,
    2195,
    2196,
    2197,
    2198,
    2199,
    2200,
    2201,
    2202,
    2203,
    2204,
    2205,
    2206,
    2207,
    2208,
    2209,
    2210,
    2211,
    2212,
    2213,
    2214,
    2215,
    2216,
    2217,
    2218,
    2219,
    2220,
    2221,
    2222,
    2223,
    2224,
    2225,
    2226,
    2227,
    2228,
    2229,
    2230,
    2231,
    2232,
    2233,
    2234,
    2235,
    2236,
    2237,
    2238,
    2239,
    2240,
    2241,
    2242,
    2243,
    2244,
    2245,
    2246,
    2247,
    2248,
    2249,
    2250,
    2251,
    2252,
    2253,
    2254,
    2255,
    2256,
    2257,
    2258,
    2259,
    2260,
    2261,
    2262,
    2263,
    2264,
    2265,
    2266,
    2267,
    2268,
    2269,
    2270,
    2271,
    2272,
    2273,
    2274,
    2275,
    2276,
    2277,
    2278,
    2279,
    2280,
    2281,
    2282,
    2283,
    2284,
    2284,
    2284,
    2287,
    2288,
    2289,
    2290,
    2291,
    2292,
    2293,
    2294,
    2295,
    2296,
    2297,
    2298,
    2299,
    2300,
    2301,
    2302,
    2303,
    2304,
    2305,
    2306,
    2307,
    2307,
    2309,
    2309,
    2309,
    2312,
    2312,
    2312,
    2315,
    2316,
    2317,
    2317,
    2317,
    2320,
    2321,
    2322,
    2322,
    2322,
    2325,
    2326,
    2326,
    2326,
    2329,
    2330,
    2331,
    2332,
    2333,
    2334,
    2335,
    2336,
    2337,
    2338,
    2339,
    2340,
    2341,
    2342,
    2343,
    2344,
    2345,
    2346,
    2347,
    2348,
    2349,
    2350,
    2351,
    2352,
    2353,
    2354,
    2355,
    2356,
    2357,
    2358,
    2359,
    2360,
    2361,
    2362,
    2363,
    2364,
    2365,
    2366,
    2367,
    2368,
    2369,
    2370,
    2371,
    2372,
    2373,
    2374,
    2375,
    2376,
    2377,
    2378,
    2379,
    2380,
    2381,
    2382,
    2383,
    2384,
    2385,
    2386,
    2387,
    2388,
    2389,
    2390,
    2391,
    2392,
    2393,
    2394,
    2395,
    2396,
    2397,
    2398,
    2399,
    2400,
    2401,
    2402,
    2403,
    2404,
    2405,
    2406,
    2407,
    2408,
    2409,
    2410,
    2411,
    2412,
    2413,
    2414,
    2415,
    2416,
    2417,
    2418,
    2419,
    2420,
    2421,
    2422,
    2423,
    2424,
    2425,
    2426,
    2427,
    2428,
    2429,
    2430,
    2431,
    2432,
    2433,
    2434,
    2435,
    2436,
    2437,
    2438,
    2439,
    2439,
    2441,
    2441,
    2443,
    2444,
    2444,
    2446,
    2447,
    2448,
    2448,
    2448,
    2451,
    2451,
    2453,
    2454,
    2454,
    2456,
    2456,
    2458,
    2459,
    2459,
    2461,
    2461,
    2463,
    2464,
    2465,
    2466,
    2467,
    2468,
    2469,
    2470,
    2470,
    2472,
    2473,
    2474,
    2475,
    2476,
    2477,
    2478,
    2479,
    2480,
    2481,
    2482,
    2483,
    2484,
    2485,
    2486,
    2487,
    2487,
    2489,
    2490,
    2491,
    2491,
    2493,
    2493,
    2495,
    2496,
    2497,
    2497,
    2499,
    2499,
    2501,
    2502,
    2503,
    2504,
    2505,
    2506,
    2506,
    2508,
    2508,
    2510,
    2511,
    2512,
    2513,
    2514,
    2515,
    2516,
    2516,
    2518,
    2519,
    2520,
    2521,
    2522,
    2523,
    2523,
    2525,
    2526,
    2527,
    2528,
    2529,
    2529,
    2531,
    2532,
    2533,
    2534,
    2534,
    2536,
    2537,
    2538,
    2539,
    2539,
    2541,
    2542,
    2543,
    2544,
    2545,
    2546,
    2546,
    2548,
    2549,
    2549,
    2551,
    2552,
    2553,
    2554,
    2555,
    2555,
    2555,
    2558,
    2559,
    2560,
    2561,
    2562,
    2563,
    2564,
    2565,
    2566,
    2567,
    2568,
    2569,
    2570,
    2571,
    2572,
    2572,
    2572,
    2572,
    2572,
    2572,
    2572,
    2572,
    2572,
    2572,
    2582,
    2583,
    2583,
    2585,
    2585,
    2587,
    2587,
    2589,
    2589,
    2591,
    2591,
    2593,
    2594,
    2595,
    2596,
    2597,
    2598,
    2599,
    2600,
    2601,
    2602,
    2603,
    2604,
    2605,
    2606,
    2607,
    2608,
    2609,
    2610,
    2611,
    2612,
    2613,
    2614,
    2615,
    2616,
    2617,
    2618,
    2619,
    2620,
    2621,
    2622,
    2623,
    2624,
    2625,
    2626,
    2627,
    2628,
    2629,
    2630,
    2631,
    2632,
    2633,
    2634,
    2635,
    2636,
    2637,
    2638,
    2639,
    2640,
    2641,
    2642,
    2643,
    2644,
    2645,
    2646,
    2647,
    2648,
    2649,
    2650,
    2651,
    2652,
    2653,
    2654,
    2655,
    2656,
    2657,
    2658,
    2659,
    2660,
    2661,
    2662,
    2663,
    2664,
    2665,
    2666,
    2667,
    2668,
    2669,
    2670,
    2671,
    2672,
    2673,
    2674,
    2675,
    2676,
    2677,
    2678,
    2679,
    2680,
    2681,
    2682,
    2683,
    2684,
    2685,
    2686,
    2687,
    2688,
    2689,
    2690,
    2691,
    2692,
    2693,
    2694,
    2695,
    2696,
    2697,
    2698,
    2699,
    2700,
    2701,
    2702,
    2703,
    2704,
    2705,
    2706,
    2707,
    2708,
    2709,
    2710,
    2711,
    2712,
    2713,
    2714,
    2715,
    2716,
    2717,
    2718,
    2719,
    2720,
    2721,
    2722,
    2723,
    2724,
    2725,
    2726,
    2727,
    2728,
    2729,
    2730,
    2731,
    2732,
    2733,
    2734,
    2735,
    2736,
    2737,
    2738,
    2739,
    2740,
    2741,
    2742,
    2743,
    2744,
    2745,
    2746,
    2747,
    2748,
    2749,
    2750,
    2751,
    2752,
    2753,
    2754,
    2755,
    2756,
    2757,
    2758,
    2759,
    2760,
    2761,
    2762,
    2763,
    2764,
    2765,
    2766,
    2767,
    2768,
    2769,
    2770,
    2771,
    2772,
    2773,
    2774,
    2775,
    2776,
    2777,
    2778,
    2779,
    2780,
    2781,
    2782,
    2783,
    2784,
    2785,
    2786,
    2787,
    2788,
    2789,
    2790,
    2791,
    2792,
    2793,
    2794,
    2795,
    2796,
    2797,
    2798,
    2799,
    2800,
    2801,
    2802,
    2803,
    2804,
    2805,
    2806,
    2807,
    2808,
    2809,
    2810,
    2811,
    2812,
    2813,
    2814,
    2815,
    2816,
    2817,
    2818,
    2819,
    2820,
    2821,
    2822,
    2823,
    2824,
    2825,
    2826,
    2827,
    2828,
    2829,
    2830,
    2831,
    2832,
    2833,
    2834,
    2835,
    2836,
    2837,
    2838,
    2839,
    2840,
    2841,
    2842,
    2843,
    2844,
    2845,
    2846,
    2847,
    2848,
    2849,
    2850,
    2851,
    2852,
    2853,
    2854,
    2855,
    2856,
    2857,
    2857,
    2857,
    2857,
    2857,
    2857,
    2857,
    2857,
    2857,
    2857,
    2867,
    2868,
    2869,
    2869,
    2869,
    2872,
    2873,
    2874,
    2875,
    2875,
    2875,
    2875,
    2875,
    2880,
    2880,
    2880,
    2880,
    2880,
    2885,
    2886,
    2887,
    2888,
    2889,
    2890,
    2891,
    2892,
    2893,
    2893,
    2895,
    2896,
    2897,
    2897,
    2897,
    2900,
    2901,
    2902,
    2903,
    2904,
    2905,
    2906,
    2907,
    2908,
    2909,
    2910,
    2911,
    2912,
    2913,
    2914,
    2915,
    2916,
    2917,
    2918,
    2919,
    2920,
    2921,
    2922,
    2923,
    2924,
    2925,
    2926,
    2927,
    2928,
    2929,
    2930,
    2931,
    2932,
    2933,
    2934,
    2935,
    2936,
    2937,
    2938,
    2939,
    2940,
    2941,
    2942,
    2943,
    2944,
    2945,
    2946,
    2947,
    2948,
    2949,
];

exports.basetile = function (idx)
{
    return _basetiles[idx - m.TILE_MAIN_MAX] + m.TILE_MAIN_MAX;
};

exports.get_img = function (idx) {
    return "player";
};

return exports;
});
