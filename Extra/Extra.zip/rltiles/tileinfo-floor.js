define([], function(m) {
// This file has been automatically generated.

var exports = {};

var val = 0;
exports.DNGN_UNSEEN = val++;
exports.DNGN_ERROR = val++;
exports.FLOOR_GREY_DIRT = val++;
val = exports.FLOOR_NORMAL = exports.FLOOR_GREY_DIRT; val++;
exports.FLOOR_GREY_DIRT_1 = val++;
exports.FLOOR_GREY_DIRT_2 = val++;
exports.FLOOR_GREY_DIRT_3 = val++;
exports.FLOOR_GREY_DIRT_4 = val++;
exports.FLOOR_GREY_DIRT_5 = val++;
exports.FLOOR_GREY_DIRT_6 = val++;
exports.FLOOR_GREY_DIRT_7 = val++;
exports.FLOOR_GREY_DIRT_B = val++;
exports.FLOOR_GREY_DIRT_B_1 = val++;
exports.FLOOR_GREY_DIRT_B_2 = val++;
exports.FLOOR_GREY_DIRT_B_3 = val++;
exports.FLOOR_GREY_DIRT_B_4 = val++;
exports.FLOOR_GREY_DIRT_B_5 = val++;
exports.FLOOR_GREY_DIRT_B_6 = val++;
exports.FLOOR_GREY_DIRT_B_7 = val++;
exports.FLOOR_PEBBLE = val++;
val = exports.FLOOR_PEBBLE_LIGHTGRAY = exports.FLOOR_PEBBLE; val++;
exports.FLOOR_PEBBLE_1 = val++;
exports.FLOOR_PEBBLE_2 = val++;
exports.FLOOR_PEBBLE_3 = val++;
exports.FLOOR_PEBBLE_4 = val++;
exports.FLOOR_PEBBLE_5 = val++;
exports.FLOOR_PEBBLE_6 = val++;
exports.FLOOR_PEBBLE_7 = val++;
exports.FLOOR_PEBBLE_8 = val++;
exports.FLOOR_PEBBLE_BROWN = val++;
exports.FLOOR_PEBBLE_BROWN_1 = val++;
exports.FLOOR_PEBBLE_BROWN_2 = val++;
exports.FLOOR_PEBBLE_BROWN_3 = val++;
exports.FLOOR_PEBBLE_BROWN_4 = val++;
exports.FLOOR_PEBBLE_BROWN_5 = val++;
exports.FLOOR_PEBBLE_BROWN_6 = val++;
exports.FLOOR_PEBBLE_BROWN_7 = val++;
exports.FLOOR_PEBBLE_BROWN_8 = val++;
exports.FLOOR_PEBBLE_BLUE = val++;
exports.FLOOR_PEBBLE_BLUE_1 = val++;
exports.FLOOR_PEBBLE_BLUE_2 = val++;
exports.FLOOR_PEBBLE_BLUE_3 = val++;
exports.FLOOR_PEBBLE_BLUE_4 = val++;
exports.FLOOR_PEBBLE_BLUE_5 = val++;
exports.FLOOR_PEBBLE_BLUE_6 = val++;
exports.FLOOR_PEBBLE_BLUE_7 = val++;
exports.FLOOR_PEBBLE_BLUE_8 = val++;
exports.FLOOR_PEBBLE_GREEN = val++;
exports.FLOOR_PEBBLE_GREEN_1 = val++;
exports.FLOOR_PEBBLE_GREEN_2 = val++;
exports.FLOOR_PEBBLE_GREEN_3 = val++;
exports.FLOOR_PEBBLE_GREEN_4 = val++;
exports.FLOOR_PEBBLE_GREEN_5 = val++;
exports.FLOOR_PEBBLE_GREEN_6 = val++;
exports.FLOOR_PEBBLE_GREEN_7 = val++;
exports.FLOOR_PEBBLE_GREEN_8 = val++;
exports.FLOOR_PEBBLE_CYAN = val++;
exports.FLOOR_PEBBLE_CYAN_1 = val++;
exports.FLOOR_PEBBLE_CYAN_2 = val++;
exports.FLOOR_PEBBLE_CYAN_3 = val++;
exports.FLOOR_PEBBLE_CYAN_4 = val++;
exports.FLOOR_PEBBLE_CYAN_5 = val++;
exports.FLOOR_PEBBLE_CYAN_6 = val++;
exports.FLOOR_PEBBLE_CYAN_7 = val++;
exports.FLOOR_PEBBLE_CYAN_8 = val++;
exports.FLOOR_PEBBLE_RED = val++;
exports.FLOOR_PEBBLE_RED_1 = val++;
exports.FLOOR_PEBBLE_RED_2 = val++;
exports.FLOOR_PEBBLE_RED_3 = val++;
exports.FLOOR_PEBBLE_RED_4 = val++;
exports.FLOOR_PEBBLE_RED_5 = val++;
exports.FLOOR_PEBBLE_RED_6 = val++;
exports.FLOOR_PEBBLE_RED_7 = val++;
exports.FLOOR_PEBBLE_RED_8 = val++;
exports.FLOOR_PEBBLE_MAGENTA = val++;
exports.FLOOR_PEBBLE_MAGENTA_1 = val++;
exports.FLOOR_PEBBLE_MAGENTA_2 = val++;
exports.FLOOR_PEBBLE_MAGENTA_3 = val++;
exports.FLOOR_PEBBLE_MAGENTA_4 = val++;
exports.FLOOR_PEBBLE_MAGENTA_5 = val++;
exports.FLOOR_PEBBLE_MAGENTA_6 = val++;
exports.FLOOR_PEBBLE_MAGENTA_7 = val++;
exports.FLOOR_PEBBLE_MAGENTA_8 = val++;
exports.FLOOR_PEBBLE_DARKGRAY = val++;
exports.FLOOR_PEBBLE_DARKGRAY_1 = val++;
exports.FLOOR_PEBBLE_DARKGRAY_2 = val++;
exports.FLOOR_PEBBLE_DARKGRAY_3 = val++;
exports.FLOOR_PEBBLE_DARKGRAY_4 = val++;
exports.FLOOR_PEBBLE_DARKGRAY_5 = val++;
exports.FLOOR_PEBBLE_DARKGRAY_6 = val++;
exports.FLOOR_PEBBLE_DARKGRAY_7 = val++;
exports.FLOOR_PEBBLE_DARKGRAY_8 = val++;
exports.FLOOR_PEBBLE_LIGHTBLUE = val++;
exports.FLOOR_PEBBLE_LIGHTBLUE_1 = val++;
exports.FLOOR_PEBBLE_LIGHTBLUE_2 = val++;
exports.FLOOR_PEBBLE_LIGHTBLUE_3 = val++;
exports.FLOOR_PEBBLE_LIGHTBLUE_4 = val++;
exports.FLOOR_PEBBLE_LIGHTBLUE_5 = val++;
exports.FLOOR_PEBBLE_LIGHTBLUE_6 = val++;
exports.FLOOR_PEBBLE_LIGHTBLUE_7 = val++;
exports.FLOOR_PEBBLE_LIGHTBLUE_8 = val++;
exports.FLOOR_PEBBLE_LIGHTGREEN = val++;
exports.FLOOR_PEBBLE_LIGHTGREEN_1 = val++;
exports.FLOOR_PEBBLE_LIGHTGREEN_2 = val++;
exports.FLOOR_PEBBLE_LIGHTGREEN_3 = val++;
exports.FLOOR_PEBBLE_LIGHTGREEN_4 = val++;
exports.FLOOR_PEBBLE_LIGHTGREEN_5 = val++;
exports.FLOOR_PEBBLE_LIGHTGREEN_6 = val++;
exports.FLOOR_PEBBLE_LIGHTGREEN_7 = val++;
exports.FLOOR_PEBBLE_LIGHTGREEN_8 = val++;
exports.FLOOR_PEBBLE_LIGHTCYAN = val++;
exports.FLOOR_PEBBLE_LIGHTCYAN_1 = val++;
exports.FLOOR_PEBBLE_LIGHTCYAN_2 = val++;
exports.FLOOR_PEBBLE_LIGHTCYAN_3 = val++;
exports.FLOOR_PEBBLE_LIGHTCYAN_4 = val++;
exports.FLOOR_PEBBLE_LIGHTCYAN_5 = val++;
exports.FLOOR_PEBBLE_LIGHTCYAN_6 = val++;
exports.FLOOR_PEBBLE_LIGHTCYAN_7 = val++;
exports.FLOOR_PEBBLE_LIGHTCYAN_8 = val++;
exports.FLOOR_PEBBLE_LIGHTRED = val++;
exports.FLOOR_PEBBLE_LIGHTRED_1 = val++;
exports.FLOOR_PEBBLE_LIGHTRED_2 = val++;
exports.FLOOR_PEBBLE_LIGHTRED_3 = val++;
exports.FLOOR_PEBBLE_LIGHTRED_4 = val++;
exports.FLOOR_PEBBLE_LIGHTRED_5 = val++;
exports.FLOOR_PEBBLE_LIGHTRED_6 = val++;
exports.FLOOR_PEBBLE_LIGHTRED_7 = val++;
exports.FLOOR_PEBBLE_LIGHTRED_8 = val++;
exports.FLOOR_PEBBLE_LIGHTMAGENTA = val++;
exports.FLOOR_PEBBLE_LIGHTMAGENTA_1 = val++;
exports.FLOOR_PEBBLE_LIGHTMAGENTA_2 = val++;
exports.FLOOR_PEBBLE_LIGHTMAGENTA_3 = val++;
exports.FLOOR_PEBBLE_LIGHTMAGENTA_4 = val++;
exports.FLOOR_PEBBLE_LIGHTMAGENTA_5 = val++;
exports.FLOOR_PEBBLE_LIGHTMAGENTA_6 = val++;
exports.FLOOR_PEBBLE_LIGHTMAGENTA_7 = val++;
exports.FLOOR_PEBBLE_LIGHTMAGENTA_8 = val++;
exports.FLOOR_PEBBLE_YELLOW = val++;
exports.FLOOR_PEBBLE_YELLOW_1 = val++;
exports.FLOOR_PEBBLE_YELLOW_2 = val++;
exports.FLOOR_PEBBLE_YELLOW_3 = val++;
exports.FLOOR_PEBBLE_YELLOW_4 = val++;
exports.FLOOR_PEBBLE_YELLOW_5 = val++;
exports.FLOOR_PEBBLE_YELLOW_6 = val++;
exports.FLOOR_PEBBLE_YELLOW_7 = val++;
exports.FLOOR_PEBBLE_YELLOW_8 = val++;
exports.FLOOR_PEBBLE_WHITE = val++;
exports.FLOOR_PEBBLE_WHITE_1 = val++;
exports.FLOOR_PEBBLE_WHITE_2 = val++;
exports.FLOOR_PEBBLE_WHITE_3 = val++;
exports.FLOOR_PEBBLE_WHITE_4 = val++;
exports.FLOOR_PEBBLE_WHITE_5 = val++;
exports.FLOOR_PEBBLE_WHITE_6 = val++;
exports.FLOOR_PEBBLE_WHITE_7 = val++;
exports.FLOOR_PEBBLE_WHITE_8 = val++;
exports.FLOOR_PEBBLE_DARKBROWN = val++;
exports.FLOOR_PEBBLE_DARKBROWN_1 = val++;
exports.FLOOR_PEBBLE_DARKBROWN_2 = val++;
exports.FLOOR_PEBBLE_DARKBROWN_3 = val++;
exports.FLOOR_PEBBLE_DARKBROWN_4 = val++;
exports.FLOOR_PEBBLE_DARKBROWN_5 = val++;
exports.FLOOR_PEBBLE_DARKBROWN_6 = val++;
exports.FLOOR_PEBBLE_DARKBROWN_7 = val++;
exports.FLOOR_PEBBLE_DARKBROWN_8 = val++;
exports.FLOOR_HALL = val++;
exports.FLOOR_HALL_1 = val++;
exports.FLOOR_HALL_2 = val++;
exports.FLOOR_HALL_3 = val++;
exports.FLOOR_MUD = val++;
exports.FLOOR_MUD_1 = val++;
exports.FLOOR_MUD_2 = val++;
exports.FLOOR_MUD_3 = val++;
exports.FLOOR_ICE = val++;
exports.FLOOR_ICE_1 = val++;
exports.FLOOR_ICE_2 = val++;
exports.FLOOR_ICE_3 = val++;
exports.FLOOR_LAIR = val++;
exports.FLOOR_LAIR_1 = val++;
exports.FLOOR_LAIR_2 = val++;
exports.FLOOR_LAIR_3 = val++;
exports.FLOOR_LAIR_4 = val++;
exports.FLOOR_LAIR_5 = val++;
exports.FLOOR_LAIR_6 = val++;
exports.FLOOR_LAIR_7 = val++;
exports.FLOOR_LAIR_8 = val++;
exports.FLOOR_LAIR_9 = val++;
exports.FLOOR_LAIR_10 = val++;
exports.FLOOR_LAIR_11 = val++;
exports.FLOOR_LAIR_12 = val++;
exports.FLOOR_LAIR_13 = val++;
exports.FLOOR_LAIR_14 = val++;
exports.FLOOR_LAIR_15 = val++;
exports.FLOOR_ORC = val++;
exports.FLOOR_ORC_1 = val++;
exports.FLOOR_ORC_2 = val++;
exports.FLOOR_ORC_3 = val++;
exports.FLOOR_ORC_4 = val++;
exports.FLOOR_ORC_5 = val++;
exports.FLOOR_ORC_6 = val++;
exports.FLOOR_ORC_7 = val++;
exports.FLOOR_MOSS = val++;
exports.FLOOR_MOSS_1 = val++;
exports.FLOOR_MOSS_2 = val++;
exports.FLOOR_MOSS_3 = val++;
exports.FLOOR_SLIME = val++;
exports.FLOOR_SLIME_1 = val++;
exports.FLOOR_SLIME_2 = val++;
exports.FLOOR_SLIME_3 = val++;
exports.FLOOR_SLIME_ACIDIC = val++;
exports.FLOOR_SLIME_ACIDIC_1 = val++;
exports.FLOOR_SLIME_ACIDIC_2 = val++;
exports.FLOOR_SLIME_ACIDIC_3 = val++;
exports.SLIME_OVERLAY = val++;
exports.SLIME_OVERLAY_1 = val++;
exports.SLIME_OVERLAY_2 = val++;
exports.SLIME_OVERLAY_3 = val++;
exports.SLIME_OVERLAY_4 = val++;
exports.SLIME_OVERLAY_5 = val++;
exports.SLIME_OVERLAY_6 = val++;
exports.SLIME_OVERLAY_7 = val++;
exports.FLOOR_SNAKE_A = val++;
exports.FLOOR_SNAKE_A_1 = val++;
exports.FLOOR_SNAKE_A_2 = val++;
exports.FLOOR_SNAKE_A_3 = val++;
exports.FLOOR_SNAKE_C = val++;
exports.FLOOR_SNAKE_C_1 = val++;
exports.FLOOR_SNAKE_C_2 = val++;
exports.FLOOR_SNAKE_C_3 = val++;
exports.FLOOR_SNAKE_D = val++;
exports.FLOOR_SNAKE_D_1 = val++;
exports.FLOOR_SNAKE_D_2 = val++;
exports.FLOOR_SNAKE_D_3 = val++;
exports.FLOOR_SWAMP = val++;
exports.FLOOR_SWAMP_1 = val++;
exports.FLOOR_SWAMP_2 = val++;
exports.FLOOR_SWAMP_3 = val++;
exports.FLOOR_SALT = val++;
exports.FLOOR_SALT_1 = val++;
exports.FLOOR_SALT_2 = val++;
exports.FLOOR_SALT_3 = val++;
exports.FLOOR_SALT_4 = val++;
exports.FLOOR_SALT_5 = val++;
exports.FLOOR_SPIDER = val++;
exports.FLOOR_SPIDER_1 = val++;
exports.FLOOR_SPIDER_2 = val++;
exports.FLOOR_SPIDER_3 = val++;
exports.FLOOR_SPIDER_4 = val++;
exports.FLOOR_SPIDER_5 = val++;
exports.FLOOR_SPIDER_6 = val++;
exports.FLOOR_SPIDER_7 = val++;
exports.FLOOR_SPIDER_8 = val++;
exports.FLOOR_SPIDER_9 = val++;
exports.FLOOR_SPIDER_10 = val++;
exports.FLOOR_SPIDER_11 = val++;
exports.FLOOR_TOMB = val++;
exports.FLOOR_TOMB_1 = val++;
exports.FLOOR_TOMB_2 = val++;
exports.FLOOR_TOMB_3 = val++;
exports.FLOOR_VAULT = val++;
exports.FLOOR_VAULT_1 = val++;
exports.FLOOR_VAULT_2 = val++;
exports.FLOOR_VAULT_3 = val++;
exports.FLOOR_VINES = val++;
exports.FLOOR_VINES_1 = val++;
exports.FLOOR_VINES_2 = val++;
exports.FLOOR_VINES_3 = val++;
exports.FLOOR_VINES_4 = val++;
exports.FLOOR_VINES_5 = val++;
exports.FLOOR_VINES_6 = val++;
exports.FLOOR_ROUGH = val++;
val = exports.FLOOR_ROUGH_RED = exports.FLOOR_ROUGH; val++;
exports.FLOOR_ROUGH_1 = val++;
exports.FLOOR_ROUGH_2 = val++;
exports.FLOOR_ROUGH_3 = val++;
exports.FLOOR_ROUGH_BLUE = val++;
exports.FLOOR_ROUGH_BLUE_1 = val++;
exports.FLOOR_ROUGH_BLUE_2 = val++;
exports.FLOOR_ROUGH_BLUE_3 = val++;
exports.FLOOR_ROUGH_GREEN = val++;
exports.FLOOR_ROUGH_GREEN_1 = val++;
exports.FLOOR_ROUGH_GREEN_2 = val++;
exports.FLOOR_ROUGH_GREEN_3 = val++;
exports.FLOOR_ROUGH_CYAN = val++;
exports.FLOOR_ROUGH_CYAN_1 = val++;
exports.FLOOR_ROUGH_CYAN_2 = val++;
exports.FLOOR_ROUGH_CYAN_3 = val++;
exports.FLOOR_ROUGH_MAGENTA = val++;
exports.FLOOR_ROUGH_MAGENTA_1 = val++;
exports.FLOOR_ROUGH_MAGENTA_2 = val++;
exports.FLOOR_ROUGH_MAGENTA_3 = val++;
exports.FLOOR_ROUGH_BROWN = val++;
exports.FLOOR_ROUGH_BROWN_1 = val++;
exports.FLOOR_ROUGH_BROWN_2 = val++;
exports.FLOOR_ROUGH_BROWN_3 = val++;
exports.FLOOR_ROUGH_LIGHTGRAY = val++;
exports.FLOOR_ROUGH_LIGHTGRAY_1 = val++;
exports.FLOOR_ROUGH_LIGHTGRAY_2 = val++;
exports.FLOOR_ROUGH_LIGHTGRAY_3 = val++;
exports.FLOOR_ROUGH_DARKGRAY = val++;
exports.FLOOR_ROUGH_DARKGRAY_1 = val++;
exports.FLOOR_ROUGH_DARKGRAY_2 = val++;
exports.FLOOR_ROUGH_DARKGRAY_3 = val++;
exports.FLOOR_ROUGH_LIGHTBLUE = val++;
exports.FLOOR_ROUGH_LIGHTBLUE_1 = val++;
exports.FLOOR_ROUGH_LIGHTBLUE_2 = val++;
exports.FLOOR_ROUGH_LIGHTBLUE_3 = val++;
exports.FLOOR_ROUGH_LIGHTGREEN = val++;
exports.FLOOR_ROUGH_LIGHTGREEN_1 = val++;
exports.FLOOR_ROUGH_LIGHTGREEN_2 = val++;
exports.FLOOR_ROUGH_LIGHTGREEN_3 = val++;
exports.FLOOR_ROUGH_LIGHTCYAN = val++;
exports.FLOOR_ROUGH_LIGHTCYAN_1 = val++;
exports.FLOOR_ROUGH_LIGHTCYAN_2 = val++;
exports.FLOOR_ROUGH_LIGHTCYAN_3 = val++;
exports.FLOOR_ROUGH_LIGHTRED = val++;
exports.FLOOR_ROUGH_LIGHTRED_1 = val++;
exports.FLOOR_ROUGH_LIGHTRED_2 = val++;
exports.FLOOR_ROUGH_LIGHTRED_3 = val++;
exports.FLOOR_ROUGH_LIGHTMAGENTA = val++;
exports.FLOOR_ROUGH_LIGHTMAGENTA_1 = val++;
exports.FLOOR_ROUGH_LIGHTMAGENTA_2 = val++;
exports.FLOOR_ROUGH_LIGHTMAGENTA_3 = val++;
exports.FLOOR_ROUGH_YELLOW = val++;
exports.FLOOR_ROUGH_YELLOW_1 = val++;
exports.FLOOR_ROUGH_YELLOW_2 = val++;
exports.FLOOR_ROUGH_YELLOW_3 = val++;
exports.FLOOR_ROUGH_WHITE = val++;
exports.FLOOR_ROUGH_WHITE_1 = val++;
exports.FLOOR_ROUGH_WHITE_2 = val++;
exports.FLOOR_ROUGH_WHITE_3 = val++;
exports.FLOOR_SAND = val++;
exports.FLOOR_SAND_1 = val++;
exports.FLOOR_SAND_2 = val++;
exports.FLOOR_SAND_3 = val++;
exports.FLOOR_SAND_4 = val++;
exports.FLOOR_SAND_5 = val++;
exports.FLOOR_SAND_6 = val++;
exports.FLOOR_SAND_7 = val++;
exports.FLOOR_COBBLE_BLOOD = val++;
exports.FLOOR_COBBLE_BLOOD_1 = val++;
exports.FLOOR_COBBLE_BLOOD_2 = val++;
exports.FLOOR_COBBLE_BLOOD_3 = val++;
exports.FLOOR_COBBLE_BLOOD_4 = val++;
exports.FLOOR_COBBLE_BLOOD_5 = val++;
exports.FLOOR_COBBLE_BLOOD_6 = val++;
exports.FLOOR_COBBLE_BLOOD_7 = val++;
exports.FLOOR_COBBLE_BLOOD_8 = val++;
exports.FLOOR_COBBLE_BLOOD_9 = val++;
exports.FLOOR_COBBLE_BLOOD_10 = val++;
exports.FLOOR_COBBLE_BLOOD_11 = val++;
exports.FLOOR_MARBLE = val++;
exports.FLOOR_MARBLE_1 = val++;
exports.FLOOR_MARBLE_2 = val++;
exports.FLOOR_MARBLE_3 = val++;
exports.FLOOR_MARBLE_4 = val++;
exports.FLOOR_MARBLE_5 = val++;
exports.FLOOR_SANDSTONE = val++;
exports.FLOOR_SANDSTONE_1 = val++;
exports.FLOOR_SANDSTONE_2 = val++;
exports.FLOOR_SANDSTONE_3 = val++;
exports.FLOOR_SANDSTONE_4 = val++;
exports.FLOOR_SANDSTONE_5 = val++;
exports.FLOOR_SANDSTONE_6 = val++;
exports.FLOOR_SANDSTONE_7 = val++;
exports.FLOOR_SANDSTONE_8 = val++;
exports.FLOOR_SANDSTONE_9 = val++;
exports.FLOOR_VOLCANIC = val++;
exports.FLOOR_VOLCANIC_1 = val++;
exports.FLOOR_VOLCANIC_2 = val++;
exports.FLOOR_VOLCANIC_3 = val++;
exports.FLOOR_VOLCANIC_4 = val++;
exports.FLOOR_VOLCANIC_5 = val++;
exports.FLOOR_VOLCANIC_6 = val++;
exports.FLOOR_CRYSTAL_SQUARES = val++;
exports.FLOOR_CRYSTAL_SQUARES_1 = val++;
exports.FLOOR_CRYSTAL_SQUARES_2 = val++;
exports.FLOOR_CRYSTAL_SQUARES_3 = val++;
exports.FLOOR_CRYSTAL_SQUARES_4 = val++;
exports.FLOOR_CRYSTAL_SQUARES_5 = val++;
exports.FLOOR_GRASS = val++;
exports.FLOOR_GRASS_1 = val++;
exports.FLOOR_GRASS_2 = val++;
exports.FLOOR_GRASS_3 = val++;
exports.FLOOR_GRASS_4 = val++;
exports.FLOOR_GRASS_5 = val++;
exports.FLOOR_GRASS_6 = val++;
exports.FLOOR_GRASS_7 = val++;
exports.FLOOR_GRASS_8 = val++;
exports.FLOOR_GRASS_9 = val++;
exports.FLOOR_GRASS_10 = val++;
exports.FLOOR_GRASS_11 = val++;
exports.HALO_GRASS = val++;
exports.HALO_GRASS_1 = val++;
exports.HALO_GRASS_2 = val++;
exports.HALO_GRASS_3 = val++;
exports.HALO_GRASS_4 = val++;
exports.HALO_GRASS_5 = val++;
exports.HALO_GRASS_6 = val++;
exports.HALO_GRASS_7 = val++;
exports.HALO_GRASS_8 = val++;
exports.FLOOR_GRASS_DIRT_MIX = val++;
exports.FLOOR_GRASS_DIRT_MIX_1 = val++;
exports.FLOOR_GRASS_DIRT_MIX_2 = val++;
exports.FLOOR_NERVES = val++;
val = exports.FLOOR_NERVES_RED = exports.FLOOR_NERVES; val++;
exports.FLOOR_NERVES_1 = val++;
exports.FLOOR_NERVES_2 = val++;
exports.FLOOR_NERVES_3 = val++;
exports.FLOOR_NERVES_4 = val++;
exports.FLOOR_NERVES_5 = val++;
exports.FLOOR_NERVES_6 = val++;
exports.FLOOR_NERVES_BLUE = val++;
exports.FLOOR_NERVES_BLUE_1 = val++;
exports.FLOOR_NERVES_BLUE_2 = val++;
exports.FLOOR_NERVES_BLUE_3 = val++;
exports.FLOOR_NERVES_BLUE_4 = val++;
exports.FLOOR_NERVES_BLUE_5 = val++;
exports.FLOOR_NERVES_BLUE_6 = val++;
exports.FLOOR_NERVES_GREEN = val++;
exports.FLOOR_NERVES_GREEN_1 = val++;
exports.FLOOR_NERVES_GREEN_2 = val++;
exports.FLOOR_NERVES_GREEN_3 = val++;
exports.FLOOR_NERVES_GREEN_4 = val++;
exports.FLOOR_NERVES_GREEN_5 = val++;
exports.FLOOR_NERVES_GREEN_6 = val++;
exports.FLOOR_NERVES_CYAN = val++;
exports.FLOOR_NERVES_CYAN_1 = val++;
exports.FLOOR_NERVES_CYAN_2 = val++;
exports.FLOOR_NERVES_CYAN_3 = val++;
exports.FLOOR_NERVES_CYAN_4 = val++;
exports.FLOOR_NERVES_CYAN_5 = val++;
exports.FLOOR_NERVES_CYAN_6 = val++;
exports.FLOOR_NERVES_MAGENTA = val++;
exports.FLOOR_NERVES_MAGENTA_1 = val++;
exports.FLOOR_NERVES_MAGENTA_2 = val++;
exports.FLOOR_NERVES_MAGENTA_3 = val++;
exports.FLOOR_NERVES_MAGENTA_4 = val++;
exports.FLOOR_NERVES_MAGENTA_5 = val++;
exports.FLOOR_NERVES_MAGENTA_6 = val++;
exports.FLOOR_NERVES_BROWN = val++;
exports.FLOOR_NERVES_BROWN_1 = val++;
exports.FLOOR_NERVES_BROWN_2 = val++;
exports.FLOOR_NERVES_BROWN_3 = val++;
exports.FLOOR_NERVES_BROWN_4 = val++;
exports.FLOOR_NERVES_BROWN_5 = val++;
exports.FLOOR_NERVES_BROWN_6 = val++;
exports.FLOOR_NERVES_LIGHTGRAY = val++;
exports.FLOOR_NERVES_LIGHTGRAY_1 = val++;
exports.FLOOR_NERVES_LIGHTGRAY_2 = val++;
exports.FLOOR_NERVES_LIGHTGRAY_3 = val++;
exports.FLOOR_NERVES_LIGHTGRAY_4 = val++;
exports.FLOOR_NERVES_LIGHTGRAY_5 = val++;
exports.FLOOR_NERVES_LIGHTGRAY_6 = val++;
exports.FLOOR_NERVES_DARKGRAY = val++;
exports.FLOOR_NERVES_DARKGRAY_1 = val++;
exports.FLOOR_NERVES_DARKGRAY_2 = val++;
exports.FLOOR_NERVES_DARKGRAY_3 = val++;
exports.FLOOR_NERVES_DARKGRAY_4 = val++;
exports.FLOOR_NERVES_DARKGRAY_5 = val++;
exports.FLOOR_NERVES_DARKGRAY_6 = val++;
exports.FLOOR_NERVES_LIGHTBLUE = val++;
exports.FLOOR_NERVES_LIGHTBLUE_1 = val++;
exports.FLOOR_NERVES_LIGHTBLUE_2 = val++;
exports.FLOOR_NERVES_LIGHTBLUE_3 = val++;
exports.FLOOR_NERVES_LIGHTBLUE_4 = val++;
exports.FLOOR_NERVES_LIGHTBLUE_5 = val++;
exports.FLOOR_NERVES_LIGHTBLUE_6 = val++;
exports.FLOOR_NERVES_LIGHTGREEN = val++;
exports.FLOOR_NERVES_LIGHTGREEN_1 = val++;
exports.FLOOR_NERVES_LIGHTGREEN_2 = val++;
exports.FLOOR_NERVES_LIGHTGREEN_3 = val++;
exports.FLOOR_NERVES_LIGHTGREEN_4 = val++;
exports.FLOOR_NERVES_LIGHTGREEN_5 = val++;
exports.FLOOR_NERVES_LIGHTGREEN_6 = val++;
exports.FLOOR_NERVES_LIGHTCYAN = val++;
exports.FLOOR_NERVES_LIGHTCYAN_1 = val++;
exports.FLOOR_NERVES_LIGHTCYAN_2 = val++;
exports.FLOOR_NERVES_LIGHTCYAN_3 = val++;
exports.FLOOR_NERVES_LIGHTCYAN_4 = val++;
exports.FLOOR_NERVES_LIGHTCYAN_5 = val++;
exports.FLOOR_NERVES_LIGHTCYAN_6 = val++;
exports.FLOOR_NERVES_LIGHTRED = val++;
exports.FLOOR_NERVES_LIGHTRED_1 = val++;
exports.FLOOR_NERVES_LIGHTRED_2 = val++;
exports.FLOOR_NERVES_LIGHTRED_3 = val++;
exports.FLOOR_NERVES_LIGHTRED_4 = val++;
exports.FLOOR_NERVES_LIGHTRED_5 = val++;
exports.FLOOR_NERVES_LIGHTRED_6 = val++;
exports.FLOOR_NERVES_LIGHTMAGENTA = val++;
exports.FLOOR_NERVES_LIGHTMAGENTA_1 = val++;
exports.FLOOR_NERVES_LIGHTMAGENTA_2 = val++;
exports.FLOOR_NERVES_LIGHTMAGENTA_3 = val++;
exports.FLOOR_NERVES_LIGHTMAGENTA_4 = val++;
exports.FLOOR_NERVES_LIGHTMAGENTA_5 = val++;
exports.FLOOR_NERVES_LIGHTMAGENTA_6 = val++;
exports.FLOOR_NERVES_YELLOW = val++;
exports.FLOOR_NERVES_YELLOW_1 = val++;
exports.FLOOR_NERVES_YELLOW_2 = val++;
exports.FLOOR_NERVES_YELLOW_3 = val++;
exports.FLOOR_NERVES_YELLOW_4 = val++;
exports.FLOOR_NERVES_YELLOW_5 = val++;
exports.FLOOR_NERVES_YELLOW_6 = val++;
exports.FLOOR_NERVES_WHITE = val++;
exports.FLOOR_NERVES_WHITE_1 = val++;
exports.FLOOR_NERVES_WHITE_2 = val++;
exports.FLOOR_NERVES_WHITE_3 = val++;
exports.FLOOR_NERVES_WHITE_4 = val++;
exports.FLOOR_NERVES_WHITE_5 = val++;
exports.FLOOR_NERVES_WHITE_6 = val++;
exports.HALO_GRASS2 = val++;
exports.HALO_GRASS2_1 = val++;
exports.HALO_GRASS2_2 = val++;
exports.HALO_GRASS2_3 = val++;
exports.HALO_GRASS2_4 = val++;
exports.HALO_GRASS2_5 = val++;
exports.HALO_GRASS2_6 = val++;
exports.HALO_GRASS2_7 = val++;
exports.HALO_GRASS2_8 = val++;
exports.HALO_VAULT = val++;
exports.HALO_VAULT_1 = val++;
exports.HALO_VAULT_2 = val++;
exports.HALO_VAULT_3 = val++;
exports.HALO_VAULT_4 = val++;
exports.HALO_VAULT_5 = val++;
exports.HALO_VAULT_6 = val++;
exports.HALO_VAULT_7 = val++;
exports.HALO_VAULT_8 = val++;
exports.FLOOR_DIRT = val++;
exports.FLOOR_DIRT_1 = val++;
exports.FLOOR_DIRT_2 = val++;
exports.HALO_DIRT = val++;
exports.HALO_DIRT_1 = val++;
exports.HALO_DIRT_2 = val++;
exports.HALO_DIRT_3 = val++;
exports.HALO_DIRT_4 = val++;
exports.HALO_DIRT_5 = val++;
exports.HALO_DIRT_6 = val++;
exports.HALO_DIRT_7 = val++;
exports.HALO_DIRT_8 = val++;
exports.TUTORIAL_PAD = val++;
exports.FLOOR_LIMESTONE = val++;
exports.FLOOR_LIMESTONE_1 = val++;
exports.FLOOR_LIMESTONE_2 = val++;
exports.FLOOR_LIMESTONE_3 = val++;
exports.FLOOR_LIMESTONE_4 = val++;
exports.FLOOR_LIMESTONE_5 = val++;
exports.FLOOR_LIMESTONE_6 = val++;
exports.FLOOR_LIMESTONE_7 = val++;
exports.FLOOR_LIMESTONE_8 = val++;
exports.FLOOR_LIMESTONE_9 = val++;
exports.FLOOR_W_MARBLE = val++;
exports.FLOOR_W_MARBLE_1 = val++;
exports.FLOOR_W_MARBLE_2 = val++;
exports.FLOOR_W_MARBLE_3 = val++;
exports.FLOOR_W_MARBLE_4 = val++;
exports.FLOOR_W_MARBLE_5 = val++;
exports.FLOOR_W_MARBLE_6 = val++;
exports.FLOOR_W_MARBLE_7 = val++;
exports.FLOOR_W_MARBLE_8 = val++;
exports.FLOOR_W_MARBLE_9 = val++;
exports.SIGIL_CURVE_N_E = val++;
exports.SIGIL_CURVE_N_W = val++;
exports.SIGIL_CURVE_S_E = val++;
exports.SIGIL_CURVE_S_W = val++;
exports.SIGIL_STRAIGHT_E_W = val++;
exports.SIGIL_STRAIGHT_N_S = val++;
exports.SIGIL_STRAIGHT_NE_SW = val++;
exports.SIGIL_STRAIGHT_NW_SE = val++;
exports.SIGIL_CROSS = val++;
exports.SIGIL_CIRCLE = val++;
exports.SIGIL_RHOMBUS = val++;
exports.SIGIL_Y = val++;
exports.SIGIL_Y_INVERTED = val++;
exports.SIGIL_Y_RIGHT = val++;
exports.SIGIL_Y_LEFT = val++;
exports.SIGIL_Y_LEFTLEANING = val++;
exports.SIGIL_Y_RIGHTLEANING = val++;
exports.SIGIL_ALGIZ_LEFT = val++;
exports.SIGIL_ALGIZ_RIGHT = val++;
exports.SIGIL_STRAIGHT_E_NW = val++;
exports.SIGIL_STRAIGHT_E_SW = val++;
exports.SIGIL_STRAIGHT_W_NE = val++;
exports.SIGIL_STRAIGHT_W_SE = val++;
exports.SIGIL_STRAIGHT_N_SE = val++;
exports.SIGIL_STRAIGHT_N_SW = val++;
exports.SIGIL_STRAIGHT_S_NE = val++;
exports.SIGIL_STRAIGHT_S_NW = val++;
exports.SIGIL_FOURWAY = val++;
exports.SIGIL_SHARP_E_NE = val++;
exports.SIGIL_SHARP_W_SW = val++;
exports.SIGIL_STRAIGHT_E_NE_SW = val++;
exports.FLOOR_INFERNAL = val++;
exports.FLOOR_INFERNAL_1 = val++;
exports.FLOOR_INFERNAL_2 = val++;
exports.FLOOR_INFERNAL_3 = val++;
exports.FLOOR_INFERNAL_4 = val++;
exports.FLOOR_INFERNAL_5 = val++;
exports.FLOOR_INFERNAL_6 = val++;
exports.FLOOR_INFERNAL_7 = val++;
exports.FLOOR_INFERNAL_8 = val++;
exports.FLOOR_INFERNAL_9 = val++;
exports.FLOOR_INFERNAL_10 = val++;
exports.FLOOR_INFERNAL_11 = val++;
exports.FLOOR_INFERNAL_12 = val++;
exports.FLOOR_INFERNAL_13 = val++;
exports.FLOOR_INFERNAL_14 = val++;
exports.FLOOR_INFERNAL_BLANK = val++;
exports.FLOOR_GAUNTLET = val++;
exports.FLOOR_GAUNTLET_1 = val++;
exports.FLOOR_GAUNTLET_2 = val++;
exports.FLOOR_GAUNTLET_3 = val++;
exports.FLOOR_CRYPT = val++;
exports.FLOOR_CRYPT_1 = val++;
exports.FLOOR_CRYPT_2 = val++;
exports.FLOOR_CRYPT_3 = val++;
exports.FLOOR_CRYPT_4 = val++;
exports.FLOOR_CRYPT_5 = val++;
exports.FLOOR_CRYPT_6 = val++;
exports.FLOOR_CRYPT_7 = val++;
exports.FLOOR_CRYPT_8 = val++;
exports.FLOOR_CRYPT_9 = val++;
exports.FLOOR_IRON = val++;
exports.FLOOR_IRON_1 = val++;
exports.FLOOR_IRON_2 = val++;
exports.FLOOR_IRON_3 = val++;
exports.FLOOR_IRON_4 = val++;
exports.FLOOR_IRON_5 = val++;
exports.FLOOR_BLACK_COBALT = val++;
exports.FLOOR_BLACK_COBALT_1 = val++;
exports.FLOOR_BLACK_COBALT_2 = val++;
exports.FLOOR_BLACK_COBALT_3 = val++;
exports.FLOOR_BLACK_COBALT_4 = val++;
exports.FLOOR_BLACK_COBALT_5 = val++;
exports.FLOOR_BLACK_COBALT_6 = val++;
exports.FLOOR_BLACK_COBALT_7 = val++;
exports.FLOOR_BLACK_COBALT_8 = val++;
exports.FLOOR_BLACK_COBALT_9 = val++;
exports.FLOOR_BLACK_COBALT_10 = val++;
exports.FLOOR_BLACK_COBALT_11 = val++;
exports.FLOOR_FROZEN = val++;
exports.FLOOR_FROZEN_1 = val++;
exports.FLOOR_FROZEN_2 = val++;
exports.FLOOR_FROZEN_3 = val++;
exports.FLOOR_FROZEN_4 = val++;
exports.FLOOR_FROZEN_5 = val++;
exports.FLOOR_FROZEN_6 = val++;
exports.FLOOR_FROZEN_7 = val++;
exports.FLOOR_FROZEN_8 = val++;
exports.FLOOR_FROZEN_9 = val++;
exports.FLOOR_FROZEN_10 = val++;
exports.FLOOR_FROZEN_11 = val++;
exports.FLOOR_FROZEN_12 = val++;
exports.FLOOR_DEMONIC = val++;
val = exports.FLOOR_DEMONIC_RED = exports.FLOOR_DEMONIC; val++;
exports.FLOOR_DEMONIC_1 = val++;
exports.FLOOR_DEMONIC_2 = val++;
exports.FLOOR_DEMONIC_3 = val++;
exports.FLOOR_DEMONIC_4 = val++;
exports.FLOOR_DEMONIC_5 = val++;
exports.FLOOR_DEMONIC_6 = val++;
exports.FLOOR_DEMONIC_7 = val++;
exports.FLOOR_DEMONIC_8 = val++;
exports.FLOOR_DEMONIC_BLUE = val++;
exports.FLOOR_DEMONIC_BLUE_1 = val++;
exports.FLOOR_DEMONIC_BLUE_2 = val++;
exports.FLOOR_DEMONIC_BLUE_3 = val++;
exports.FLOOR_DEMONIC_BLUE_4 = val++;
exports.FLOOR_DEMONIC_BLUE_5 = val++;
exports.FLOOR_DEMONIC_BLUE_6 = val++;
exports.FLOOR_DEMONIC_BLUE_7 = val++;
exports.FLOOR_DEMONIC_BLUE_8 = val++;
exports.FLOOR_DEMONIC_GREEN = val++;
exports.FLOOR_DEMONIC_GREEN_1 = val++;
exports.FLOOR_DEMONIC_GREEN_2 = val++;
exports.FLOOR_DEMONIC_GREEN_3 = val++;
exports.FLOOR_DEMONIC_GREEN_4 = val++;
exports.FLOOR_DEMONIC_GREEN_5 = val++;
exports.FLOOR_DEMONIC_GREEN_6 = val++;
exports.FLOOR_DEMONIC_GREEN_7 = val++;
exports.FLOOR_DEMONIC_GREEN_8 = val++;
exports.FLOOR_DEMONIC_CYAN = val++;
exports.FLOOR_DEMONIC_CYAN_1 = val++;
exports.FLOOR_DEMONIC_CYAN_2 = val++;
exports.FLOOR_DEMONIC_CYAN_3 = val++;
exports.FLOOR_DEMONIC_CYAN_4 = val++;
exports.FLOOR_DEMONIC_CYAN_5 = val++;
exports.FLOOR_DEMONIC_CYAN_6 = val++;
exports.FLOOR_DEMONIC_CYAN_7 = val++;
exports.FLOOR_DEMONIC_CYAN_8 = val++;
exports.FLOOR_DEMONIC_MAGENTA = val++;
exports.FLOOR_DEMONIC_MAGENTA_1 = val++;
exports.FLOOR_DEMONIC_MAGENTA_2 = val++;
exports.FLOOR_DEMONIC_MAGENTA_3 = val++;
exports.FLOOR_DEMONIC_MAGENTA_4 = val++;
exports.FLOOR_DEMONIC_MAGENTA_5 = val++;
exports.FLOOR_DEMONIC_MAGENTA_6 = val++;
exports.FLOOR_DEMONIC_MAGENTA_7 = val++;
exports.FLOOR_DEMONIC_MAGENTA_8 = val++;
exports.FLOOR_DEMONIC_BROWN = val++;
exports.FLOOR_DEMONIC_BROWN_1 = val++;
exports.FLOOR_DEMONIC_BROWN_2 = val++;
exports.FLOOR_DEMONIC_BROWN_3 = val++;
exports.FLOOR_DEMONIC_BROWN_4 = val++;
exports.FLOOR_DEMONIC_BROWN_5 = val++;
exports.FLOOR_DEMONIC_BROWN_6 = val++;
exports.FLOOR_DEMONIC_BROWN_7 = val++;
exports.FLOOR_DEMONIC_BROWN_8 = val++;
exports.FLOOR_DEMONIC_LIGHTGRAY = val++;
exports.FLOOR_DEMONIC_LIGHTGRAY_1 = val++;
exports.FLOOR_DEMONIC_LIGHTGRAY_2 = val++;
exports.FLOOR_DEMONIC_LIGHTGRAY_3 = val++;
exports.FLOOR_DEMONIC_LIGHTGRAY_4 = val++;
exports.FLOOR_DEMONIC_LIGHTGRAY_5 = val++;
exports.FLOOR_DEMONIC_LIGHTGRAY_6 = val++;
exports.FLOOR_DEMONIC_LIGHTGRAY_7 = val++;
exports.FLOOR_DEMONIC_LIGHTGRAY_8 = val++;
exports.FLOOR_DEMONIC_DARKGRAY = val++;
exports.FLOOR_DEMONIC_DARKGRAY_1 = val++;
exports.FLOOR_DEMONIC_DARKGRAY_2 = val++;
exports.FLOOR_DEMONIC_DARKGRAY_3 = val++;
exports.FLOOR_DEMONIC_DARKGRAY_4 = val++;
exports.FLOOR_DEMONIC_DARKGRAY_5 = val++;
exports.FLOOR_DEMONIC_DARKGRAY_6 = val++;
exports.FLOOR_DEMONIC_DARKGRAY_7 = val++;
exports.FLOOR_DEMONIC_DARKGRAY_8 = val++;
exports.FLOOR_DEMONIC_LIGHTBLUE = val++;
exports.FLOOR_DEMONIC_LIGHTBLUE_1 = val++;
exports.FLOOR_DEMONIC_LIGHTBLUE_2 = val++;
exports.FLOOR_DEMONIC_LIGHTBLUE_3 = val++;
exports.FLOOR_DEMONIC_LIGHTBLUE_4 = val++;
exports.FLOOR_DEMONIC_LIGHTBLUE_5 = val++;
exports.FLOOR_DEMONIC_LIGHTBLUE_6 = val++;
exports.FLOOR_DEMONIC_LIGHTBLUE_7 = val++;
exports.FLOOR_DEMONIC_LIGHTBLUE_8 = val++;
exports.FLOOR_DEMONIC_LIGHTGREEN = val++;
exports.FLOOR_DEMONIC_LIGHTGREEN_1 = val++;
exports.FLOOR_DEMONIC_LIGHTGREEN_2 = val++;
exports.FLOOR_DEMONIC_LIGHTGREEN_3 = val++;
exports.FLOOR_DEMONIC_LIGHTGREEN_4 = val++;
exports.FLOOR_DEMONIC_LIGHTGREEN_5 = val++;
exports.FLOOR_DEMONIC_LIGHTGREEN_6 = val++;
exports.FLOOR_DEMONIC_LIGHTGREEN_7 = val++;
exports.FLOOR_DEMONIC_LIGHTGREEN_8 = val++;
exports.FLOOR_DEMONIC_LIGHTCYAN = val++;
exports.FLOOR_DEMONIC_LIGHTCYAN_1 = val++;
exports.FLOOR_DEMONIC_LIGHTCYAN_2 = val++;
exports.FLOOR_DEMONIC_LIGHTCYAN_3 = val++;
exports.FLOOR_DEMONIC_LIGHTCYAN_4 = val++;
exports.FLOOR_DEMONIC_LIGHTCYAN_5 = val++;
exports.FLOOR_DEMONIC_LIGHTCYAN_6 = val++;
exports.FLOOR_DEMONIC_LIGHTCYAN_7 = val++;
exports.FLOOR_DEMONIC_LIGHTCYAN_8 = val++;
exports.FLOOR_DEMONIC_LIGHTRED = val++;
exports.FLOOR_DEMONIC_LIGHTRED_1 = val++;
exports.FLOOR_DEMONIC_LIGHTRED_2 = val++;
exports.FLOOR_DEMONIC_LIGHTRED_3 = val++;
exports.FLOOR_DEMONIC_LIGHTRED_4 = val++;
exports.FLOOR_DEMONIC_LIGHTRED_5 = val++;
exports.FLOOR_DEMONIC_LIGHTRED_6 = val++;
exports.FLOOR_DEMONIC_LIGHTRED_7 = val++;
exports.FLOOR_DEMONIC_LIGHTRED_8 = val++;
exports.FLOOR_DEMONIC_LIGHTMAGENTA = val++;
exports.FLOOR_DEMONIC_LIGHTMAGENTA_1 = val++;
exports.FLOOR_DEMONIC_LIGHTMAGENTA_2 = val++;
exports.FLOOR_DEMONIC_LIGHTMAGENTA_3 = val++;
exports.FLOOR_DEMONIC_LIGHTMAGENTA_4 = val++;
exports.FLOOR_DEMONIC_LIGHTMAGENTA_5 = val++;
exports.FLOOR_DEMONIC_LIGHTMAGENTA_6 = val++;
exports.FLOOR_DEMONIC_LIGHTMAGENTA_7 = val++;
exports.FLOOR_DEMONIC_LIGHTMAGENTA_8 = val++;
exports.FLOOR_DEMONIC_YELLOW = val++;
exports.FLOOR_DEMONIC_YELLOW_1 = val++;
exports.FLOOR_DEMONIC_YELLOW_2 = val++;
exports.FLOOR_DEMONIC_YELLOW_3 = val++;
exports.FLOOR_DEMONIC_YELLOW_4 = val++;
exports.FLOOR_DEMONIC_YELLOW_5 = val++;
exports.FLOOR_DEMONIC_YELLOW_6 = val++;
exports.FLOOR_DEMONIC_YELLOW_7 = val++;
exports.FLOOR_DEMONIC_YELLOW_8 = val++;
exports.FLOOR_DEMONIC_WHITE = val++;
exports.FLOOR_DEMONIC_WHITE_1 = val++;
exports.FLOOR_DEMONIC_WHITE_2 = val++;
exports.FLOOR_DEMONIC_WHITE_3 = val++;
exports.FLOOR_DEMONIC_WHITE_4 = val++;
exports.FLOOR_DEMONIC_WHITE_5 = val++;
exports.FLOOR_DEMONIC_WHITE_6 = val++;
exports.FLOOR_DEMONIC_WHITE_7 = val++;
exports.FLOOR_DEMONIC_WHITE_8 = val++;
exports.FLOOR_GREEN_BONES = val++;
exports.FLOOR_GREEN_BONES_1 = val++;
exports.FLOOR_GREEN_BONES_2 = val++;
exports.FLOOR_GREEN_BONES_3 = val++;
exports.FLOOR_GREEN_BONES_4 = val++;
exports.FLOOR_GREEN_BONES_5 = val++;
exports.FLOOR_GREEN_BONES_6 = val++;
exports.FLOOR_GREEN_BONES_7 = val++;
exports.FLOOR_GREEN_BONES_8 = val++;
exports.FLOOR_GREEN_BONES_9 = val++;
exports.FLOOR_GREEN_BONES_10 = val++;
exports.FLOOR_GREEN_BONES_11 = val++;
exports.FLOOR_WOODGROUND = val++;
exports.FLOOR_WOODGROUND_1 = val++;
exports.FLOOR_WOODGROUND_2 = val++;
exports.FLOOR_WOODGROUND_3 = val++;
exports.FLOOR_WOODGROUND_4 = val++;
exports.FLOOR_WOODGROUND_5 = val++;
exports.FLOOR_WOODGROUND_6 = val++;
exports.FLOOR_WOODGROUND_7 = val++;
exports.FLOOR_WOODGROUND_8 = val++;
exports.FLOOR_CAGE = val++;
exports.FLOOR_CAGE_1 = val++;
exports.FLOOR_CAGE_2 = val++;
exports.FLOOR_CAGE_3 = val++;
exports.FLOOR_CAGE_4 = val++;
exports.FLOOR_CAGE_5 = val++;
exports.FLOOR_ETCHED = val++;
exports.FLOOR_ETCHED_1 = val++;
exports.FLOOR_ETCHED_2 = val++;
exports.FLOOR_ETCHED_3 = val++;
exports.FLOOR_ETCHED_4 = val++;
exports.FLOOR_ETCHED_5 = val++;
exports.FLOOR_MOSAIC = val++;
exports.FLOOR_MOSAIC_1 = val++;
exports.FLOOR_MOSAIC_2 = val++;
exports.FLOOR_MOSAIC_3 = val++;
exports.FLOOR_MOSAIC_4 = val++;
exports.FLOOR_MOSAIC_5 = val++;
exports.FLOOR_MOSAIC_6 = val++;
exports.FLOOR_MOSAIC_7 = val++;
exports.FLOOR_MOSAIC_8 = val++;
exports.FLOOR_MOSAIC_9 = val++;
exports.FLOOR_MOSAIC_10 = val++;
exports.FLOOR_MOSAIC_11 = val++;
exports.FLOOR_MOSAIC_12 = val++;
exports.FLOOR_MOSAIC_13 = val++;
exports.FLOOR_MOSAIC_14 = val++;
exports.FLOOR_MOSAIC_15 = val++;
exports.DNGN_ENDLESS_SALT = val++;
exports.DNGN_ENDLESS_SALT_1 = val++;
exports.DNGN_ENDLESS_SALT_2 = val++;
exports.DNGN_ENDLESS_SALT_3 = val++;
exports.DNGN_LAVA = val++;
exports.DNGN_LAVA_1 = val++;
exports.DNGN_LAVA_2 = val++;
exports.DNGN_LAVA_3 = val++;
exports.DNGN_LAVA_4 = val++;
exports.DNGN_LAVA_5 = val++;
exports.DNGN_LAVA_6 = val++;
exports.DNGN_LAVA_7 = val++;
exports.DNGN_LAVA_8 = val++;
exports.DNGN_LAVA_9 = val++;
exports.DNGN_LAVA_10 = val++;
exports.DNGN_LAVA_11 = val++;
exports.DNGN_LAVA_12 = val++;
exports.DNGN_LAVA_13 = val++;
exports.DNGN_LAVA_14 = val++;
exports.DNGN_LAVA_15 = val++;
exports.DNGN_LAVA_SEA = val++;
exports.DNGN_LAVA_SEA_1 = val++;
exports.DNGN_LAVA_SEA_2 = val++;
exports.DNGN_LAVA_SEA_3 = val++;
exports.DNGN_LAVA_SEA_4 = val++;
exports.DNGN_LAVA_SEA_5 = val++;
exports.DNGN_LAVA_SEA_6 = val++;
exports.DNGN_LAVA_SEA_7 = val++;
exports.DNGN_LAVA_SEA_8 = val++;
exports.DNGN_LAVA_SEA_9 = val++;
exports.DNGN_LAVA_SEA_10 = val++;
exports.DNGN_LAVA_SEA_11 = val++;
exports.DNGN_LAVA_SEA_12 = val++;
exports.DNGN_LAVA_SEA_13 = val++;
exports.DNGN_LAVA_SEA_14 = val++;
exports.DNGN_LAVA_SEA_15 = val++;
exports.DNGN_OPEN_SEA = val++;
exports.DNGN_OPEN_SEA_1 = val++;
exports.DNGN_DEEP_WATER = val++;
exports.DNGN_DEEP_WATER_1 = val++;
exports.DNGN_SHALLOW_WATER = val++;
exports.DNGN_SHALLOW_WATER_1 = val++;
exports.DNGN_SHALLOW_WATER_DISTURBANCE = val++;
exports.DNGN_SHALLOW_WATER_DISTURBANCE_1 = val++;
exports.DNGN_DEEP_WATER_MURKY = val++;
exports.DNGN_DEEP_WATER_MURKY_1 = val++;
exports.DNGN_SHALLOW_WATER_MURKY = val++;
exports.DNGN_SHALLOW_WATER_MURKY_1 = val++;
exports.DNGN_SHALLOW_WATER_MURKY_DISTURBANCE = val++;
exports.DNGN_SHALLOW_WATER_MURKY_DISTURBANCE_1 = val++;
exports.SHORE_N = val++;
exports.SHORE_W = val++;
exports.SHORE_E = val++;
exports.SHORE_NW = val++;
exports.SHORE_NE = val++;
exports.DNGN_WAVE_N = val++;
exports.DNGN_WAVE_NE = val++;
exports.DNGN_WAVE_E = val++;
exports.DNGN_WAVE_SE = val++;
exports.DNGN_WAVE_S = val++;
exports.DNGN_WAVE_SW = val++;
exports.DNGN_WAVE_W = val++;
exports.DNGN_WAVE_NW = val++;
exports.MURKY_WAVE_N = val++;
exports.MURKY_WAVE_NE = val++;
exports.MURKY_WAVE_E = val++;
exports.MURKY_WAVE_SE = val++;
exports.MURKY_WAVE_S = val++;
exports.MURKY_WAVE_SW = val++;
exports.MURKY_WAVE_W = val++;
exports.MURKY_WAVE_NW = val++;
exports.SHOALS_DEEP_WATER = val++;
exports.SHOALS_DEEP_WATER_1 = val++;
exports.SHOALS_DEEP_WATER_2 = val++;
exports.SHOALS_DEEP_WATER_3 = val++;
exports.SHOALS_DEEP_WATER_4 = val++;
exports.SHOALS_DEEP_WATER_5 = val++;
exports.SHOALS_DEEP_WATER_6 = val++;
exports.SHOALS_DEEP_WATER_7 = val++;
exports.SHOALS_DEEP_WATER_8 = val++;
exports.SHOALS_DEEP_WATER_9 = val++;
exports.SHOALS_DEEP_WATER_10 = val++;
exports.SHOALS_DEEP_WATER_11 = val++;
exports.SHOALS_SHALLOW_WATER = val++;
exports.SHOALS_SHALLOW_WATER_1 = val++;
exports.SHOALS_SHALLOW_WATER_2 = val++;
exports.SHOALS_SHALLOW_WATER_3 = val++;
exports.SHOALS_SHALLOW_WATER_4 = val++;
exports.SHOALS_SHALLOW_WATER_5 = val++;
exports.SHOALS_SHALLOW_WATER_6 = val++;
exports.SHOALS_SHALLOW_WATER_7 = val++;
exports.SHOALS_SHALLOW_WATER_8 = val++;
exports.SHOALS_SHALLOW_WATER_9 = val++;
exports.SHOALS_SHALLOW_WATER_10 = val++;
exports.SHOALS_SHALLOW_WATER_11 = val++;
exports.SHOALS_SHALLOW_WATER_DISTURBANCE = val++;
exports.SHOALS_SHALLOW_WATER_DISTURBANCE_1 = val++;
exports.SHOALS_SHALLOW_WATER_DISTURBANCE_2 = val++;
exports.WAVE_DEEP_CORNER_NE = val++;
exports.WAVE_DEEP_CORNER_NE_1 = val++;
exports.WAVE_DEEP_CORNER_NW = val++;
exports.WAVE_DEEP_CORNER_NW_1 = val++;
exports.WAVE_DEEP_CORNER_SE = val++;
exports.WAVE_DEEP_CORNER_SE_1 = val++;
exports.WAVE_DEEP_CORNER_SW = val++;
exports.WAVE_DEEP_CORNER_SW_1 = val++;
exports.WAVE_DEEP_N = val++;
exports.WAVE_DEEP_N_1 = val++;
exports.WAVE_DEEP_S = val++;
exports.WAVE_DEEP_S_1 = val++;
exports.WAVE_DEEP_E = val++;
exports.WAVE_DEEP_E_1 = val++;
exports.WAVE_DEEP_W = val++;
exports.WAVE_DEEP_W_1 = val++;
exports.WAVE_CORNER_NE = val++;
exports.WAVE_CORNER_NW = val++;
exports.WAVE_CORNER_SE = val++;
exports.WAVE_CORNER_SW = val++;
exports.WAVE_N = val++;
exports.WAVE_S = val++;
exports.WAVE_E = val++;
exports.WAVE_W = val++;
exports.WAVE_INK_CORNER_NE = val++;
exports.WAVE_INK_CORNER_NW = val++;
exports.WAVE_INK_CORNER_SE = val++;
exports.WAVE_INK_CORNER_SW = val++;
exports.WAVE_INK_N = val++;
exports.WAVE_INK_S = val++;
exports.WAVE_INK_E = val++;
exports.WAVE_INK_W = val++;
exports.WAVE_INK_FULL = val++;
exports.LIQUEFACTION = val++;
exports.LIQUEFACTION_1 = val++;
exports.FLOOR_MAX = exports.TILE_FLOOR_MAX = val++;

var tile_info = [
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
  {w: 0, h: 0, ox: 0, oy: 0, sx: 0, sy: 0, ex: 0, ey: 0},
];

exports.get_tile_info = function (idx)
{
    return tile_info[idx - 0];
};

var _tile_count =
[
    1,
    1,
    8,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    8,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    16,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    8,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    8,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    6,
    1,
    1,
    1,
    1,
    1,
    12,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    8,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    12,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    6,
    1,
    1,
    1,
    1,
    1,
    10,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    6,
    1,
    1,
    1,
    1,
    1,
    12,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    3,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    7,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    3,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    10,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    10,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    15,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    10,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    6,
    1,
    1,
    1,
    1,
    1,
    12,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    13,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    12,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    9,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    6,
    1,
    1,
    1,
    1,
    1,
    6,
    1,
    1,
    1,
    1,
    1,
    16,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    4,
    1,
    1,
    1,
    16,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    16,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    12,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    12,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    3,
    1,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    2,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    1,
];

exports.tile_count = function (idx)
{
    return _tile_count[idx - 0];
}

var _basetiles =
[
    0,
    1,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    10,
    10,
    10,
    10,
    10,
    10,
    10,
    10,
    18,
    18,
    18,
    18,
    18,
    18,
    18,
    18,
    18,
    27,
    27,
    27,
    27,
    27,
    27,
    27,
    27,
    27,
    36,
    36,
    36,
    36,
    36,
    36,
    36,
    36,
    36,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    45,
    54,
    54,
    54,
    54,
    54,
    54,
    54,
    54,
    54,
    63,
    63,
    63,
    63,
    63,
    63,
    63,
    63,
    63,
    72,
    72,
    72,
    72,
    72,
    72,
    72,
    72,
    72,
    81,
    81,
    81,
    81,
    81,
    81,
    81,
    81,
    81,
    90,
    90,
    90,
    90,
    90,
    90,
    90,
    90,
    90,
    99,
    99,
    99,
    99,
    99,
    99,
    99,
    99,
    99,
    108,
    108,
    108,
    108,
    108,
    108,
    108,
    108,
    108,
    117,
    117,
    117,
    117,
    117,
    117,
    117,
    117,
    117,
    126,
    126,
    126,
    126,
    126,
    126,
    126,
    126,
    126,
    135,
    135,
    135,
    135,
    135,
    135,
    135,
    135,
    135,
    144,
    144,
    144,
    144,
    144,
    144,
    144,
    144,
    144,
    153,
    153,
    153,
    153,
    153,
    153,
    153,
    153,
    153,
    162,
    162,
    162,
    162,
    166,
    166,
    166,
    166,
    170,
    170,
    170,
    170,
    174,
    174,
    174,
    174,
    174,
    174,
    174,
    174,
    174,
    174,
    174,
    174,
    174,
    174,
    174,
    174,
    190,
    190,
    190,
    190,
    190,
    190,
    190,
    190,
    198,
    198,
    198,
    198,
    202,
    202,
    202,
    202,
    206,
    206,
    206,
    206,
    210,
    210,
    210,
    210,
    210,
    210,
    210,
    210,
    218,
    218,
    218,
    218,
    222,
    222,
    222,
    222,
    226,
    226,
    226,
    226,
    230,
    230,
    230,
    230,
    234,
    234,
    234,
    234,
    234,
    234,
    240,
    240,
    240,
    240,
    240,
    240,
    240,
    240,
    240,
    240,
    240,
    240,
    252,
    252,
    252,
    252,
    256,
    256,
    256,
    256,
    260,
    260,
    260,
    260,
    260,
    260,
    260,
    267,
    267,
    267,
    267,
    271,
    271,
    271,
    271,
    275,
    275,
    275,
    275,
    279,
    279,
    279,
    279,
    283,
    283,
    283,
    283,
    287,
    287,
    287,
    287,
    291,
    291,
    291,
    291,
    295,
    295,
    295,
    295,
    299,
    299,
    299,
    299,
    303,
    303,
    303,
    303,
    307,
    307,
    307,
    307,
    311,
    311,
    311,
    311,
    315,
    315,
    315,
    315,
    319,
    319,
    319,
    319,
    323,
    323,
    323,
    323,
    327,
    327,
    327,
    327,
    327,
    327,
    327,
    327,
    335,
    335,
    335,
    335,
    335,
    335,
    335,
    335,
    335,
    335,
    335,
    335,
    347,
    347,
    347,
    347,
    347,
    347,
    353,
    353,
    353,
    353,
    353,
    353,
    353,
    353,
    353,
    353,
    363,
    363,
    363,
    363,
    363,
    363,
    363,
    370,
    370,
    370,
    370,
    370,
    370,
    376,
    376,
    376,
    376,
    376,
    376,
    376,
    376,
    376,
    376,
    376,
    376,
    388,
    388,
    388,
    388,
    388,
    388,
    388,
    388,
    388,
    397,
    397,
    397,
    400,
    400,
    400,
    400,
    400,
    400,
    400,
    407,
    407,
    407,
    407,
    407,
    407,
    407,
    414,
    414,
    414,
    414,
    414,
    414,
    414,
    421,
    421,
    421,
    421,
    421,
    421,
    421,
    428,
    428,
    428,
    428,
    428,
    428,
    428,
    435,
    435,
    435,
    435,
    435,
    435,
    435,
    442,
    442,
    442,
    442,
    442,
    442,
    442,
    449,
    449,
    449,
    449,
    449,
    449,
    449,
    456,
    456,
    456,
    456,
    456,
    456,
    456,
    463,
    463,
    463,
    463,
    463,
    463,
    463,
    470,
    470,
    470,
    470,
    470,
    470,
    470,
    477,
    477,
    477,
    477,
    477,
    477,
    477,
    484,
    484,
    484,
    484,
    484,
    484,
    484,
    491,
    491,
    491,
    491,
    491,
    491,
    491,
    498,
    498,
    498,
    498,
    498,
    498,
    498,
    505,
    505,
    505,
    505,
    505,
    505,
    505,
    505,
    505,
    514,
    514,
    514,
    514,
    514,
    514,
    514,
    514,
    514,
    523,
    523,
    523,
    526,
    526,
    526,
    526,
    526,
    526,
    526,
    526,
    526,
    535,
    536,
    536,
    536,
    536,
    536,
    536,
    536,
    536,
    536,
    536,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    546,
    556,
    557,
    558,
    559,
    560,
    561,
    562,
    563,
    564,
    565,
    566,
    567,
    568,
    569,
    570,
    571,
    572,
    573,
    574,
    575,
    576,
    577,
    578,
    579,
    580,
    581,
    582,
    583,
    584,
    585,
    586,
    587,
    587,
    587,
    587,
    587,
    587,
    587,
    587,
    587,
    587,
    587,
    587,
    587,
    587,
    587,
    602,
    603,
    603,
    603,
    603,
    607,
    607,
    607,
    607,
    607,
    607,
    607,
    607,
    607,
    607,
    617,
    617,
    617,
    617,
    617,
    617,
    623,
    623,
    623,
    623,
    623,
    623,
    623,
    623,
    623,
    623,
    623,
    623,
    635,
    635,
    635,
    635,
    635,
    635,
    635,
    635,
    635,
    635,
    635,
    635,
    635,
    648,
    648,
    648,
    648,
    648,
    648,
    648,
    648,
    648,
    657,
    657,
    657,
    657,
    657,
    657,
    657,
    657,
    657,
    666,
    666,
    666,
    666,
    666,
    666,
    666,
    666,
    666,
    675,
    675,
    675,
    675,
    675,
    675,
    675,
    675,
    675,
    684,
    684,
    684,
    684,
    684,
    684,
    684,
    684,
    684,
    693,
    693,
    693,
    693,
    693,
    693,
    693,
    693,
    693,
    702,
    702,
    702,
    702,
    702,
    702,
    702,
    702,
    702,
    711,
    711,
    711,
    711,
    711,
    711,
    711,
    711,
    711,
    720,
    720,
    720,
    720,
    720,
    720,
    720,
    720,
    720,
    729,
    729,
    729,
    729,
    729,
    729,
    729,
    729,
    729,
    738,
    738,
    738,
    738,
    738,
    738,
    738,
    738,
    738,
    747,
    747,
    747,
    747,
    747,
    747,
    747,
    747,
    747,
    756,
    756,
    756,
    756,
    756,
    756,
    756,
    756,
    756,
    765,
    765,
    765,
    765,
    765,
    765,
    765,
    765,
    765,
    774,
    774,
    774,
    774,
    774,
    774,
    774,
    774,
    774,
    783,
    783,
    783,
    783,
    783,
    783,
    783,
    783,
    783,
    783,
    783,
    783,
    795,
    795,
    795,
    795,
    795,
    795,
    795,
    795,
    795,
    804,
    804,
    804,
    804,
    804,
    804,
    810,
    810,
    810,
    810,
    810,
    810,
    816,
    816,
    816,
    816,
    816,
    816,
    816,
    816,
    816,
    816,
    816,
    816,
    816,
    816,
    816,
    816,
    832,
    832,
    832,
    832,
    836,
    836,
    836,
    836,
    836,
    836,
    836,
    836,
    836,
    836,
    836,
    836,
    836,
    836,
    836,
    836,
    852,
    852,
    852,
    852,
    852,
    852,
    852,
    852,
    852,
    852,
    852,
    852,
    852,
    852,
    852,
    852,
    868,
    868,
    870,
    870,
    872,
    872,
    874,
    874,
    876,
    876,
    878,
    878,
    880,
    880,
    882,
    883,
    884,
    885,
    886,
    887,
    888,
    889,
    890,
    891,
    892,
    893,
    894,
    895,
    896,
    897,
    898,
    899,
    900,
    901,
    902,
    903,
    903,
    903,
    903,
    903,
    903,
    903,
    903,
    903,
    903,
    903,
    903,
    915,
    915,
    915,
    915,
    915,
    915,
    915,
    915,
    915,
    915,
    915,
    915,
    927,
    927,
    927,
    930,
    930,
    932,
    932,
    934,
    934,
    936,
    936,
    938,
    938,
    940,
    940,
    942,
    942,
    944,
    944,
    946,
    947,
    948,
    949,
    950,
    951,
    952,
    953,
    954,
    955,
    956,
    957,
    958,
    959,
    960,
    961,
    962,
    963,
    963,
];

exports.basetile = function (idx)
{
    return _basetiles[idx - 0] + 0;
};

exports.get_img = function (idx) {
    return "floor";
};

return exports;
});
